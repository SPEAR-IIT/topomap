#include "defs.h"
#include "misc/common.h"
#include "misc/options.h"
#include <string.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "mylib.h"
#include "analytical_mapping.h"
#include "timing.h"
#include "lu_nics.h"
#ifndef METIS51
#include "chol_solve.h"
#else
extern "C" {
#include <metis.h>
}
#endif

#define LINE_LENGTH 65536 // support up to 1K MPI processes
#define INVALID -1

// If global mapping does not derive a better solution within
// ITER_BOUND iterations, it will terminate.
//#define ITER_BOUND 10

// The RCM ordering does not give better performance than BFS
//#define ENABLE_RCM

using misc::options;
using namespace timing;

int original_num_procs;
int num_procs;
int num_nodes;
int num_procs_per_node;
int num_vars;

int *pinned_processes;
int **total_comm_map;
int **original_comm_map;
int **comm_map;

std::vector<int> total_comm_off_diag_x;
std::vector<int> total_comm_off_diag_i;
std::vector<int> total_comm_off_diag_p;

std::vector<int> part_comm_off_diag_x;
std::vector<int> part_comm_off_diag_i;
std::vector<int> part_comm_off_diag_p;

std::vector<int> comm_off_diag_x_temp;
std::vector<int> comm_off_diag_i_temp;
std::vector<int> comm_off_diag_p_temp;

std::vector<int>& comm_off_diag_x = comm_off_diag_x_temp;
std::vector<int>& comm_off_diag_i = comm_off_diag_i_temp;
std::vector<int>& comm_off_diag_p = comm_off_diag_p_temp;

std::vector<int> newpart_comm_off_diag_x;
std::vector<int> newpart_comm_off_diag_i;

std::vector<int> proc2var;
std::vector<double> off_diag_x;
std::vector<int> off_diag_i;
std::vector<int> off_diag_p;
std::vector<double> diag;
std::vector<double> minus_dx;
std::vector<double> minus_dy;
std::vector<double> minus_dz;
std::vector<coordinates> proc2nodecoord;
std::vector<double> varx;
std::vector<double> vary;
std::vector<double> varz;
std::vector<double> new_varx;
std::vector<double> new_vary;
std::vector<double> new_varz;
//std::vector<double> original_varx;
//std::vector<double> original_vary;
//std::vector<double> original_varz;
std::vector<double> original_diag;
std::vector<double> original_minus_dx;
std::vector<double> original_minus_dy;
std::vector<double> original_minus_dz;
std::vector<double> sum_off_diag;
std::vector<int> ****nodecoord2procvar;
double ***NBx;
double ***NBy;
double ***NBz;

double delta = 1.5;
int max_Ui;
double alpha;
size_t my_hop_bytes;

lu_nics nicslu;
#ifndef METIS51
chol_solve cholmod;
#endif

std::vector<int> proc_part;
std::vector<std::vector<int>*> part_procs;

char *input_comm_file;

void read_sparse_comm_map_file(char *comm_map_file)
{
	input_comm_file = comm_map_file;

	FILE *fp;
	char aline[LINE_LENGTH];
	char *line;
	char buffer[LINE_LENGTH];

	std::vector<edge_map*> edge_maps;

	enum ParseState {Init, Read};
	ParseState state = Init;

	size_t max_weight = 0;

	bool mm_format = options::get().as_bool("mm_format");

	if (!(fp=fopen(comm_map_file, "r")))
	{
		fprintf(stdout, "\n\tCannot read file %s !\n", comm_map_file);
		fflush(stdout);
		exit(-1);
	}

	fseek(fp, 0, SEEK_SET);
	while (fgets(aline, LINE_LENGTH, fp)) {
		if ((aline[0] == '%') || (aline[0] == '#')) {
			continue; // comment
		}

		line = aline;
		line = get_data(line, buffer);

		if (state == Init) { // read num_procs
			sscanf(aline, "%d", &num_procs);
			fprintf(stdout, "num_procs:\t%d\n", num_procs);
			assert(num_procs > 1);
			
			original_num_procs = num_procs;

			for (int i = 0; i < num_procs; i++) {
				edge_maps.push_back(new edge_map);
			}

			state = Read;
		}
		else { // read edges (i j weight) in the communication graph
			int i, j;
			size_t weight;
			sscanf(buffer, "%d", &i);
			line = get_data(line, buffer);
			sscanf(buffer, "%d", &j);
			line = get_data(line, buffer);
			sscanf(buffer, "%ld", &weight);

			if (mm_format) {
				i--;
				j--;
			}

			assert(i >= 0 && i < num_procs);
			assert(j >= 0 && j < num_procs);
			assert(weight > 0);

			if (i != j) {
				(*edge_maps[i])[j] = weight;
				if (weight > max_weight) max_weight = weight;
			}
		}
	}
		
	fclose(fp);

	fprintf(stdout, "max_weight = %ld\n", max_weight);

	bool scale_edge_weight = options::get().as_bool("scale_edge_weight");
	if (scale_edge_weight) {
		for (size_t i = 0; i < edge_maps.size(); i++) {
			for (edge_map::iterator it = edge_maps[i]->begin();
				it != edge_maps[i]->end(); it++) {
				size_t weight = it->second; // weight
				//it->second = ceil((double)weight/(double)max_weight*10000.0);
				double weight_double = static_cast<double>(weight);
				double max_weight_double = static_cast<double>(max_weight);
				//it->second = ceil(10000.0*static_cast<double>(weight)/static_cast<double>(max_weight));
				double scaled_weight = ceil(10000.0*weight_double/max_weight_double);
				it->second = scaled_weight;
			}
		}
	}

	bool write_scaled_comm = options::get().as_bool("write_scaled_comm");
	if (write_scaled_comm) {
		assert(scale_edge_weight);
		char filename[256];
		sprintf(filename, "%s.scaled.comm", comm_map_file);
		write_scaled_comm_map_file(filename, edge_maps);
//		exit(0);
	}

	// build the communication graph
	build_sparse_graph(edge_maps, total_comm_off_diag_x,
		total_comm_off_diag_i, total_comm_off_diag_p);

	if (write_scaled_comm) {
		assert(scale_edge_weight);
		char filename[256];
		sprintf(filename, "%s.scaled.comm.sym", comm_map_file);
		write_scaled_comm_map_file(filename, edge_maps);
		exit(0);
	}

	// destroy edge_map entries
	for (size_t i = 0; i < edge_maps.size(); i++)
		edge_maps[i]->~map();

}

void write_scaled_comm_map_file(char *filename, std::vector<edge_map*> &edge_maps)
{
	FILE *fp;

	if (!(fp=fopen(filename, "w")))
	{
		fprintf(stdout, "\n\tCannot open file %s !\n", filename);
		fflush(stdout);
		exit(-1);
	}

	fprintf(fp, "%d\n", num_procs);

/*
	for (int i = 0; i < num_procs; ++i) {
		for (int offset = total_comm_off_diag_p[i]; offset < total_comm_off_diag_p[i+1]; ++offset) {
			int j = total_comm_off_diag_i[offset];
			int weight = total_comm_off_diag_x[offset];
			fprintf(fp, "%d %d %d\n", i, j, weight);
		}
	}
*/

	// Note: the communication map is asymmetric
	// In later steps, we convert it into a symmetric graph for analytical mapping
	// Here, we write the scaled comm_map_file in order to test libtopomap
	for (size_t i = 0; i < edge_maps.size(); i++) {
		for (edge_map::iterator it = edge_maps[i]->begin();
			it != edge_maps[i]->end(); it++) {
			int j = it->first; // other proc
			size_t weight = it->second; // weight
			fprintf(fp, "%d %d %d\n", i, j, weight);
		}
	}

	fclose(fp);

	fprintf(stdout, "Write scaled comm_map_file \"%s\" done!\n", filename);
}

// build an undirected sparse graph from directed edge maps
void build_sparse_graph(std::vector<edge_map*> &edge_maps, std::vector<int> &graph_x,
		std::vector<int> &graph_i, std::vector<int> &graph_p)
{
	size_t edge_cnt = 0;

	for (size_t i = 0; i < edge_maps.size(); i++) {
		for (edge_map::iterator it = edge_maps[i]->begin();
			it != edge_maps[i]->end(); it++) {
			size_t j = it->first; // other proc
			int weight = it->second; // weight

			edge_map::iterator other_it = edge_maps[j]->find(i);

			if (j > i) { 
				if (other_it == edge_maps[j]->end()) { // no such edge j->i
					(*edge_maps[j])[i] = weight; // add edge j->i
				}
				else { // has an edge j->i, count the total weight, and then update both edges
					int other_weight = other_it->second;
					int total_weight = weight + other_weight;

					// update the total communication between i and j
					it->second = total_weight;
					other_it->second = total_weight;
				}
			}
			else { // must be j < i
				if (other_it == edge_maps[j]->end()) { // no such edge j->i
					(*edge_maps[j])[i] = weight; // add edge j->i
					edge_cnt++; // one edge added to a prior counted map
				}
				else { // this case has already been handled
				}
			}
		}

		edge_cnt += edge_maps[i]->size(); // count the edges
	}
	
	graph_x.clear();
	graph_i.clear();
	graph_p.clear();

	graph_x.reserve(edge_cnt);
	graph_i.reserve(edge_cnt);
	graph_p.reserve(edge_maps.size()+1);

	for (size_t i = 0; i < edge_maps.size(); i++) {
		graph_p.push_back(graph_x.size());
		for (edge_map::iterator it = edge_maps[i]->begin();
			it != edge_maps[i]->end(); it++) {
			graph_i.push_back(it->first);
			graph_x.push_back(it->second);

			#ifndef NDEBUG
			int j = it->first; // other proc
			edge_map::iterator other_it = edge_maps[j]->find(i);
			assert(other_it != edge_maps[j]->end() && it->second == other_it->second); // symmetric
			#endif
		}
	}
	graph_p.push_back(graph_x.size());
}

void read_comm_map_file(char *comm_map_file)
{
	FILE *fp;
	char aline[LINE_LENGTH];
	char *line;
	char buffer[LINE_LENGTH];
	int i, j;
	//int proc;

	//pinned_processes = memory_alloc(int, 8);

	if (!(fp=fopen(comm_map_file, "r")))
	{
		fprintf(stdout, "\n\tCannot read file %s !\n", comm_map_file);
		fflush(stdout);
		exit(-1);
	}

	fseek(fp, 0, SEEK_SET);
	enum ParseState {Init, Total, Original};
	ParseState state = Init;
	//bool read_first = true;
	num_procs = -1;
	while (fgets(aline, LINE_LENGTH, fp)) {
		line = aline;
		line = get_data(line, buffer);

		if (state == Init) { // read num_procs
			//fprintf(stdout, "state 0\n");
			if (strcmp(buffer, "num_procs:") == 0) {
			
				line = get_data(line, buffer);
				sscanf(buffer, "%d", &num_procs);
				assert(num_procs > 1);

				total_comm_map = memory_alloc(int*, num_procs);
				for (i = 0; i < num_procs; i++) {
					total_comm_map[i] = memory_alloc(int, num_procs);
					for (j = 0; j < num_procs; j++) total_comm_map[i][j] = 0;
				}

				original_comm_map = memory_alloc(int*, num_procs);
				for (i = 0; i < num_procs; i++) {
					original_comm_map[i] = memory_alloc(int, num_procs);
					for (j = 0; j < num_procs; j++) original_comm_map[i][j] = 0;
				}
			}
			else if (strcmp(buffer, "total_comm_map") == 0) {
				state = Total;
			}
		}
		else if (state == Total) { // read total_comm_map
			//fprintf(stdout, "state 1\n");
			if (strcmp(buffer, "original_comm_map") == 0) {
				state = Original;
			}
			else if (isdigit(buffer[0])) {
				sscanf(buffer, "%d", &i);
				line = get_data(line, buffer);
				sscanf(buffer, "%d", &j);

				int weight;
				line = get_data(line, buffer);
				sscanf(buffer, "%d", &weight);

				assert(i >= 0 && i < num_procs);
				assert(j >= 0 && j < num_procs);
				assert(weight > 0);

				total_comm_map[i][j] = weight;
				//fprintf(stdout, "%d\t%d\t%d\n", i, j, weight);
			}
		}
		else if (state == Original) { // read original_comm_map
			if (isdigit(buffer[0])) {
				sscanf(buffer, "%d", &i);
				line = get_data(line, buffer);
				sscanf(buffer, "%d", &j);

				int weight;
				line = get_data(line, buffer);
				sscanf(buffer, "%d", &weight);

				assert(i >= 0 && i < num_procs);
				assert(j >= 0 && j < num_procs);
				assert(weight > 0);

				original_comm_map[i][j] = weight;
			}
		}
		
/*		//else if (strcmp(buffer, "pinned_procs:") == 0) {
		//	for (i = 0; i < 8; i++) {
		//		line = get_data(line, buffer);
		//		sscanf(buffer, "%d", &pinned_processes[i]);
		//	}
		//}
		else if (read_first && (strcmp(buffer, "proc\\proc") == 0)) {
			assert(num_procs > 1);
			for (i = 0; i < num_procs; i++) {
				if (fgets(aline, LINE_LENGTH, fp) != NULL) {
					line = aline;
					line = get_data(line, buffer);
					sscanf(buffer, "%d", &proc);
					assert(i == proc);

					for (j = 0; j < num_procs; j++) {
						line = get_data(line, buffer);
						sscanf(buffer, "%d", &total_comm_map[i][j]);
						//assert(hop_distance[i][j] >= 0);
					}
				}
				else {
					fprintf(stdout, "\n\tCannot read total_comm_map of process %d!\n",
						i);
					fflush(stdout);
					exit(-1);
				}
			}

			read_first = false;
			//break;
		}
		else if ((!read_first) && (strcmp(buffer, "proc\\proc") == 0)) {
			assert(num_procs > 1);
			for (i = 0; i < num_procs; i++) {
				if (fgets(aline, LINE_LENGTH, fp) != NULL) {
					line = aline;
					line = get_data(line, buffer);
					sscanf(buffer, "%d", &proc);
					assert(i == proc);

					for (j = 0; j < num_procs; j++) {
						line = get_data(line, buffer);
						sscanf(buffer, "%d", &original_comm_map[i][j]);
						//assert(hop_distance[i][j] >= 0);
					}
				}
				else {
					fprintf(stdout, "\n\tCannot read original_comm_map of process %d!\n",
						i);
					fflush(stdout);
					exit(-1);
				}
			}

			break;
		} */
	}

	fclose(fp);

	for (i = 0; i < num_procs; i++) {
		for (j = 0; j < i; j++) {
			assert(total_comm_map[i][j] == total_comm_map[j][i]); // check symmetry
		}
	}

	fprintf(stdout, "num_procs:\t%d\n", num_procs);

/*	//fprintf(stdout, "pinned_procs:");
	//for (i = 0; i < 8; i++) {
	//	fprintf(stdout, "\t%d", pinned_processes[i]);
	//}
	//fprintf(stdout, "\n");

	fprintf(stdout, "total_comm_map (symmetric):\n");
	fprintf(stdout, "proc\\proc");
	for (i = 0; i < num_procs; i++) {
		fprintf(stdout, "\t%d", i);
	}
	fprintf(stdout, "\n");

	for (i = 0; i < num_procs; i++) {
		fprintf(stdout, "%d", i);
		for (j = 0; j < num_procs; j++) {
			fprintf(stdout, "\t%d", total_comm_map[i][j]);
		}
		fprintf(stdout, "\n");
	}

	fprintf(stdout, "\noriginal_comm_map (asymmetric):\n");
	fprintf(stdout, "proc\\proc");
	for (i = 0; i < num_procs; i++) {
		fprintf(stdout, "\t%d", i);
	}
	fprintf(stdout, "\n");

	for (i = 0; i < num_procs; i++) {
		fprintf(stdout, "%d", i);
		for (j = 0; j < num_procs; j++) {
			fprintf(stdout, "\t%d", original_comm_map[i][j]);
		}
		fprintf(stdout, "\n");
	}

	fflush(stdout); */
}

coordinates compute_coordinates(int n)
{
	assert(n >= 0);

	coordinates coord;
	int remainder;

	coord.x = n/(mesh_y*mesh_z);
	remainder = n%(mesh_y*mesh_z);
	coord.y = remainder/mesh_z;
	coord.z = remainder%mesh_z;

	return coord;
}

int estimate_coordinate_distance(int x1, int x2, int x_dimension)
{
	int d1 = abs(x1-x2);

	if (!is_torus) return d1; // mesh

	int d2;

	if (x1 < x2) {
		d2 = abs(x1+x_dimension-x2);
	}
	else {
		d2 = abs(x2+x_dimension-x1);
	}

	int d = (d1 < d2) ? d1 : d2;

	//debug_assert(d <= max_dis);

	return d; // torus
}

int estimate_hop_distance(coordinates &coord1, coordinates &coord2)
{
	int dis = 0;
	
	dis += estimate_coordinate_distance(coord1.x, coord2.x, mesh_x);
	dis += estimate_coordinate_distance(coord1.y, coord2.y, mesh_y);
	dis += estimate_coordinate_distance(coord1.z, coord2.z, mesh_z);

	return dis;
}

int compute_node_hop_distance(int node1, int node2)
{
	coordinates coord1, coord2;
	coord1 = compute_coordinates(node1);
	coord2 = compute_coordinates(node2);
	
	//int dis = abs(coord1.x-coord2.x)
	//		+ abs(coord1.y-coord2.y)
	//		+ abs(coord1.z-coord2.z);
	
	int dis = estimate_hop_distance(coord1, coord2);

	return dis; 
}

bool compare_degree(const int i, const int j)
{
	int degree_i = comm_off_diag_p[i+1] - comm_off_diag_p[i];
	int degree_j = comm_off_diag_p[j+1] - comm_off_diag_p[j];
	return (degree_i < degree_j); 
}

//std::vector<int> reordered_parts; // the re-ordered parts 
//std::vector<int> part_order; // the mapping of original part id to its new part id 

bool compare_i(const int i, const int j)
{
	return (newpart_comm_off_diag_i[i] < newpart_comm_off_diag_i[j]); 
}

/*
void update_comm_off_diag_xi()
{
	assert(reordered_parts.size() > 0);

	newpart_comm_off_diag_x.resize(comm_off_diag_x.size());
	newpart_comm_off_diag_i.resize(comm_off_diag_i.size());

	for (size_t i = 0; i < comm_off_diag_i.size(); ++i) {
		newpart_comm_off_diag_x[i] = part_comm_off_diag_x[reordered_parts[i]];
		newpart_comm_off_diag_i[i] = part_comm_off_diag_i[reordered_parts[i]];
	}

	std::vector<int> order(newpart_comm_off_diag_i.size());
	for (size_t i = 0; i < newpart_comm_off_diag_i.size(); ++i) {
		order[i] = i;
	}

	for (int i = 0; i < num_nodes; ++i) {
		std::sort(order.begin()+part_comm_off_diag_p[i], order.begin()+part_comm_off_diag_p[i+1], compare_i);
	}


		for (int i = 0; i < num_nodes; ++i) {
}
*/

void determine_pinned_processes()
{
	int pin_scheme = options::get().as_int("pin_scheme");
	assert(pin_scheme == 0 || pin_scheme == 1);

//	bool cache_opt = options::get().as_bool("cache_opt");
//	assert(cache_opt ? (pin_scheme == 1) : true);

	// perform breath first traversal of the mesh topology.
	
	std::vector<int> color(num_nodes, 0); // color: 0 - white, 1 - grey, 2 - black
	std::vector<int> reordered_nodes; // the re-ordered nodes 
	std::list<int> Q;
	color[0] = 1; // grey
	Q.push_back(0);

	while (!Q.empty()) {
		int node = Q.front();
		Q.pop_front();

		color[node] = 2; // black
		reordered_nodes.push_back(node);

		int neighbor_node = node + 1; // <x,y,z> -> <x,y,z+1>
		if (neighbor_node < num_nodes) {
			if (color[neighbor_node] == 0) { // white
				Q.push_back(neighbor_node);
				color[neighbor_node] = 1; // grey
			}
		}

		neighbor_node = node + mesh_z; // <x,y,z> -> <x,y+1,z>
		if (neighbor_node < num_nodes) {
			if (color[neighbor_node] == 0) { // white
				Q.push_back(neighbor_node);
				color[neighbor_node] = 1; // grey
			}
		}

		neighbor_node = node + mesh_y*mesh_z; // <x,y,z> -> <x+1,y,z>
		if (neighbor_node < num_nodes) {
			if (color[neighbor_node] == 0) { // white
				Q.push_back(neighbor_node);
				color[neighbor_node] = 1; // grey
			}
		}
	}

	assert(reordered_nodes.size() == (size_t)num_nodes);

	for (int i = 0; i < num_nodes; i++) {
		assert(color[i] == 2); // all black
	}

	// perform breath first traversal of the communication graph.

	color.assign(num_nodes,0);
	std::vector<int> reordered_parts; // the re-ordered parts 
	reordered_parts.clear();

	color[0] = 1; // grey
	Q.push_back(0);

//#ifndef ENABLE_RCM
	if (pin_scheme == 0) { // breath first traversal
	while (!Q.empty()) {
		int part = Q.front();
		Q.pop_front();

		color[part] = 2; // black
		reordered_parts.push_back(part);

		for (int i = comm_off_diag_p[part]; i < comm_off_diag_p[part+1]; i++) {
			int other_part = comm_off_diag_i[i];
			if (color[other_part] == 0) { // white
				Q.push_back(other_part);
				color[other_part] = 1; // grey
			}
		}
	}
	}
//#else
	else { // rcm ordering
	std::list<int>* Q_current = &Q;
	std::list<int>* Q_next = new std::list<int>;
	std::vector<int> level_p; // level offset
	//int level_cnt = 0;
	level_p.push_back(reordered_parts.size());
	while (!Q_current->empty()) {
		int part = Q_current->front();
		Q_current->pop_front();

		assert(color[part] == 1); // grey
		color[part] = 2; // black
		reordered_parts.push_back(part);
		//level_cnt++;

		for (int i = comm_off_diag_p[part]; i < comm_off_diag_p[part+1]; i++) {
			int other_part = comm_off_diag_i[i];
			if (color[other_part] == 0) { // white
				Q_next->push_back(other_part);
				color[other_part] = 1; // grey
			}
		}

		if (Q_current->empty()) {
			//level_p.push_back(level_cnt);
			level_p.push_back(reordered_parts.size());
			std::list<int>* temp = Q_current;
			Q_current = Q_next;
			Q_next = temp;
		}
	}
	assert(*(level_p.end()-1) == num_nodes);

	// sort the vertices for each level
	for (size_t i = 0; i+1 < level_p.size(); i++) {
		std::sort(reordered_parts.begin()+level_p[i], reordered_parts.begin()+level_p[i+1], compare_degree);
	}
//#endif
	}

	assert(reordered_parts.size() == (size_t)num_nodes);

	for (int i = 0; i < num_nodes; i++) {
		assert(color[i] == 2); // all black
	}

/*	
	if (cache_opt) {
		part_order.resize(num_nodes);
		for (int i = 0; i < num_nodes; ++i) {
			part_order[reordered_parts[i]] = i;
		}
	}
*/
	// determine pinned processes according to the node and part ordering
	pinned_processes = memory_alloc(int, 8);

	for (int i = 0; i < num_nodes; i++) {
		int node = reordered_nodes[i];
		coordinates coord = compute_coordinates(node);

		int offset = 0;

		if ((coord.x == 0) || (coord.x == mesh_x-1)) {
			if (coord.x == mesh_x-1) offset +=  4;
		}
		else {
			continue;
		}

		if ((coord.y == 0) || (coord.y == mesh_y-1)) {
			if (coord.y == mesh_y-1) offset +=  2;
		}
		else {
			continue;
		}

		if ((coord.z == 0) || (coord.z == mesh_z-1)) {
			if (coord.z == mesh_z-1) offset +=  1;
		}
		else {
			continue;
		}

		pinned_processes[offset] = reordered_parts[i];
	}
}

void preprocessing(char *comm_map_file)
{
	start_timer(IO);
	read_sparse_comm_map_file(comm_map_file);
	end_timer(IO);

	start_timer(TOTALMAP);
	start_timer(PREPROCESS);

	//num_procs = mesh_x * mesh_y * mesh_z;
	num_nodes = mesh_x * mesh_y * mesh_z;
	//num_vars = num_procs - 8;
	num_procs_per_node = num_procs / num_nodes;

	fprintf(stdout, "num_procs = %d, num_nodes = %d, num_procs_per_node = %d\n",
		num_procs, num_nodes, num_procs_per_node);

	assert(num_procs_per_node >= 1);
	assert(num_procs % num_nodes == 0);

	if (num_procs_per_node > 1) {

		// use METIS to partition the communication graph into equal parts
		start_timer(GP);
		partition_graph_METIS(num_procs, total_comm_off_diag_x, 
			total_comm_off_diag_i, total_comm_off_diag_p, num_procs_per_node,
			proc_part, part_procs);
		end_timer(GP);

		std::vector<edge_map*> edge_maps;

		for (int i = 0; i < num_nodes; i++) {
			edge_maps.push_back(new edge_map);
		}
		
		int edge_cnt = 0;
		for (int i = 0; i < num_procs; i++) {
			for (int offset = total_comm_off_diag_p[i]; offset < total_comm_off_diag_p[i+1]; offset++) {
				int j = total_comm_off_diag_i[offset];
				int weight = total_comm_off_diag_x[offset];
				int ipart = proc_part[i];
				int jpart = proc_part[j];
				if (ipart != jpart) { // not in the same part
					if (edge_maps[ipart]->find(jpart) == edge_maps[ipart]->end()) { // entry does not exist
						(*edge_maps[ipart])[jpart] = weight;
						edge_cnt++;
					}
					else { // entry exists, just update the edge weight
						(*edge_maps[ipart])[jpart] += weight;
					}
				}
			}
		}

		part_comm_off_diag_x.clear();
		part_comm_off_diag_i.clear();
		part_comm_off_diag_p.clear();

		part_comm_off_diag_x.reserve(edge_cnt);
		part_comm_off_diag_i.reserve(edge_cnt);
		part_comm_off_diag_p.reserve(edge_maps.size()+1);

		for (int i = 0; i < num_nodes; i++) {
			part_comm_off_diag_p.push_back(part_comm_off_diag_x.size());
			for (edge_map::iterator it = edge_maps[i]->begin();
				it != edge_maps[i]->end(); it++) {
				part_comm_off_diag_i.push_back(it->first);
				part_comm_off_diag_x.push_back(it->second);

				#ifndef NDEBUG
				int j = it->first; // other node
				edge_map::iterator other_it = edge_maps[j]->find(i);
				assert(other_it != edge_maps[j]->end() && it->second == other_it->second); // symmetric
				#endif
			}
		}
		part_comm_off_diag_p.push_back(part_comm_off_diag_x.size());

		// destroy map entries
		for (int i = 0; i < num_nodes; i++) {
			edge_maps[i]->~map();
		}

		// set the reference comm to be part_comm
		comm_off_diag_x = part_comm_off_diag_x;
		comm_off_diag_i = part_comm_off_diag_i;
		comm_off_diag_p = part_comm_off_diag_p;

		num_procs = num_nodes; // set num_procs to be equal to num_nodes, cheat the analytical mapping code
	}
	else {
		assert(num_procs_per_node == 1); // num_procs == num_nodes

		proc_part.resize(num_procs);
		part_procs.clear();
		for (int i = 0; i < num_procs; i++) {
			proc_part[i] = i;
			part_procs.push_back(new std::vector<int>);
			part_procs[i]->push_back(i);
		}

		comm_off_diag_x = total_comm_off_diag_x;
		comm_off_diag_i = total_comm_off_diag_i;
		comm_off_diag_p = total_comm_off_diag_p;
	}

	num_vars = num_procs - 8;

	determine_pinned_processes();

	proc2var.assign(num_procs, 0);
	coordinates coord;
	coord.x = INVALID;
	coord.y = INVALID;
	coord.z = INVALID;
	proc2nodecoord.assign(num_procs, coord);

	for (int i = 0; i < 8; i++) {
		proc2var[pinned_processes[i]] = INVALID;

		// convert i to binary number xyz
		int x, y, z;
		int remainder;
		x = i/4;
		remainder = i%4;
		y = remainder/2;
		z = remainder%2;

		if (x==0) proc2nodecoord[pinned_processes[i]].x = 0;
		else proc2nodecoord[pinned_processes[i]].x = mesh_x-1;

		if (y==0) proc2nodecoord[pinned_processes[i]].y = 0;
		else proc2nodecoord[pinned_processes[i]].y = mesh_y-1;

		if (z==0) proc2nodecoord[pinned_processes[i]].z = 0;
		else proc2nodecoord[pinned_processes[i]].z = mesh_z-1;
	}
		   
	int var = 0;
	// build proc2var
	for (int i = 0; i < num_procs; i++) {
		if (proc2var[i] != INVALID) {
			proc2var[i] = var;
			var++;
		}
	}
	assert(var == num_vars);

	off_diag_x.clear();
	off_diag_i.clear();
	off_diag_p.clear();
	diag.clear();
	minus_dx.clear();
	minus_dy.clear();
	minus_dz.clear();
	sum_off_diag.clear();

	off_diag_x.reserve(6*num_vars);
	off_diag_i.reserve(6*num_vars);
	off_diag_p.reserve(num_vars+1);
	diag.reserve(num_vars);
	minus_dx.reserve(num_vars);
	minus_dy.reserve(num_vars);
	minus_dz.reserve(num_vars);
	sum_off_diag.reserve(num_vars);

	for (int i = 0; i < num_procs; i++) {
		if (proc2var[i] != INVALID) {
			off_diag_p.push_back(off_diag_x.size());
			double total_comm = 0;
			double sum_off_diag_comm = 0;
			double mdx = 0;
			double mdy = 0;
			double mdz = 0;
			for (int j = comm_off_diag_p[i]; j < comm_off_diag_p[i+1]; j++) {
				total_comm += (double)comm_off_diag_x[j];
				int other_proc = comm_off_diag_i[j];
				if (proc2var[other_proc] != INVALID) { // connection with un-pinned processes
					off_diag_i.push_back(proc2var[other_proc]);
					off_diag_x.push_back((double)comm_off_diag_x[j]);
					sum_off_diag_comm += (double)comm_off_diag_x[j];
				}
				else { // connection with pinned processes
					mdx += comm_off_diag_x[j]*proc2nodecoord[other_proc].x;
					mdy += comm_off_diag_x[j]*proc2nodecoord[other_proc].y;
					mdz += comm_off_diag_x[j]*proc2nodecoord[other_proc].z;
				}
			}

			diag.push_back(total_comm);
			minus_dx.push_back(mdx);
			minus_dy.push_back(mdy);
			minus_dz.push_back(mdz);
			sum_off_diag.push_back(sum_off_diag_comm);
		}
	}
	off_diag_p.push_back(off_diag_x.size());

	assert(off_diag_p.size() == (size_t)num_vars+1);
	assert(diag.size() == (size_t)num_vars);
	assert(minus_dx.size() == (size_t)num_vars);
	assert(minus_dy.size() == (size_t)num_vars);
	assert(minus_dz.size() == (size_t)num_vars);

#ifndef METIS51
	if (options::get().as_int("solver") == 0) {
		nicslu.load_matrix(num_vars, off_diag_x.size()+num_vars, &off_diag_x[0],
			&off_diag_i[0], &off_diag_p[0], &diag[0]);
	}
	else {
		assert(options::get().as_int("solver") == 1);
		cholmod.load_matrix(num_vars, off_diag_x.size()+num_vars, &off_diag_x[0],
			&off_diag_i[0], &off_diag_p[0], &diag[0]);
	}
#else
	assert(options::get().as_int("solver") == 0);
	nicslu.load_matrix(num_vars, off_diag_x.size()+num_vars, &off_diag_x[0],
		&off_diag_i[0], &off_diag_p[0], &diag[0]);
#endif

	varx.assign(num_vars, 0);
	vary.assign(num_vars, 0);
	varz.assign(num_vars, 0);
	new_varx.assign(num_vars, 0);
	new_vary.assign(num_vars, 0);
	new_varz.assign(num_vars, 0);
	
//	original_varx.assign(num_vars, 0);
//	original_vary.assign(num_vars, 0);
//	original_varz.assign(num_vars, 0);
	original_diag.assign(num_vars, 0);
	original_minus_dx.assign(num_vars, 0);
	original_minus_dy.assign(num_vars, 0);
	original_minus_dz.assign(num_vars, 0);

	std::copy(diag.begin(), diag.end(), original_diag.begin());
	std::copy(minus_dx.begin(), minus_dx.end(), original_minus_dx.begin());
	std::copy(minus_dy.begin(), minus_dy.end(), original_minus_dy.begin());
	std::copy(minus_dz.begin(), minus_dz.end(), original_minus_dz.begin());
	
	nodecoord2procvar = new std::vector<int>*** [mesh_x];
	for (int i = 0; i < mesh_x; i++) {
		nodecoord2procvar[i] = new std::vector<int>** [mesh_y];
 		for (int j = 0; j < mesh_y; j++) {
			nodecoord2procvar[i][j] = new std::vector<int>* [mesh_z];
			for (int k = 0; k < mesh_z; k++) {
				nodecoord2procvar[i][j][k] = new std::vector<int>;
			}
		}
	}

	// NBx[mesh_y][mesh_z][mesh_x-1]
	NBx = new double** [mesh_y];
	for (int i = 0; i < mesh_y; i++) {
		NBx[i] = new double* [mesh_z];
		for (int j = 0; j < mesh_z; j++) {
			NBx[i][j] = new double [mesh_x-1];
		}
	}

	// NBy[mesh_z][mesh_x][mesh_y-1]
	NBy = new double** [mesh_z];
	for (int i = 0; i < mesh_z; i++) {
		NBy[i] = new double* [mesh_x];
		for (int j = 0; j < mesh_x; j++) {
			NBy[i][j] = new double [mesh_y-1];
		}
	}

	// NBz[mesh_x][mesh_y][mesh_z-1]
	NBz = new double** [mesh_x];
	for (int i = 0; i < mesh_x; i++) {
		NBz[i] = new double* [mesh_y];
		for (int j = 0; j < mesh_y; j++) {
			NBz[i][j] = new double [mesh_z-1];
		}
	}

	end_timer(PREPROCESS);
	end_timer(TOTALMAP);
}

bool is_first_call = true;

void solve_proc2nodecoord()
{
	static int solver = options::get().as_int("solver");
	assert((solver == 0) || (solver == 1));

#ifndef METIS51
	if (solver == 0) { // NICSLU
		if (is_first_call) {
			nicslu.factorize();
		}
		else {
			nicslu.update_matrix_diag(&diag[0]);
			nicslu.re_factorize_stable();
		}
		nicslu.solve(&varx[0], &minus_dx[0]);
		nicslu.solve(&vary[0], &minus_dy[0]);
		nicslu.solve(&varz[0], &minus_dz[0]);
	}
	else {
		if (is_first_call) {
			cholmod.factorize();
		}
		else {
			cholmod.update_matrix_diag(&diag[0]);
			cholmod.re_factorize_stable();
		}
		cholmod.solve(&varx[0], &minus_dx[0]);
		cholmod.solve(&vary[0], &minus_dy[0]);
		cholmod.solve(&varz[0], &minus_dz[0]);
	}
#else
	assert(solver == 0);
	if (is_first_call) {
		nicslu.factorize();
	}
	else {
		nicslu.update_matrix_diag(&diag[0]);
		nicslu.re_factorize_stable();
	}
	nicslu.solve(&varx[0], &minus_dx[0]);
	nicslu.solve(&vary[0], &minus_dy[0]);
	nicslu.solve(&varz[0], &minus_dz[0]);
#endif

//	std::copy(varx.begin(), varx.end(), original_varx.begin());
//	std::copy(vary.begin(), vary.end(), original_vary.begin());
//	std::copy(varz.begin(), varz.end(), original_varz.begin());

	if (is_first_call) {
		is_first_call = false;
	}

	for (int i = 0; i < num_procs; i++) {
		int var = proc2var[i];
		if (var != INVALID) {
			int node_x, node_y, node_z;
			node_x = round(varx[var]);
			node_y = round(vary[var]);
			node_z = round(varz[var]);
			assert(node_x >= 0 && node_x <= mesh_x-1);
			assert(node_y >= 0 && node_y <= mesh_y-1);
			assert(node_z >= 0 && node_z <= mesh_z-1);
			proc2nodecoord[i].x = node_x;
			proc2nodecoord[i].y = node_y;
			proc2nodecoord[i].z = node_z;
		}
	}
}

// nodecoord2procvar[i][j][k]->vector of variable ids
void generate_nodecoord2procvar()
{
	for (int i = 0; i < mesh_x; i++) {
 		for (int j = 0; j < mesh_y; j++) {
			for (int k = 0; k < mesh_z; k++) {
				nodecoord2procvar[i][j][k]->clear();
			}
		}
	}

	for (int i = 0; i < num_procs; i++) {
		int node_x, node_y, node_z;
		node_x = proc2nodecoord[i].x;
		node_y = proc2nodecoord[i].y;
		node_z = proc2nodecoord[i].z;
		nodecoord2procvar[node_x][node_y][node_z]->push_back(proc2var[i]);
	}
}

// nodecoord2procvar[i][j][k]->vector of process ids
void regenerate_nodecoord2procvar()
{
	for (int i = 0; i < mesh_x; i++) {
 		for (int j = 0; j < mesh_y; j++) {
			for (int k = 0; k < mesh_z; k++) {
				nodecoord2procvar[i][j][k]->clear();
			}
		}
	}

	for (int i = 0; i < num_procs; i++) {
		int node_x, node_y, node_z;
		node_x = proc2nodecoord[i].x;
		node_y = proc2nodecoord[i].y;
		node_z = proc2nodecoord[i].z;
		nodecoord2procvar[node_x][node_y][node_z]->push_back(i);
	}
}

void compute_max_Ui()
{
	max_Ui = 0;
	for (int i = 0; i < mesh_x; i++) {
 		for (int j = 0; j < mesh_y; j++) {
			for (int k = 0; k < mesh_z; k++) {
				// calculte max_Ui
				int Ui = nodecoord2procvar[i][j][k]->size();
				if (Ui > max_Ui) max_Ui = Ui;
			}
		}
	}
}

void proc_shifting()
{
	for (int i = 0; i < mesh_x; i++) {
 		for (int j = 0; j < mesh_y; j++) {
			for (int k = 0; k < mesh_z; k++) {
				int Ui = nodecoord2procvar[i][j][k]->size();
				// comptue NBx, NBy, NBz
				double OBi_minus1, OBi_plus1;
				double NBi;
				int Ui_plus1;
				// NBx:
				if (i != mesh_x-1) {
					OBi_minus1 = (double)i - 0.5;
					OBi_plus1 = (double)i + 1.5;
					Ui_plus1 = nodecoord2procvar[i+1][j][k]->size();
					NBi = (OBi_minus1*((double)Ui_plus1+delta)+OBi_plus1*((double)Ui+delta))/((double)(Ui+Ui_plus1)+2.0*delta);
					NBx[j][k][i] = NBi;
				}
				// NBy:
				if (j != mesh_y-1) {
					OBi_minus1 = (double)j - 0.5;
					OBi_plus1 = (double)j + 1.5;
					Ui_plus1 = nodecoord2procvar[i][j+1][k]->size();
					NBi = (OBi_minus1*((double)Ui_plus1+delta)+OBi_plus1*((double)Ui+delta))/((double)(Ui+Ui_plus1)+2.0*delta);
					NBy[k][i][j] = NBi;
				}
				// NBz:
				if (k != mesh_z-1) {
					OBi_minus1 = (double)k - 0.5;
					OBi_plus1 = (double)k + 1.5;
					Ui_plus1 = nodecoord2procvar[i][j][k+1]->size();
					NBi = (OBi_minus1*((double)Ui_plus1+delta)+OBi_plus1*((double)Ui+delta))/((double)(Ui+Ui_plus1)+2.0*delta);
					NBz[i][j][k] = NBi;
				}
			}
		}
	}

	// compute new_varx
 	for (int j = 0; j < mesh_y; j++) {
		for (int k = 0; k < mesh_z; k++) {
			for (int i = 0; i < mesh_x; i++) {
				if (nodecoord2procvar[i][j][k]->size() > 0) {
					double OBi, OBi_minus1;
					double NBi, NBi_minus1;
					OBi = (double)i + 0.5;
					OBi_minus1 = (double)i - 0.5;

					if (i == mesh_x-1) NBi = (double)i + 0.5;
					else NBi = NBx[j][k][i];

					if (i == 0) NBi_minus1 = (double)i - 0.5;
					else NBi_minus1 = NBx[j][k][i-1];

					for (std::vector<int>::const_iterator it = nodecoord2procvar[i][j][k]->begin();
						it != nodecoord2procvar[i][j][k]->end(); it++) {
						int var = *it;
						if (var != INVALID) {
							double xj, new_xj;	
							xj = varx[var];
							new_xj = NBi*(xj-OBi_minus1)+NBi_minus1*(OBi-xj);
							new_varx[var] = xj+alpha*(new_xj-xj);
/*							new_xj = xj+alpha*(new_xj-xj);

							if (new_xj < 0)
								new_xj = 0;
							else if (new_xj > (double)(mesh_x-1))
								new_xj = mesh_x-1;

							new_varx[var] = new_xj;*/
						}
					}
				}
			}
		}
	}
	// compute new_vary
	for (int k = 0; k < mesh_z; k++) {
		for (int i = 0; i < mesh_x; i++) {
 			for (int j = 0; j < mesh_y; j++) {
				if (nodecoord2procvar[i][j][k]->size() > 0) {
					double OBi, OBi_minus1;
					double NBi, NBi_minus1;
					OBi = (double)j + 0.5;
					OBi_minus1 = (double)j - 0.5;

					if (j == mesh_y-1) NBi = (double)j + 0.5;
					else NBi = NBy[k][i][j];

					if (j == 0) NBi_minus1 = (double)j - 0.5;
					else NBi_minus1 = NBy[k][i][j-1];

					for (std::vector<int>::const_iterator it = nodecoord2procvar[i][j][k]->begin();
						it != nodecoord2procvar[i][j][k]->end(); it++) {
						int var = *it;
						if (var != INVALID) {
							double xj, new_xj;	
							xj = vary[var];
							new_xj = NBi*(xj-OBi_minus1)+NBi_minus1*(OBi-xj);
							new_vary[var] = xj+alpha*(new_xj-xj);
/*							new_xj = xj+alpha*(new_xj-xj);

							if (new_xj < 0)
								new_xj = 0;
							else if (new_xj > (double)(mesh_y-1))
								new_xj = mesh_y-1;

							new_vary[var] = new_xj;*/
						}
					}
				}
			}
		}
	}
	// compute new_varz
	for (int i = 0; i < mesh_x; i++) {
 		for (int j = 0; j < mesh_y; j++) {
			for (int k = 0; k < mesh_z; k++) {
				if (nodecoord2procvar[i][j][k]->size() > 0) {
					double OBi, OBi_minus1;
					double NBi, NBi_minus1;
					OBi = (double)k + 0.5;
					OBi_minus1 = (double)k - 0.5;

					if (k == mesh_z-1) NBi = (double)k + 0.5;
					else NBi = NBz[i][j][k];

					if (k == 0) NBi_minus1 = (double)k - 0.5;
					else NBi_minus1 = NBz[i][j][k-1];

					for (std::vector<int>::const_iterator it = nodecoord2procvar[i][j][k]->begin();
						it != nodecoord2procvar[i][j][k]->end(); it++) {
						int var = *it;
						if (var != INVALID) {
							double xj, new_xj;	
							xj = varz[var];
							new_xj = NBi*(xj-OBi_minus1)+NBi_minus1*(OBi-xj);
							new_varz[var] = xj+alpha*(new_xj-xj);
/*							new_xj = xj+alpha*(new_xj-xj);

							if (new_xj < 0)
								new_xj = 0;
							else if (new_xj > (double)(mesh_z-1))
								new_xj = mesh_z-1;

							new_varz[var] = new_xj;*/
						}
					}
				}
			}
		}
	}
}

// update diag, minus_dx, minus_dy, minus_dz
void add_spreading_forces()
{
	for (int i = 0; i < num_procs; i++) {
		int var = proc2var[i];
		if (var != INVALID) {
			double pFx = 0;
			double pFy = 0;
			double pFz = 0;
			// compute resultant force (pFx, pFy, pFz)
			for (int j = comm_off_diag_p[i]; j < comm_off_diag_p[i+1]; j++) {
				int other_proc = comm_off_diag_i[j];
				int other_var = proc2var[other_proc];
				double spring_constant = comm_off_diag_x[j];
				double other_x, other_y, other_z;
				if (other_var != INVALID) {
					//other_x = original_varx[other_var];
					//other_y = original_vary[other_var];
					//other_z = original_varz[other_var];
					other_x = varx[other_var];
					other_y = vary[other_var];
					other_z = varz[other_var];
					pFx += spring_constant*(new_varx[var]-other_x);
					pFy += spring_constant*(new_vary[var]-other_y);
					pFz += spring_constant*(new_varz[var]-other_z);
				}
				//else {
				//	other_x = proc2nodecoord[other_proc].x;
				//	other_y = proc2nodecoord[other_proc].y;
				//	other_z = proc2nodecoord[other_proc].z;
				//}
				//pFx += spring_constant*(new_varx[var]-other_x);
				//pFy += spring_constant*(new_vary[var]-other_y);
				//pFz += spring_constant*(new_varz[var]-other_z);
			}
			// compute pseudo-pin position
			double pseudo_pin_x;
			double pseudo_pin_y;
			double pseudo_pin_z;
			double ratio_x, ratio_y, ratio_z;
			double min_ratio = 0;

			if (pFx > 0) ratio_x = fabs((((double)mesh_x-0.5)-new_varx[var])/pFx);
			else if (pFx < 0) ratio_x = fabs((new_varx[var]+0.5)/pFx);
			else ratio_x = -1.0; // -1 means invalid

			if (pFy > 0) ratio_y = fabs((((double)mesh_y-0.5)-new_vary[var])/pFy);
			else if (pFy < 0) ratio_y = fabs((new_vary[var]+0.5)/pFy);
			else ratio_y = -1.0; // -1 means invalid

			if (pFz > 0) ratio_z = fabs((((double)mesh_z-0.5)-new_varz[var])/pFz);
			else if (pFz < 0) ratio_z = fabs((new_varz[var]+0.5)/pFz);
			else ratio_z = -1.0; // -1 means invalid

/*
			if (pFx > 0) ratio_x = fabs(((double)(mesh_x-1)-new_varx[var])/pFx);
			else if (pFx < 0) ratio_x = fabs(new_varx[var]/pFx);
			else ratio_x = -1.0; // -1 means invalid

			if (pFy > 0) ratio_y = fabs(((double)(mesh_y-1)-new_vary[var])/pFy);
			else if (pFy < 0) ratio_y = fabs(new_vary[var]/pFy);
			else ratio_y = -1.0; // -1 means invalid

			if (pFz > 0) ratio_z = fabs(((double)(mesh_z-1)-new_varz[var])/pFz);
			else if (pFz < 0) ratio_z = fabs(new_varz[var]/pFz);
			else ratio_z = -1.0; // -1 means invalid
*/

			if (ratio_x != -1.0) min_ratio = ratio_x;
			if (ratio_y != -1.0) {
				if (min_ratio > 0) min_ratio = std::min(min_ratio, ratio_y);
				else min_ratio = ratio_y;
			}
			if (ratio_z != -1.0) {
				if (min_ratio > 0) min_ratio = std::min(min_ratio, ratio_z);
				else min_ratio = ratio_z;
			}

			assert(min_ratio >= 0);

			if (min_ratio > 0) {
				pseudo_pin_x = new_varx[var]+min_ratio*pFx;
				pseudo_pin_y = new_vary[var]+min_ratio*pFy;
				pseudo_pin_z = new_varz[var]+min_ratio*pFz;
				double added_spring_constant = 1.0/min_ratio;

				//diag[var] = original_diag[var]+added_spring_constant;
				//minus_dx[var] = original_minus_dx[var]+added_spring_constant*pseudo_pin_x;
				//minus_dy[var] = original_minus_dy[var]+added_spring_constant*pseudo_pin_y;
				//minus_dz[var] = original_minus_dz[var]+added_spring_constant*pseudo_pin_z;

				diag[var] = sum_off_diag[var]+added_spring_constant;
				minus_dx[var] = added_spring_constant*pseudo_pin_x;
				minus_dy[var] = added_spring_constant*pseudo_pin_y;
				minus_dz[var] = added_spring_constant*pseudo_pin_z;

				// The following code is wrong:
				//diag[var] = diag[var]+added_spring_constant;
				//minus_dx[var] = minus_dx[var]+added_spring_constant*pseudo_pin_x;
				//minus_dy[var] = minus_dy[var]+added_spring_constant*pseudo_pin_y;
				//minus_dz[var] = minus_dz[var]+added_spring_constant*pseudo_pin_z;

			#ifndef NDEBUG
				fprintf(stdout, "var %d, add spring force %f, new position @(%f,%f,%f), pseudo pin @ (%f,%f,%f)\n",
					var, added_spring_constant, new_varx[var], new_vary[var], new_varz[var],
					pseudo_pin_x, pseudo_pin_y, pseudo_pin_z);
			#endif
			}
		}
	}
}

int compute_proc_hop_distance(int proc1, int proc2)
{
//	int dis = abs(proc2nodecoord[proc1].x-proc2nodecoord[proc2].x)
//			+ abs(proc2nodecoord[proc1].y-proc2nodecoord[proc2].y)
//			+ abs(proc2nodecoord[proc1].z-proc2nodecoord[proc2].z);

	int dis = estimate_coordinate_distance(proc2nodecoord[proc1].x, proc2nodecoord[proc2].x, mesh_x)
			+ estimate_coordinate_distance(proc2nodecoord[proc1].y, proc2nodecoord[proc2].y, mesh_y)
			+ estimate_coordinate_distance(proc2nodecoord[proc1].z, proc2nodecoord[proc2].z, mesh_z);

	return dis; 
}

size_t compute_hop_bytes()
{
	size_t hop_bytes = 0;
	for (int i = 0; i < num_procs; i++) {
		for (int j = comm_off_diag_p[i]; j < comm_off_diag_p[i+1]; j++) {
			int bytes = comm_off_diag_x[j];
			int proc = comm_off_diag_i[j];
			int hop = compute_proc_hop_distance(i, proc);
			hop_bytes += hop * bytes;
		}
	}

	hop_bytes /= 2; // each edge will be counted twice

	return hop_bytes;
}

int compute_max_hop()
{
	int max_hop = 0;
	for (int i = 0; i < num_procs; i++) {
		for (int j = comm_off_diag_p[i]; j < comm_off_diag_p[i+1]; j++) {
			int proc = comm_off_diag_i[j];
			int hop = compute_proc_hop_distance(i, proc);
			if (hop > max_hop) max_hop = hop;
		}
	}

	return max_hop;
}

std::vector<int> default_proc2node;

// generate proc2node for the default TXYZ mapping on BG/P
// based on the partitioned communication graph
void generate_default_proc2node()
{
	default_proc2node.clear();
	for (int z = 0; z < mesh_z; z++) {
		for (int y = 0; y < mesh_y; y++) {
			for (int x = 0; x < mesh_x; x++) {
				default_proc2node.push_back(compute_node_id(x, y, z));
			}
		}
	}
}

size_t compute_default_hop_bytes()
{
	if (default_proc2node.empty())
		generate_default_proc2node();

	size_t hop_bytes = 0;
	for (int i = 0; i < num_procs; i++) {
		for (int j = comm_off_diag_p[i]; j < comm_off_diag_p[i+1]; j++) {
			int bytes = comm_off_diag_x[j];
			int proc = comm_off_diag_i[j];
			int hop = compute_node_hop_distance(default_proc2node[i], default_proc2node[proc]);
			hop_bytes += hop * bytes;
		}
	}

	hop_bytes /= 2; // each edge will be counted twice

	return hop_bytes;
}

int compute_default_max_hop()
{
	if (default_proc2node.empty())
		generate_default_proc2node();

	int max_hop = 0;
	for (int i = 0; i < num_procs; i++) {
		for (int j = comm_off_diag_p[i]; j < comm_off_diag_p[i+1]; j++) {
			int proc = comm_off_diag_i[j];
			int hop = compute_node_hop_distance(default_proc2node[i], default_proc2node[proc]);
			if (hop > max_hop) max_hop = hop;
		}
	}

	return max_hop;
}

std::vector<int> original_proc2node;

// generate proc2node for the original TXYZ mapping on BG/P
// based on the original communication graph
void generate_original_proc2node()
{
	original_proc2node.clear();
	assert(num_procs_per_node >= 1);

	for (int z = 0; z < mesh_z; z++) {
		for (int y = 0; y < mesh_y; y++) {
			for (int x = 0; x < mesh_x; x++) {
				int node_id = compute_node_id(x, y, z);
				for (int i = 0; i < num_procs_per_node; i++) {
					original_proc2node.push_back(node_id);
				}
			}
		}
	}

	assert(original_proc2node.size() == (size_t)original_num_procs);
}

size_t compute_original_hop_bytes()
{
	if (original_proc2node.empty())
		generate_original_proc2node();

	size_t hop_bytes = 0;
	for (int i = 0; i < original_num_procs; i++) {
		for (int j = total_comm_off_diag_p[i]; j < total_comm_off_diag_p[i+1]; j++) {
			int bytes = total_comm_off_diag_x[j];
			int proc = total_comm_off_diag_i[j];
			int hop = compute_node_hop_distance(original_proc2node[i], original_proc2node[proc]);
			hop_bytes += hop * bytes;
		}
	}

	hop_bytes /= 2; // each edge will be counted twice

	return hop_bytes;
}

int compute_original_max_hop()
{
	if (original_proc2node.empty())
		generate_original_proc2node();

	int max_hop = 0;
	for (int i = 0; i < original_num_procs; i++) {
		for (int j = total_comm_off_diag_p[i]; j < total_comm_off_diag_p[i+1]; j++) {
			int proc = total_comm_off_diag_i[j];
			int hop = compute_node_hop_distance(original_proc2node[i], original_proc2node[proc]);
			if (hop > max_hop) max_hop = hop;
		}
	}

	return max_hop;
}

size_t compute_original_bytes()
{
	assert(total_comm_off_diag_x.size() > 0);

	size_t bytes = 0;
	for (size_t i = 0; i < total_comm_off_diag_x.size(); i++)
		bytes += total_comm_off_diag_x[i];

	fprintf(stdout, "\noriginal_bytes = %ld\n", bytes);
	bytes /= 2; // each edge appears twice

	return bytes;
}

void legalization_by_process_shifting()
{
	alpha = 1;

	int i = 1;
	while (1) {
		proc_shifting();
		std::copy(new_varx.begin(), new_varx.end(), varx.begin());
		std::copy(new_vary.begin(), new_vary.end(), vary.begin());
		std::copy(new_varz.begin(), new_varz.end(), varz.begin());

		for (int i = 0; i < num_procs; i++) {
			int var = proc2var[i];
			if (var != INVALID) {
				int node_x, node_y, node_z;
				node_x = round(varx[var]);
				node_y = round(vary[var]);
				node_z = round(varz[var]);
				assert(node_x >= 0 && node_x <= mesh_x-1);
				assert(node_y >= 0 && node_y <= mesh_y-1);
				assert(node_z >= 0 && node_z <= mesh_z-1);
				proc2nodecoord[i].x = node_x;
				proc2nodecoord[i].y = node_y;
				proc2nodecoord[i].z = node_z;
			}
		}

		size_t hop_bytes = compute_hop_bytes();
		generate_nodecoord2procvar();
		compute_max_Ui();

		fprintf(stdout, "iter %d: max_Ui = %d, hop_bytes = %ld\n",
			i, max_Ui, hop_bytes);

		if (max_Ui <= 1) break;
		else i++;
	}
}

int compute_node_id(int x, int y, int z)
{
	assert(x >= 0 && x < mesh_x);
	assert(y >= 0 && y < mesh_y);
	assert(z >= 0 && z < mesh_z);

	int id;
	id = x*(mesh_y*mesh_z)+y*mesh_z+z;
	return id;
}

void migrate_one_process(int node, int other_node)
{
	coordinates coord = compute_coordinates(node);
	coordinates other_coord = compute_coordinates(other_node);

	// compute migration cost based on current (infeasible) mapping
	std::vector<int> migration_cost;
	std::vector<int>* node2proc = nodecoord2procvar[coord.x][coord.y][coord.z];
	std::vector<int>* other_node2proc = nodecoord2procvar[other_coord.x][other_coord.y][other_coord.z];
	migration_cost.reserve(node2proc->size());

	for (std::vector<int>::const_iterator it = node2proc->begin();
		it != node2proc->end(); it++) {
		int proc = *it;
		int cost = 0;
		for (int offset = comm_off_diag_p[proc]; offset < comm_off_diag_p[proc+1]; offset++) {
			int bytes = comm_off_diag_x[offset];
			int other_proc = comm_off_diag_i[offset];
/*			int original_hop = abs(coord.x-proc2nodecoord[other_proc].x)
				+ abs(coord.y-proc2nodecoord[other_proc].y)
				+ abs(coord.z-proc2nodecoord[other_proc].z);
			int new_hop = abs(other_coord.x-proc2nodecoord[other_proc].x)
				+ abs(other_coord.y-proc2nodecoord[other_proc].y)
				+ abs(other_coord.z-proc2nodecoord[other_proc].z);
*/
			// we need to consider torus topology
			int original_hop = estimate_hop_distance(coord, proc2nodecoord[other_proc]);
			int new_hop = estimate_hop_distance(other_coord, proc2nodecoord[other_proc]);
			cost += (new_hop-original_hop)*bytes; // the increase of hop-bytes
		}
		migration_cost.push_back(cost);
	}

	// identify the process with the minimum cost for migration
	assert(node2proc->size() == migration_cost.size());
	int migration_proc = *(node2proc->begin()
		+(std::min_element(migration_cost.begin(), migration_cost.end())
		-migration_cost.begin()));

	// perform process migration
	other_node2proc->push_back(migration_proc); // map to the other node 
	for (std::vector<int>::iterator it = node2proc->begin();
		it != node2proc->end(); it++) {
		if ((*it) == migration_proc) {
			node2proc->erase(it);
			break;
		}
	}
	proc2nodecoord[migration_proc].x = other_coord.x;
	proc2nodecoord[migration_proc].y = other_coord.y;
	proc2nodecoord[migration_proc].z = other_coord.z;

#ifndef NDEBUG
	fprintf(stdout, "process %d @ node (%d,%d,%d) -> node (%d,%d,%d)\n",
		migration_proc, coord.x, coord.y, coord.z,
		other_coord.x, other_coord.y, other_coord.z);
#endif
}

typedef std::pair<int, double> neighbor_potential;

std::vector<int> potentials;
std::vector<double> x;
//std::vector<std::pair<int, double>> neighbor_potential_diff;
std::vector<neighbor_potential> neighbor_potential_diff;

bool mycompare(int i, int j) {return (x[i]>x[j]);}
bool mycomparepotdiff(int i, int j)
{return (neighbor_potential_diff[i].second>neighbor_potential_diff[j].second);}

void compute_potentials()
{
	// This is not real Laplacian matrix, it is obtained by removing the
	// last row and the last column of laplacian matrix. It is of size
	// (num_procs-1)x(num_procs-1).
	std::vector<double> Laplacian_off_diag_x;
	std::vector<int> Laplacian_off_diag_i;
	std::vector<int> Laplacian_off_diag_p;
	std::vector<double> degrees;
	std::vector<double> b;

	Laplacian_off_diag_x.clear();
	Laplacian_off_diag_i.clear();
	Laplacian_off_diag_p.clear();
	degrees.clear();
	x.clear();
	b.clear();

	Laplacian_off_diag_x.reserve(6*num_procs);
	Laplacian_off_diag_i.reserve(6*num_procs);
	Laplacian_off_diag_p.reserve(6*num_procs);
	degrees.reserve(num_procs);
	x.assign(num_procs, 0);
	b.reserve(num_procs);

	potentials.assign(num_procs, 0);

	for (int i = 0; i < mesh_x; i++) {
		for (int j = 0; j < mesh_y; j++) {
			for (int k = 0; k < mesh_z; k++) {

				Laplacian_off_diag_p.push_back(Laplacian_off_diag_x.size());
				int degree = 0;

				if (i != 0) {
					Laplacian_off_diag_i.push_back(compute_node_id(i-1, j, k));
					Laplacian_off_diag_x.push_back(1);
					degree++;
				}
				if (j != 0) {
					Laplacian_off_diag_i.push_back(compute_node_id(i, j-1, k));
					Laplacian_off_diag_x.push_back(1);
					degree++;
				}
				if (k != 0) {
					Laplacian_off_diag_i.push_back(compute_node_id(i, j, k-1));
					Laplacian_off_diag_x.push_back(1);
					degree++;
				}
				if (k != mesh_z-1) {
					degree++;
					int id = compute_node_id(i, j, k+1);
					if (id != num_procs-1) {
						Laplacian_off_diag_i.push_back(id);
						Laplacian_off_diag_x.push_back(1);
					}
				}
				if (j != mesh_y-1) {
					degree++;
					int id = compute_node_id(i, j+1, k);
					if (id != num_procs-1) {
						Laplacian_off_diag_i.push_back(id);
						Laplacian_off_diag_x.push_back(1);
					}
				}
				if (i != mesh_x-1) {
					degree++;
					int id = compute_node_id(i+1, j, k);
					if (id != num_procs-1) {
						Laplacian_off_diag_i.push_back(id);
						Laplacian_off_diag_x.push_back(1);
					}
				}

				degrees.push_back((double)degree);

				int proc_cnt = nodecoord2procvar[i][j][k]->size();
				double diff = proc_cnt-1; 
				b.push_back(diff);
			}
		}
	}

	Laplacian_off_diag_p.push_back(Laplacian_off_diag_x.size());
	assert(Laplacian_off_diag_p.size() == (size_t)(num_procs+1));
	assert(degrees.size() == (size_t)(num_procs));

	lu_nics Laplacian_lu;
	Laplacian_lu.load_matrix(num_procs-1, Laplacian_off_diag_p[num_procs-1]+num_procs-1,
		&Laplacian_off_diag_x[0], &Laplacian_off_diag_i[0], &Laplacian_off_diag_p[0],
		&degrees[0]);
	Laplacian_lu.factorize();

	int iter = 1;
	while (1) {
#ifndef NDEBUG
	fprintf(stdout, "iter %d:\n", iter);
#endif
	Laplacian_lu.solve(&x[0], &b[0]);

	bool error = false;

	std::vector<int> indices;
	indices.clear();
	indices.reserve(num_procs);
	for (int i = 0; i < num_procs; i++) {
		indices.push_back(i);
	}

	std::sort(indices.begin(), indices.end(), mycompare);

	std::vector<int> out_cnt(num_procs, 0);

	for (int i = 0; i < num_procs; i++) {

		int node = indices[i];
		int out = (int)b[node]; // shift out count
		neighbor_potential_diff.clear();
		std::vector<int> local_indices;
		for (int j = Laplacian_off_diag_p[node]; j < Laplacian_off_diag_p[node+1]; j++) {
			local_indices.push_back(neighbor_potential_diff.size());
			neighbor_potential_diff.push_back(std::make_pair(Laplacian_off_diag_i[j], x[node]-x[Laplacian_off_diag_i[j]]));
		}
		int degree = (int)degrees[node];
		if (degree > Laplacian_off_diag_p[node+1]-Laplacian_off_diag_p[node]) {
			local_indices.push_back(neighbor_potential_diff.size());
			neighbor_potential_diff.push_back(std::make_pair(num_procs-1, x[node]));
		}
		std::sort(local_indices.begin(), local_indices.end(), mycomparepotdiff);

		int local_out_cnt = out_cnt[node];
		int index = 0;
		while ((local_out_cnt < out) && ((size_t)index < local_indices.size())) {
			if (neighbor_potential_diff[local_indices[index]].second > 0) {
				int move_cnt = std::min(out-local_out_cnt, (int)floor(neighbor_potential_diff[local_indices[index]].second));
				if (move_cnt <= 0) {
					break;
				}
				neighbor_potential_diff[local_indices[index]].second -= move_cnt;
				int other_node = neighbor_potential_diff[local_indices[index]].first;
				out_cnt[other_node] -= move_cnt;
				index++;
				local_out_cnt += move_cnt;

				while (move_cnt > 0) {
					//fprintf(stderr, "phase 1: call migrate_one_process\n");
					migrate_one_process(node, other_node);
					//fprintf(stderr, "finish migrate_one_process\n");
					move_cnt--;
				}
			}
			else {
				break;
			}
		}
		std::sort(local_indices.begin(), local_indices.end(), mycomparepotdiff);
		index = 0;
		//fprintf(stderr, "local_indices size = %d\n", local_indices.size());
		while ((local_out_cnt < out) && ((size_t)index < local_indices.size())) {
			//fprintf(stderr, "local_out_cnt = %d, out = %d, index = %d\n",
			//	local_out_cnt, out, index);
			int move_cnt = std::min(out-local_out_cnt, round(neighbor_potential_diff[local_indices[index]].second));
			//fprintf(stderr, "move_cnt = %d\n", move_cnt);
			if (move_cnt < 0) {
				break;
			}
			else if (move_cnt == 0) {
				if (neighbor_potential_diff[local_indices[index]].second > 0)
				move_cnt = 1;
				else {
				#ifndef NDEBUG
					fprintf(stdout, "Warning: current local_out_cnt = %d, out = %d, but neighbor_potential_diff[%d] = %f\n",
						local_out_cnt, out, local_indices[index], neighbor_potential_diff[local_indices[index]].second);
					break;
				#endif
				}
			}
			int other_node = neighbor_potential_diff[local_indices[index]].first;
			out_cnt[other_node] -= move_cnt;
			index++;
			local_out_cnt += move_cnt;

			while (move_cnt > 0) {
				//fprintf(stderr, "phase 2: call migrate_one_process\n");
				migrate_one_process(node, other_node);
				//fprintf(stderr, "finish migrate_one_process\n");
				move_cnt--;
			}
		}

		if ((double)local_out_cnt != b[node]) {
		#ifndef NDEBUG
			fprintf(stdout, "Warning: local_out_cnt[%d] = %d, b[%d] = %f\n",
				node, local_out_cnt, node, b[node]);
		#endif
			error = true;
		}

		b[node] -= (double)local_out_cnt;
	}

	int total_b = 0;
	for (int i = 0; i < num_procs; i++) {
		total_b += (int)b[i];
	}
	assert(total_b == 0);

	if (!error) {
		fprintf(stdout, "feasible solution obtained in %d iterations!\n",
			iter);
		break;
	}
	iter++;
	}
}

void legalization_by_process_migration()
{
	// flag for BFS
	bool ***visited;
	visited = new bool** [mesh_x];
	for (int i = 0; i < mesh_x; i++) {
		visited[i] = new bool* [mesh_y];
 		for (int j = 0; j < mesh_y; j++) {
			visited[i][j] = new bool [mesh_z];
		}
	}

	for (int i = 0; i < mesh_x; i++) {
		for (int j = 0; j < mesh_y; j++) {
			for (int k = 0; k < mesh_z; k++) {
				visited[i][j][k] = false;
			}
		}
	}

	// perform BFS from an empty node and move a process from
	// a nearest overloaded process to the empty node. Note that
	// we should move the proper process, which results in the
	// minimum hop-bytes.
	for (int i = 0; i < mesh_x; i++) {
		for (int j = 0; j < mesh_y; j++) {
			for (int k = 0; k < mesh_z; k++) {
				if (nodecoord2procvar[i][j][k]->size() == 0) {
					// perform BFS to find the nearest overloaded nodes
					std::list<coordinates>* Q_current;
					std::list<coordinates>* Q_next;
					Q_current = new std::list<coordinates>;
					Q_next = new std::list<coordinates>;
					Q_current->clear();
					Q_next->clear();

					coordinates coord;
					coord.x = i;
					coord.y = j;
					coord.z = k;
					Q_current->push_back(coord);

					std::vector<coordinates> overloaded_nodes;

					int dis = 1;
					while (1) {
						bool found = false;
						while (!Q_current->empty()) {
							coordinates current_node = Q_current->front();
							Q_current->pop_front();
							coordinates neighbor_node;
							for (int direction = 0; direction < 6; direction++) {
								neighbor_node = current_node;
								switch (direction) {
									case 0: // x-1
										if (neighbor_node.x != 0) neighbor_node.x--;
										else continue;
										break;
									case 1: // x+1
										if (neighbor_node.x != mesh_x-1) neighbor_node.x++;
										else continue;
										break;
									case 2: // y-1
										if (neighbor_node.y != 0) neighbor_node.y--;
										else continue;
										break;
									case 3: // y+1
										if (neighbor_node.y != mesh_y-1) neighbor_node.y++;
										else continue;
										break;
									case 4: // z-1
										if (neighbor_node.z != 0) neighbor_node.z--;
										else continue;
										break;
									case 5: // z+1
										if (neighbor_node.z != mesh_z-1) neighbor_node.z++;
										else continue;
										break;
									default:
										fprintf(stderr, "ERROR: infeasible search direction!\n");
										exit(-1);
								}
								int distance = abs(neighbor_node.x-i)
									+ abs(neighbor_node.y-j)
									+ abs(neighbor_node.z-k);
								if (dis == distance) {
									if (!visited[neighbor_node.x][neighbor_node.y][neighbor_node.z]) {
										visited[neighbor_node.x][neighbor_node.y][neighbor_node.z] = true;
										Q_next->push_back(neighbor_node);
										if (nodecoord2procvar[neighbor_node.x][neighbor_node.y][neighbor_node.z]->size() > 1) {
											found = true;
											overloaded_nodes.push_back(neighbor_node);
										}
									}
								}
							}
						}
						assert(Q_current->empty());
						assert(!Q_next->empty());

						// reset BFS flag
						for (std::list<coordinates>::const_iterator it = Q_next->begin();
							it != Q_next->end(); it++) {
								visited[(*it).x][(*it).y][(*it).z] = false;
						}

						if (found) {
							assert(!overloaded_nodes.empty());
							break;
						}
						else {
							dis++;
							assert(overloaded_nodes.empty());
							std::list<coordinates>* temp;
							temp = Q_current;
							Q_current = Q_next;
							Q_next = temp;
						}
					}
					Q_current->~list();
					Q_next->~list();

					// identify candidate variables for migration
					std::vector<int> candidate_procs;
					for (std::vector<coordinates>::const_iterator it = overloaded_nodes.begin();
						it != overloaded_nodes.end(); it++) {
						for (std::vector<int>::const_iterator pit = nodecoord2procvar[(*it).x][(*it).y][(*it).z]->begin();
							pit != nodecoord2procvar[(*it).x][(*it).y][(*it).z]->end(); pit++) {
							candidate_procs.push_back(*pit);
						}
					}

					// compute migration cost based on current (infeasible) mapping
					std::vector<int> migration_cost;
					migration_cost.reserve(candidate_procs.size());

					for (std::vector<int>::const_iterator it = candidate_procs.begin();
						it != candidate_procs.end(); it++) {
						int proc = *it;
						int cost = 0;
						for (int offset = comm_off_diag_p[proc]; offset < comm_off_diag_p[proc+1]; offset++) {
							int bytes = comm_off_diag_x[offset];
							int other_proc = comm_off_diag_i[offset];
							int original_hop = abs(proc2nodecoord[proc].x-proc2nodecoord[other_proc].x)
												+ abs(proc2nodecoord[proc].y-proc2nodecoord[other_proc].y)
												+ abs(proc2nodecoord[proc].z-proc2nodecoord[other_proc].z);
							int new_hop = abs(i-proc2nodecoord[other_proc].x)
												+ abs(j-proc2nodecoord[other_proc].y)
												+ abs(k-proc2nodecoord[other_proc].z);
							cost += (new_hop-original_hop)*bytes;
						}
						migration_cost.push_back(cost);
					}

					// identify the process with the minimum cost for migration
					assert(candidate_procs.size() == migration_cost.size());
					int migration_proc = *(candidate_procs.begin()
										+(std::min_element(migration_cost.begin(), migration_cost.end())
										-migration_cost.begin()));

					// perform process migration
					nodecoord2procvar[i][j][k]->push_back(migration_proc); // map to current empty node
					int migration_proc_x = proc2nodecoord[migration_proc].x;
					int migration_proc_y = proc2nodecoord[migration_proc].y;
					int migration_proc_z = proc2nodecoord[migration_proc].z;
					for (std::vector<int>::iterator it
						= nodecoord2procvar[migration_proc_x][migration_proc_y][migration_proc_z]->begin();
						it != nodecoord2procvar[migration_proc_x][migration_proc_y][migration_proc_z]->end();
						it++) {
						if ((*it) == migration_proc) {
							nodecoord2procvar[migration_proc_x][migration_proc_y][migration_proc_z]->erase(it);
							break;
						}
					}
					proc2nodecoord[migration_proc].x = i;
					proc2nodecoord[migration_proc].y = j;
					proc2nodecoord[migration_proc].z = k;

					fprintf(stdout, "process %d @ node (%d,%d,%d) -> node (%d,%d,%d), distance = %d\n",
						migration_proc, migration_proc_x, migration_proc_y, migration_proc_z, i, j, k, dis);
				}
			}
		}
	}
}

// select one process for migration during iterative local refinement
// This function returns the id of the selected process. If there is no propoer
// process for migration, then it returns -1.

typedef std::pair<int, int> migrate_process_cost;

migrate_process_cost select_one_process_for_migration(coordinates &coord, coordinates &other_coord)
{
	// compute migration cost based on current (infeasible) mapping
	std::vector<int> migration_cost;
	std::vector<int>* node2proc = nodecoord2procvar[coord.x][coord.y][coord.z];
	//std::vector<int>* other_node2proc = nodecoord2procvar[other_coord.x][other_coord.y][other_coord.z];
	migration_cost.reserve(node2proc->size());

	for (std::vector<int>::const_iterator it = node2proc->begin();
		it != node2proc->end(); it++) {

		int proc = *it;
		int cost = 0;

		if (proc2var[proc] == INVALID) { // must be a pinned process
			cost = 1; // set the cost to a positive value 
		}	
		else {
			for (int offset = comm_off_diag_p[proc]; offset < comm_off_diag_p[proc+1]; offset++) {
				int bytes = comm_off_diag_x[offset];
				int other_proc = comm_off_diag_i[offset];
				int original_hop = estimate_hop_distance(coord, proc2nodecoord[other_proc]);
				int new_hop = estimate_hop_distance(other_coord, proc2nodecoord[other_proc]);
				cost += (new_hop-original_hop)*bytes; // the increase of hop-bytes
			}
		}

		migration_cost.push_back(cost);
	}

	// identify the process with the minimum cost for migration
	assert(node2proc->size() == migration_cost.size());

	std::vector<int>::iterator min_iter = std::min_element(migration_cost.begin(), migration_cost.end());
	int min_cost = *min_iter;
	int min_proc = *(node2proc->begin() + (min_iter - migration_cost.begin()));

	return std::make_pair(min_cost, min_proc);
}

bool local_refinement(int node)
{
	coordinates current_node = compute_coordinates(node);
	coordinates neighbor_node;

	std::vector<int>* node2proc = nodecoord2procvar[current_node.x][current_node.y][current_node.z];

	int min_direction = -1; // INVALID
	migrate_process_cost min_proc_cost;
	migrate_process_cost proc_cost;
	for (int direction = 0; direction < 6; direction++) {
		neighbor_node = current_node;
		switch (direction) {
			case 0: // x-1
				if (neighbor_node.x != 0) {
					neighbor_node.x--;
					if (node2proc->size() > nodecoord2procvar[neighbor_node.x][neighbor_node.y][neighbor_node.z]->size()) {
						proc_cost = select_one_process_for_migration(current_node, neighbor_node);
						if (proc_cost.first < 0) { // a feasible move
							min_direction = direction;
							min_proc_cost = proc_cost;
						}
					}
				}
				else continue;
				break;
			case 1: // x+1
				if (neighbor_node.x != mesh_x-1) {
					neighbor_node.x++;
					if (node2proc->size() > nodecoord2procvar[neighbor_node.x][neighbor_node.y][neighbor_node.z]->size()) {
						proc_cost = select_one_process_for_migration(current_node, neighbor_node);
						if (min_direction == -1) { // feasible move not found yet
							if (proc_cost.first < 0) { // a feasible move
								min_direction = direction;
								min_proc_cost = proc_cost;
							}
						}
						else if (proc_cost.first < min_proc_cost.first) {
							min_direction = direction;
							min_proc_cost = proc_cost;
						}
					}
				}
				else continue;
				break;
			case 2: // y-1
				if (neighbor_node.y != 0) {
					neighbor_node.y--;
					if (node2proc->size() > nodecoord2procvar[neighbor_node.x][neighbor_node.y][neighbor_node.z]->size()) {
						proc_cost = select_one_process_for_migration(current_node, neighbor_node);
						if (min_direction == -1) { // feasible move not found yet
							if (proc_cost.first < 0) { // a feasible move
								min_direction = direction;
								min_proc_cost = proc_cost;
							}
						}
						else if (proc_cost.first < min_proc_cost.first) {
							min_direction = direction;
							min_proc_cost = proc_cost;
						}
					}
				}
				else continue;
				break;
			case 3: // y+1
				if (neighbor_node.y != mesh_y-1) {
					neighbor_node.y++;
					if (node2proc->size() > nodecoord2procvar[neighbor_node.x][neighbor_node.y][neighbor_node.z]->size()) {
						proc_cost = select_one_process_for_migration(current_node, neighbor_node);
						if (min_direction == -1) { // feasible move not found yet
							if (proc_cost.first < 0) { // a feasible move
								min_direction = direction;
								min_proc_cost = proc_cost;
							}
						}
						else if (proc_cost.first < min_proc_cost.first) {
							min_direction = direction;
							min_proc_cost = proc_cost;
						}
					}
				}
				else continue;
				break;
			case 4: // z-1
				if (neighbor_node.z != 0) {
					neighbor_node.z--;
					if (node2proc->size() > nodecoord2procvar[neighbor_node.x][neighbor_node.y][neighbor_node.z]->size()) {
						proc_cost = select_one_process_for_migration(current_node, neighbor_node);
						if (min_direction == -1) { // feasible move not found yet
							if (proc_cost.first < 0) { // a feasible move
								min_direction = direction;
								min_proc_cost = proc_cost;
							}
						}
						else if (proc_cost.first < min_proc_cost.first) {
							min_direction = direction;
							min_proc_cost = proc_cost;
						}
					}
				}
				else continue;
				break;
			case 5: // z+1
				if (neighbor_node.z != mesh_z-1) {
					neighbor_node.z++;
					if (node2proc->size() > nodecoord2procvar[neighbor_node.x][neighbor_node.y][neighbor_node.z]->size()) {
						proc_cost = select_one_process_for_migration(current_node, neighbor_node);
						if (min_direction == -1) { // feasible move not found yet
							if (proc_cost.first < 0) { // a feasible move
								min_direction = direction;
								min_proc_cost = proc_cost;
							}
						}
						else if (proc_cost.first < min_proc_cost.first) {
							min_direction = direction;
							min_proc_cost = proc_cost;
						}
					}
				}
				else continue;
				break;
			default:
				fprintf(stderr, "ERROR: infeasible search direction!\n");
				exit(-1);
		}
	}

	// migrate one process
	int migration_proc = min_proc_cost.second;
	if (min_direction != -1) {
		neighbor_node = current_node;
		switch (min_direction) {
			case 0: // x-1
				if (neighbor_node.x != 0) {
					neighbor_node.x--;
					varx[proc2var[migration_proc]] -= 1;
					proc2nodecoord[migration_proc].x = neighbor_node.x;
				}
				break;
			case 1: // x+1
				if (neighbor_node.x != mesh_x-1) {
					neighbor_node.x++;
					varx[proc2var[migration_proc]] += 1;
					proc2nodecoord[migration_proc].x = neighbor_node.x;
				}
				break;
			case 2: // y-1
				if (neighbor_node.y != 0) {
					neighbor_node.y--;
					vary[proc2var[migration_proc]] -= 1;
					proc2nodecoord[migration_proc].y = neighbor_node.y;
				}
				break;
			case 3: // y+1
				if (neighbor_node.y != mesh_y-1) {
					neighbor_node.y++;
					vary[proc2var[migration_proc]] += 1;
					proc2nodecoord[migration_proc].y = neighbor_node.y;
				}
				break;
			case 4: // z-1
				if (neighbor_node.z != 0) {
					neighbor_node.z--;
					varz[proc2var[migration_proc]] -= 1;
					proc2nodecoord[migration_proc].z = neighbor_node.z;
				}
				break;
			case 5: // z+1
				if (neighbor_node.z != mesh_z-1) {
					neighbor_node.z++;
					varz[proc2var[migration_proc]] += 1;
					proc2nodecoord[migration_proc].z = neighbor_node.z;
				}
				break;
			default:
				fprintf(stderr, "ERROR: infeasible migration direction!\n");
				exit(-1);
		}
	}
	else {
		return false;
	}

	nodecoord2procvar[neighbor_node.x][neighbor_node.y][neighbor_node.z]->push_back(migration_proc); // map to the neighbor node
	for (std::vector<int>::iterator it = node2proc->begin();
		it != node2proc->end(); it++) {
		if ((*it) == migration_proc) {
			node2proc->erase(it);
			break;
		}
	}
//	proc2nodecoord[migration_proc].x = neighbor_node.x;
//	proc2nodecoord[migration_proc].y = neighbor_node.y;
//	proc2nodecoord[migration_proc].z = neighbor_node.z;

#ifndef NDEBUG
	fprintf(stdout, "iterative local refinement: process %d @ node (%d,%d,%d) -> node (%d,%d,%d)\n",
		migration_proc, current_node.x, current_node.y, current_node.z,
		neighbor_node.x, neighbor_node.y, neighbor_node.z);
#endif

	return true;
}

void iterative_local_refinement()
{
	int i = 0;
	while (1) {
		bool refine_success = false;
		for (int i = 0; i < num_nodes; i++) {
			if (local_refinement(i)) refine_success = true;
		}
		if (!refine_success) {
          break;
		} else {
		  ++i;
		}
	}
	fprintf(stdout, "total %d iterations of local refinement!\n", i);
}

void analytical_mapping(char *comm_map_file)
{
	fprintf(stdout, "analytical mapping:\n");

	int max_iter = options::get().as_int("max_iter");
	int gamma = options::get().as_int("gamma");

	preprocessing(comm_map_file);

	fprintf(stdout, "First phase - global mapping through quadratic programming:\n");

	start_timer(TOTALMAP);
	start_timer(GLOBALMAP);

	int opt_i = 0;
	int opt_max_Ui = num_procs;
	int i = 1;
	while (1) {
		start_timer(SOLVE);
		solve_proc2nodecoord();
		end_timer(SOLVE);

		start_timer(OTHER);
		if (enable_refine) {
			regenerate_nodecoord2procvar();
			iterative_local_refinement();
		}
		size_t hop_bytes = compute_hop_bytes();
		generate_nodecoord2procvar();
		compute_max_Ui();
		alpha = 0.02+0.5/(double)max_Ui;
		if (max_Ui < opt_max_Ui) {
			opt_max_Ui = max_Ui;
			opt_i = i;
		}
		end_timer(OTHER);

		fprintf(stdout, "iter %d: max_Ui = %d, alpha = %f, hop_bytes = %ld\n",
			i, max_Ui, alpha, hop_bytes);

		if ((opt_i + max_iter <= i) || (max_Ui <= gamma)) {
          break;
		} else {
          i++;
        }

		start_timer(SHIFT);
		proc_shifting();
		add_spreading_forces();
		end_timer(SHIFT);
	}

	fprintf(stdout, "global mapping done! total %d iterations!\n", i);

	std::vector<int> proc_cnts(max_Ui+1, 0);

#ifndef NDEBUG
	fprintf(stdout, "Global mapping results:\n");
#endif
	for (int i = 0; i < mesh_x; i++) {
 		for (int j = 0; j < mesh_y; j++) {
			for (int k = 0; k < mesh_z; k++) {
				// calculte max_Ui
				int Ui = nodecoord2procvar[i][j][k]->size();
			#ifndef NDEBUG
				fprintf(stdout, "node[%d][%d][%d]: %d processes\n",
					i, j, k, Ui);
			#endif
				proc_cnts[Ui]++;
			}
		}
	}

#ifndef NDEBUG
	fprintf(stdout, "proc_cnts:\n");
	for (size_t i = 0; i < proc_cnts.size(); i++) {
		fprintf(stdout, "proc_cnts[%d] = %d\n",
			i, proc_cnts[i]);
	}
#endif

	end_timer(GLOBALMAP);

	fprintf(stdout, "Second phase - legalization through process migration:\n");

	start_timer(LEGALIZATION);
	regenerate_nodecoord2procvar();

	if (!enable_refine) {
		iterative_local_refinement();
	}

	//legalization_by_process_migration();
	//legalization_by_process_shifting();
	compute_potentials();
	end_timer(LEGALIZATION);
	end_timer(TOTALMAP);

#ifndef NDEBUG
	fprintf(stdout, "mapping");
	for (int i = 0; i < mesh_x; i++) {
		for (int j = 0; j < mesh_y; j++) {
			for (int k = 0; k < mesh_z; k++) {
				assert(nodecoord2procvar[i][j][k]->size() == 1);
				fprintf(stdout, " %d", *(nodecoord2procvar[i][j][k]->begin()));
			}
		}
	}
#endif

	size_t default_hop_bytes = compute_default_hop_bytes();
	size_t original_hop_bytes = compute_original_hop_bytes();
	my_hop_bytes = compute_hop_bytes();
	size_t original_bytes = compute_original_bytes();

	fprintf(stdout, "\nhop_bytes = %ld, original_hop_bytes = %ld, original_bytes = %ld, reduction = %.2f%%\n",
		my_hop_bytes, original_hop_bytes, original_bytes,
		((double)original_hop_bytes-(double)my_hop_bytes)
		/(double)original_hop_bytes*100.0);

	double default_average_hops = (double)default_hop_bytes/(double)original_bytes;
	double original_average_hops = (double)original_hop_bytes/(double)original_bytes;
	double average_hops = (double)my_hop_bytes/(double)original_bytes;

	fprintf(stdout, "average_hops = %f, default_average_hops = %f, original_average_hops = %f, reduction = %.2f%%, %.2f%%\n",
		average_hops, default_average_hops, original_average_hops,
		(original_average_hops - average_hops)/original_average_hops*100.0,
		(original_average_hops - default_average_hops)/original_average_hops*100.0);

	int max_hop = compute_max_hop();
	int default_max_hop = compute_default_max_hop();
	int original_max_hop = compute_original_max_hop();

	fprintf(stdout, "max_hop = %d, default_max_hop = %d, original_max_hop = %d, reduction = %.2f%%, %.2f%%\n",
		max_hop, default_max_hop, original_max_hop,
		(double)(original_max_hop - max_hop)/(double)original_max_hop*100.0,
		(double)(original_max_hop - default_max_hop)/(double)original_max_hop*100.0);

	bool select_opt = options::get().as_bool("select_opt");
	bool write_rank_map = options::get().as_bool("write_rank_map");
	bool write_libtopomap = options::get().as_bool("write_libtopomap");

	if (select_opt && (average_hops > default_average_hops)) {
		write_default_mapping_file();
		if (write_libtopomap) {
			write_default_mapping_file_for_libtopomap();
		}
		if (write_rank_map) {
			write_default_rank2newrank();
		}
	}
	else {
		write_mapping_file();
		if (write_libtopomap) {
			write_mapping_file_for_libtopomap();
		}
		if (write_rank_map) {
			write_rank2newrank();
		}
	}
}

void compare_mapping(char *reference_map_file)
{
	FILE *fp;
	char aline[LINE_LENGTH];
	char *line;
	char buffer[LINE_LENGTH];
	int num_ref_mappings;

	if (!(fp=fopen(reference_map_file, "r")))
	{
		fprintf(stdout, "\n\tCannot read file %s !\n", reference_map_file);
		fflush(stdout);
		exit(-1);
	}

	fseek(fp, 0, SEEK_SET);
	bool is_first_line = true;
	while (fgets(aline, LINE_LENGTH, fp)) {
		line = aline;
		line = get_data(line, buffer);
		if (is_first_line) {
			sscanf(buffer, "%d", &num_ref_mappings);
			assert(num_ref_mappings > 0);
			fprintf(stdout, "%d reference mappings:\n",
				num_ref_mappings);
			is_first_line = false;
			continue;
		}
		fprintf(stdout, "%s:\t", buffer);
		int proc;
		for (int node = 0; node < num_procs; node++) {
			line = get_data(line, buffer);
			sscanf(buffer, "%d", &proc);
			assert(proc >= 0 && proc < num_procs);
			proc2nodecoord[proc] = compute_coordinates(node);
		}

		size_t hop_bytes = compute_hop_bytes();

		fprintf(stdout, "\nhop_bytes = %ld, reduction = %.2f%%\n",
			hop_bytes,
			((double)hop_bytes-(double)my_hop_bytes)
			/(double)hop_bytes*100.0);

		if ((--num_ref_mappings) == 0)
			break;
	}

	fclose(fp);
}

//int compute_node_id(int x, int y, int z)
//{
//	int id = x*(mesh_y*mesh_z)+y*mesh_z+z;
//	return id;
//}

void write_mapping_file()
{
	FILE *fp;
	char filename[256];

	num_procs = num_nodes * num_procs_per_node;

	sprintf(filename, "./%dx%dx%d.%d.map",
		mesh_x, mesh_y, mesh_z, num_procs);

	if (!(fp=fopen(filename, "w")))
	{
		fprintf(stdout, "\n\tCannot open file %s !\n", filename);
		fflush(stdout);
		exit(-1);
	}

	std::vector<int> cnt(num_nodes, 0);

	for (int proc = 0; proc < num_procs; proc++) {
		int node_x, node_y, node_z;
		int part = proc_part[proc];
		node_x = proc2nodecoord[part].x;
		node_y = proc2nodecoord[part].y;
		node_z = proc2nodecoord[part].z;
		fprintf(fp, "%d %d %d %d\n",
			node_x, node_y, node_z, cnt[compute_node_id(node_x,node_y,node_z)]++);	
	}

	fclose(fp);

	fprintf(stdout, "Write mapping file \"%s\" done!\n", filename);
}

void write_mapping_file_for_libtopomap()
{
	FILE *fp;
	char filename[256];

	num_procs = num_nodes * num_procs_per_node;

	sprintf(filename, "./%dx%dx%d.%d.map.fake",
		mesh_x, mesh_y, mesh_z, num_procs);

	if (!(fp=fopen(filename, "w")))
	{
		fprintf(stdout, "\n\tCannot open file %s !\n", filename);
		fflush(stdout);
		exit(-1);
	}

//	std::vector<int> cnt(num_nodes, 0);

	for (int proc = 0; proc < num_procs; proc++) {
		int node_x, node_y, node_z;
		int part = proc_part[proc];
		node_x = proc2nodecoord[part].x;
		node_y = proc2nodecoord[part].y;
		node_z = proc2nodecoord[part].z;
//		fprintf(fp, "%d %d %d %d\n",
//			node_x, node_y, node_z, cnt[compute_node_id(node_x,node_y,node_z)]++);	
		fprintf(fp, "%d host_%d_%d_%d\n",
			proc, node_x, node_y, node_z);
	}

	fclose(fp);

	fprintf(stdout, "Write mapping file (for libtopomap) \"%s\" done!\n", filename);
}

void write_default_mapping_file()
{
	FILE *fp;
	char filename[256];

	assert(!default_proc2node.empty());
	num_procs = num_nodes * num_procs_per_node;

	sprintf(filename, "./%dx%dx%d.%d.default.map",
		mesh_x, mesh_y, mesh_z, num_procs);

	if (!(fp=fopen(filename, "w")))
	{
		fprintf(stdout, "\n\tCannot open file %s !\n", filename);
		fflush(stdout);
		exit(-1);
	}

	std::vector<int> cnt(num_nodes, 0);

	for (int proc = 0; proc < num_procs; proc++) {
		int part = proc_part[proc];
		int node = default_proc2node[part];
		coordinates coord = compute_coordinates(node);	
		fprintf(fp, "%d %d %d %d\n",
			coord.x, coord.y, coord.z, cnt[node]++);	
	}

	fclose(fp);

	fprintf(stdout, "Write default mapping file \"%s\" done!\n", filename);
}

void write_default_mapping_file_for_libtopomap()
{
	FILE *fp;
	char filename[256];

	assert(!default_proc2node.empty());
	num_procs = num_nodes * num_procs_per_node;

	sprintf(filename, "./%dx%dx%d.%d.default.map.fake",
		mesh_x, mesh_y, mesh_z, num_procs);

	if (!(fp=fopen(filename, "w")))
	{
		fprintf(stdout, "\n\tCannot open file %s !\n", filename);
		fflush(stdout);
		exit(-1);
	}

//	std::vector<int> cnt(num_nodes, 0);

	for (int proc = 0; proc < num_procs; proc++) {
		int part = proc_part[proc];
		int node = default_proc2node[part];
		coordinates coord = compute_coordinates(node);	
//		fprintf(fp, "%d %d %d %d\n",
//			coord.x, coord.y, coord.z, cnt[node]++);	
		fprintf(fp, "%d host_%d_%d_%d\n",
			proc, coord.x, coord.y, coord.z);	
	}

	fclose(fp);

	fprintf(stdout, "Write default mapping file (for libtopomap) \"%s\" done!\n", filename);
}

// write original mapping file for tests
void write_original_mapping_file()
{
	FILE *fp;
	char filename[256];

	num_procs = num_nodes * num_procs_per_node;

	sprintf(filename, "./%dx%dx%d.%d.original.map",
		mesh_x, mesh_y, mesh_z, num_procs);

	if (!(fp=fopen(filename, "w")))
	{
		fprintf(stdout, "\n\tCannot open file %s !\n", filename);
		fflush(stdout);
		exit(-1);
	}

	for (int z = 0; z < mesh_z; z++) {
		for (int y = 0; y < mesh_y; y++) {
			for (int x = 0; x < mesh_x; x++) {
				for (int i = 0; i < num_procs_per_node; i++) {
					fprintf(fp, "%d %d %d %d\n",
						x, y, z, i);	
				}
			}
		}
	}

	fclose(fp);

	fprintf(stdout, "Write original mapping file \"%s\" done!\n", filename);
}

// write original mapping file for libtopomap
void write_original_mapping_file_for_libtopomap()
{
	FILE *fp;
	char filename[256];

	num_procs = num_nodes * num_procs_per_node;

	sprintf(filename, "./%dx%dx%d.%d.original.map.fake",
		mesh_x, mesh_y, mesh_z, num_procs);

	if (!(fp=fopen(filename, "w")))
	{
		fprintf(stdout, "\n\tCannot open file %s !\n", filename);
		fflush(stdout);
		exit(-1);
	}

	int proc = 0;
	for (int z = 0; z < mesh_z; z++) {
		for (int y = 0; y < mesh_y; y++) {
			for (int x = 0; x < mesh_x; x++) {
				for (int i = 0; i < num_procs_per_node; i++) {
					fprintf(fp, "%d host_%d_%d_%d\n",
						proc, x, y, z);	
					++proc;
				}
			}
		}
	}

	fclose(fp);

	fprintf(stdout, "Write original mapping file (for libtopomap) \"%s\" done!\n", filename);
}

// write rank2newrank for hiertopomap 
void write_rank2newrank()
{
	FILE *fp;
	char filename[256];

	num_procs = num_nodes * num_procs_per_node;

	sprintf(filename, "%s.rank2newrank",
		input_comm_file);

	if (!(fp=fopen(filename, "w")))
	{
		fprintf(stdout, "\n\tCannot open file %s !\n", filename);
		fflush(stdout);
		exit(-1);
	}

	std::vector<int> rank2newrank;
	rank2newrank.reserve(num_procs);

	for (int z = 0; z < mesh_z; z++) {
		for (int y = 0; y < mesh_y; y++) {
			for (int x = 0; x < mesh_x; x++) {
				int part = *(nodecoord2procvar[x][y][z]->begin());
				for (int i = 0; i < num_procs_per_node; i++) {
					rank2newrank.push_back(*(part_procs[part]->begin()+i));
				}
			}
		}
	}
	assert(rank2newrank.size() == (size_t)num_procs);

	fprintf(fp, "%d\n", num_procs);

	for (int i = 0; i < num_procs; ++i) {
		fprintf(fp, "%d\n", rank2newrank[i]);
	}

	fclose(fp);

	fprintf(stdout, "Write rank2newrank file \"%s\" done!\n", filename);
}

// write rank2newrank for hiertopomap 
void write_default_rank2newrank()
{
	FILE *fp;
	char filename[256];

	num_procs = num_nodes * num_procs_per_node;

	sprintf(filename, "./%dx%dx%d.%d.rank2newrank",
		mesh_x, mesh_y, mesh_z, num_procs);

	if (!(fp=fopen(filename, "w")))
	{
		fprintf(stdout, "\n\tCannot open file %s !\n", filename);
		fflush(stdout);
		exit(-1);
	}

	std::vector<int> default_rank2newrank;
	default_rank2newrank.reserve(num_procs);

	for (int part = 0; part < num_nodes; ++part) {
		for (int i = 0; i < num_procs_per_node; i++) {
			default_rank2newrank.push_back(*(part_procs[part]->begin()+i));
		}
	}
	assert(default_rank2newrank.size() == (size_t)num_procs);

	fprintf(fp, "%d\n", num_procs);

	for (int i = 0; i < num_procs; ++i) {
		fprintf(fp, "%d\n", default_rank2newrank[i]);
	}

	fclose(fp);

	fprintf(stdout, "Write default rank2newrank file \"%s\" done!\n", filename);
}

//! @brief Write topology file for libtopomap
void write_topology_for_libtopomap()
{
	FILE *fp;
	char filename[256];

	sprintf(filename, "%dx%dx%d.topology",
		mesh_x, mesh_y, mesh_z);

	if (!(fp=fopen(filename, "w")))
	{
		fprintf(stdout, "\n\tCannot open file %s !\n", filename);
		fflush(stdout);
		exit(-1);
	}

	fprintf(fp, "num: %d\n",
		mesh_x*mesh_y*mesh_z);	

	for (int i = 0; i < mesh_x; i++) {
		for (int j = 0; j < mesh_y; j++) {
			for (int k = 0; k < mesh_z; k++) {
				int node = compute_node_id(i, j, k);
				fprintf(fp, "%d host_%d_%d_%d\n",
					node, i, j, k);	
			}
		}
	}

	for (int i = 0; i < mesh_x; i++) {
		for (int j = 0; j < mesh_y; j++) {
			for (int k = 0; k < mesh_z; k++) {
				int node = compute_node_id(i, j, k);
				fprintf(fp, "%d", node);
				if (i != 0) fprintf(fp, " %d", compute_node_id(i-1, j, k));
				else if (is_torus) fprintf(fp, " %d", compute_node_id(mesh_x-1, j, k));
				if (i != mesh_x-1) fprintf(fp, " %d", compute_node_id(i+1, j, k));
				else if (is_torus) fprintf(fp, " %d", compute_node_id(0, j, k));
				if (j != 0) fprintf(fp, " %d", compute_node_id(i, j-1, k));
				else if (is_torus) fprintf(fp, " %d", compute_node_id(i, mesh_y-1, k));
				if (j != mesh_y-1) fprintf(fp, " %d", compute_node_id(i, j+1, k));
				else if (is_torus) fprintf(fp, " %d", compute_node_id(i, 0, k));
				if (k != 0) fprintf(fp, " %d", compute_node_id(i, j, k-1));
				else if (is_torus) fprintf(fp, " %d", compute_node_id(i, j, mesh_z-1));
				if (k != mesh_z-1) fprintf(fp, " %d", compute_node_id(i, j, k+1));
				else if (is_torus) fprintf(fp, " %d", compute_node_id(i, j, 0));
				fprintf(fp, "\n");
			}
		}
	}

	fprintf(stdout, "Write topology file (for libtopomap) \"%s\" done!\n", filename);

	fclose(fp);
}

/*
void write_top_files()
{
	FILE *fp;
	char filename[256];

// write the default mapping file
	sprintf(filename, "%dx%dx%d.defaultmapping",
		mesh_x, mesh_y, mesh_z);

	if (!(fp=fopen(filename, "w")))
	{
		fprintf(stdout, "\n\tCannot open file %s !\n", filename);
		fflush(stdout);
		exit(-1);
	}

	for (int i = 0; i < mesh_x; i++) {
		for (int j = 0; j < mesh_y; j++) {
			for (int k = 0; k < mesh_z; k++) {
				int node = compute_node_id(i, j, k);
				fprintf(fp, "%d host_%d_%d_%d\n",
					node, i, j, k);	
			}
		}
	}

	fclose(fp);

// write my mapping file

	sprintf(filename, "%dx%dx%d.mymapping",
		mesh_x, mesh_y, mesh_z);

	if (!(fp=fopen(filename, "w")))
	{
		fprintf(stdout, "\n\tCannot open file %s !\n", filename);
		fflush(stdout);
		exit(-1);
	}

	for (int proc = 0; proc < num_procs; proc++) {
		int node_x, node_y, node_z;
		node_x = proc2nodecoord[proc].x;
		node_y = proc2nodecoord[proc].y;
		node_z = proc2nodecoord[proc].z;
		fprintf(fp, "%d host_%d_%d_%d\n",
			proc, node_x, node_y, node_z);	
	}

	fclose(fp);

// write the 3D mesh topology file

	sprintf(filename, "%dx%dx%d.topology",
		mesh_x, mesh_y, mesh_z);

	if (!(fp=fopen(filename, "w")))
	{
		fprintf(stdout, "\n\tCannot open file %s !\n", filename);
		fflush(stdout);
		exit(-1);
	}

	fprintf(fp, "num: %d\n",
		mesh_x*mesh_y*mesh_z);	

	for (int i = 0; i < mesh_x; i++) {
		for (int j = 0; j < mesh_y; j++) {
			for (int k = 0; k < mesh_z; k++) {
				int node = compute_node_id(i, j, k);
				fprintf(fp, "%d host_%d_%d_%d\n",
					node, i, j, k);	
			}
		}
	}

	for (int i = 0; i < mesh_x; i++) {
		for (int j = 0; j < mesh_y; j++) {
			for (int k = 0; k < mesh_z; k++) {
				int node = compute_node_id(i, j, k);
				fprintf(fp, "%d", node);
				if (i != 0) fprintf(fp, " %d", compute_node_id(i-1, j, k));
				if (i != mesh_x-1) fprintf(fp, " %d", compute_node_id(i+1, j, k));
				if (j != 0) fprintf(fp, " %d", compute_node_id(i, j-1, k));
				if (j != mesh_y-1) fprintf(fp, " %d", compute_node_id(i, j+1, k));
				if (k != 0) fprintf(fp, " %d", compute_node_id(i, j, k-1));
				if (k != mesh_z-1) fprintf(fp, " %d", compute_node_id(i, j, k+1));
				fprintf(fp, "\n");
			}
		}
	}

	fclose(fp);
}
*/

void clear(char *data)
{
	int i;
	for (i=0; i<LINE_LENGTH; i++)
	{
		data[i] = ' ';
	}
}

char* get_data(char *data, char *buffer)
{
	char *residue_data;
	int index=0;
	int i=0;

	clear(buffer);
	
	while ((data[index]==' ')||(data[index]==',')||(data[index]=='\t')) index ++;
	while (!((data[index]==' ')||(data[index]==',')||(data[index]=='\t')||(data[index]=='\n'))) {
		buffer[i] = data[index];
		index++;
		i++;
	}

	buffer[i] = '\0';
	residue_data = data + index;

	return residue_data;
}

// partition a given graph into equal parts
void partition_graph(int num_vertices, int** edges, int num_vertices_per_part,
		int* vertex_part,  std::vector<std::vector<int>*> &part_vertices)
{
	FILE *fptr;
	char filename[256];
	char part_filename[256];
	char command_string[256];

	int num_parts = num_vertices / num_vertices_per_part;
	assert(num_vertices % num_vertices_per_part == 0);

	sprintf(filename, "graph.hg");

	fptr = fopen(filename, "w");
	if (fptr==NULL) {
		fprintf(stdout, "Error: Uable to open %s for writing!\n\n",
			filename);
		fflush(stdout);
		exit(-1);
	}

	size_t nhedges = 0;

	for (int i = 0; i < num_vertices; i++) {
		for (int j = 0; j < i; j++) {
			if (edges[i][j] > 0) {
				nhedges++;
			}
		}
	}

	fprintf(fptr, "%d %d 1\n", nhedges,
		num_vertices); // only edges have weight, no weight for vertices

	for (int i = 0; i < num_vertices; i++) {
		for (int j = 0; j < i; j++) {
			if (edges[i][j] > 0) {
				fprintf(fptr, "%d %d %d\n",
					edges[i][j],
					j+1, i+1);
			}
		}
	}

	fclose(fptr);

	sprintf(command_string, "./hmetis2.0pre1 -ptype=rb -ufactor=1 -seed=0 %s %d",
			filename, num_parts);

	// Execute command line hmetis for patitioning
	int ret = system(command_string);

	if (ret != 0) {
		fprintf(stdout, "Error: Execute command \"%s\" fail!\nReturn %d!\n\n",
			command_string, ret);
		fflush(stdout);
		exit(-1);
	}

	sprintf(part_filename, "%s.part.%d",
		filename, num_parts);

	fptr = fopen(part_filename, "r");
	if (fptr == NULL) {
		fprintf(stdout, "Error: Uable to open %s for reading!\n\n",
			part_filename);
		fflush(stdout);
		exit(-1);
	}

	fseek(fptr, 0, SEEK_SET);

	part_vertices.clear();
	for (int i = 0; i < num_parts; i++) {
		part_vertices.push_back(new std::vector<int>);
	}

	//vertex_part = memory_alloc(int, num_vertices);

	// read partition results
	for (int i = 0; i < num_vertices; i++) {
		int ret = fscanf(fptr, "%d", &vertex_part[i]);
		assert(ret == 1);
		assert((vertex_part[i] >= 0) && (vertex_part[i] < num_parts)); 

		part_vertices[vertex_part[i]]->push_back(i);
	}

	fclose(fptr);

	sprintf(command_string, "rm -rf %s %s",
		filename, part_filename);

	// Execute command line hmetis
	ret = system(command_string);

	if (ret != 0) {
		fprintf(stdout, "Error: Execute command \"%s\" fail!\nReturn %d!\n\n",
			command_string, ret);
		fflush(stdout);
		exit(-1);
	}

	size_t num_moves = 0;
	while (1) {
		// check the number of vertices on each part 
		size_t max_num_vertices = num_vertices_per_part;
		size_t min_num_vertices = num_vertices_per_part;
		int max_part = -1;
		int min_part = -1;
		for (int i = 0; i < num_parts; i++) {
			if (part_vertices[i]->size() > max_num_vertices) {
				max_num_vertices = part_vertices[i]->size();
				max_part = i;
			}
			else if (part_vertices[i]->size() < min_num_vertices) {
				min_num_vertices = part_vertices[i]->size();
				min_part = i;
			}
		}

		assert(((max_part == -1) && (min_part == -1)) ||
				((max_part != -1) && (min_part != -1)));

		if (max_part != -1) {
			assert(min_part != -1);
			fprintf(stdout, "adjust partition results to achieve equal parts:\n");

			std::vector<int> migration_cost(part_vertices[max_part]->size(), 0);

			for (size_t i = 0; i < part_vertices[max_part]->size(); i++) {
				int vertex = *(part_vertices[max_part]->begin()+i);
				for (int j = 0; j < num_vertices; j++) {
					if (edges[vertex][j] > 0) {
						if (vertex_part[j] == max_part) {
							migration_cost[i] += edges[vertex][j]; // accumulate internal edge weight
						}
						else if (vertex_part[j] == min_part) {
							migration_cost[i] -= edges[vertex][j]; // subtract external edge weight (with min_part)
						}
					}
				}
			}

			// find the vertex to move
			int min_id = 0;
			int min_cost = migration_cost[0];
			for (size_t i = 1; i < part_vertices[max_part]->size(); i++) {
				if (migration_cost[i] < min_cost) {
					min_id = i;
					min_cost = migration_cost[i];
				}
			}

			// move vertex from max_part to min_part
			int move_vertex = *(part_vertices[max_part]->begin()+min_id);
			part_vertices[max_part]->erase(part_vertices[max_part]->begin()+min_id);
			part_vertices[min_part]->push_back(move_vertex);
			vertex_part[move_vertex] = min_part;

			fprintf(stdout, "\tmove vertex %d from part %d to part %d\n",
				move_vertex, max_part, min_part);
			num_moves++;
		}
		else {
			fprintf(stdout, "partition graph done! total %d movements!\n",
				num_moves);
			break;
		}
	}

	// check partition results
	for (int i = 0; i < num_parts; i++) {
		assert(part_vertices[i]->size() == (size_t)num_vertices_per_part);
		std::sort(part_vertices[i]->begin(), part_vertices[i]->end());
	}
}

#ifndef METIS51
extern "C" {
typedef int idxtype;
void METIS_PartGraphRecursive(int *, idxtype *, idxtype *, idxtype *, idxtype *, int *, int *, int *, int *, int *, idxtype *);
}
#endif

void partition_graph_METIS(int num_vertices, std::vector<int> &graph_x,
		std::vector<int> &graph_i, std::vector<int> &graph_p, int num_vertices_per_part,
		std::vector<int> &vertex_part,  std::vector<std::vector<int>*> &part_vertices)
{
	int num_parts = num_vertices / num_vertices_per_part;
	assert(num_vertices % num_vertices_per_part == 0);

	int edgecut;

	vertex_part.resize(num_vertices);

#ifdef METIS51
	int ncon = 1;
	int seed = options::get().as_int("seed");

	int options[METIS_NOPTIONS];
	METIS_SetDefaultOptions(options);

	options[METIS_OPTION_PTYPE] = METIS_PTYPE_RB; // recursive bisectioning
	options[METIS_OPTION_OBJTYPE] = METIS_OBJTYPE_CUT; // use edge cut as objective
	options[METIS_OPTION_NUMBERING] = 0; // use C style numbering
	options[METIS_OPTION_SEED] = seed; // the seed for the random number generator

	int r = METIS_PartGraphRecursive(&num_vertices, &ncon, &graph_p[0], &graph_i[0],
		NULL, NULL, &graph_x[0], &num_parts, NULL, NULL, options, &edgecut, &vertex_part[0]);

	if (r != METIS_OK) {
		fprintf(stderr, "METIS Error: return code r = %d\n", r);
		exit(-1);
	}
	else {
		fprintf(stdout, "METIS edgecut = %d\n", edgecut);
	}
#else // METIS 4.0
	int options[5] = {0,0,0,0,0};
	int wgtflag = 0;
	int numflag = 0;
	METIS_PartGraphRecursive(&num_vertices, (idxtype*)(&graph_p[0]), (idxtype*)(&graph_i[0]), NULL, NULL, &wgtflag,
		&numflag, &num_parts, options, &edgecut, (idxtype*)(&vertex_part[0]));
#endif

	part_vertices.clear();

	for (int i = 0; i < num_parts; i++)
		part_vertices.push_back(new std::vector<int>);

	for (int i = 0; i < num_vertices; i++)
		part_vertices[vertex_part[i]]->push_back(i);

	// use a greedy heuristic to move a vertex from the max_part to the min_part
	// this is to ensure that the parts are even 

	fprintf(stdout, "adjust partition results to achieve equal parts:\n");

	size_t num_moves = 0;
	while (1) {
		// check the number of vertices on each part 
		size_t max_num_vertices = num_vertices_per_part;
		size_t min_num_vertices = num_vertices_per_part;
		int max_part = -1;
		int min_part = -1;
		for (int i = 0; i < num_parts; i++) {
			if (part_vertices[i]->size() > max_num_vertices) {
				max_num_vertices = part_vertices[i]->size();
				max_part = i;
			}
			else if (part_vertices[i]->size() < min_num_vertices) {
				min_num_vertices = part_vertices[i]->size();
				min_part = i;
			}
		}

		assert(((max_part == -1) && (min_part == -1)) ||
				((max_part != -1) && (min_part != -1)));

		if (max_part != -1) {
			assert(min_part != -1);

			std::vector<int> migration_cost(part_vertices[max_part]->size(), 0);

			for (size_t i = 0; i < part_vertices[max_part]->size(); i++) {
				int vertex = *(part_vertices[max_part]->begin()+i);
				for (int offset = graph_p[vertex]; offset < graph_p[vertex+1]; offset++) {
					int other_vertex = graph_i[offset];
					int other_part = vertex_part[other_vertex];

					if (other_part == max_part)
						migration_cost[i] += graph_x[offset]; // accumulate internal edge weight
					else if (other_part == min_part)
						migration_cost[i] -= graph_x[offset]; // subtract external edge weight (with min_part)
				}
			}

			// find the vertex to move
			int min_id = std::min_element(migration_cost.begin(),
					migration_cost.end()) - migration_cost.begin();

			// move vertex from max_part to min_part
			int move_vertex = *(part_vertices[max_part]->begin()+min_id);
			part_vertices[max_part]->erase(part_vertices[max_part]->begin()+min_id);
			part_vertices[min_part]->push_back(move_vertex);
			vertex_part[move_vertex] = min_part;

		#ifndef NDEBUG
			fprintf(stdout, "\tmove vertex %d from part %d to part %d\n",
				move_vertex, max_part, min_part);
		#endif

			num_moves++;
		}
		else {
			fprintf(stdout, "partition graph done! total %d movements!\n",
				num_moves);
			break;
		}
	}

	// check partition results
	for (int i = 0; i < num_parts; i++) {
		assert(part_vertices[i]->size() == (size_t)num_vertices_per_part);
		std::sort(part_vertices[i]->begin(), part_vertices[i]->end());
	}
}
