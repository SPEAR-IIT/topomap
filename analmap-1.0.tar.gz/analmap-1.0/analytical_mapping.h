#ifndef __ANALYTICAL_MAPPING_H__
#define __ANALYTICAL_MAPPING_H__

#include "misc/common.h"

typedef std::map<int, size_t> edge_map;

extern int mesh_x;
extern int mesh_y;
extern int mesh_z;
extern bool is_torus;
extern bool enable_refine;

struct coordinates {
	int x;
	int y;
	int z;
	coordinates(): x(-1), y(-1), z(-1) {}
};

char* get_data(char *data, char *buffer);
void analytical_mapping(char *comm_map_file);
void compare_mapping(char *reference_map_file);
//void write_top_files();
void write_topology_for_libtopomap();
void write_scaled_comm_map_file(char *filename, std::vector<edge_map*> &edge_maps);
void write_mapping_file();
void write_mapping_file_for_libtopomap();
void write_default_mapping_file();
void write_default_mapping_file_for_libtopomap();
void write_original_mapping_file();
void write_original_mapping_file_for_libtopomap();
void write_rank2newrank();
void write_default_rank2newrank();

void read_sparse_comm_map_file(char *comm_map_file);
void build_sparse_graph(std::vector<edge_map*> &edge_maps, std::vector<int> &graph_x,
		std::vector<int> &graph_i, std::vector<int> &graph_p);
void partition_graph_METIS(int num_vertices, std::vector<int> &graph_x,
		std::vector<int> &graph_i, std::vector<int> &graph_p, int num_vertices_per_part,
		std::vector<int> &vertex_part,  std::vector<std::vector<int>*> &part_vertices);

int compute_node_id(int x, int y, int z);

#endif // __ANALYTICAL_MAPPING_H__
