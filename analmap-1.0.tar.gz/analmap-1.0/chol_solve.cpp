#include "misc/common.h"
#include "misc/options.h"
#include "misc/trace.h"
#include "misc/timer.h"

#include "cholmod.h"
#include "cholmod_direct_solve.h"
#include "chol_solve.h"

#define STYPE_SYMMETRIC_UPPER 1

chol_solve::chol_solve()
	: A_(NULL), x_(NULL), b_(NULL), L_(NULL),
	x_data_(NULL), b_data_(NULL)
{
	num_vars_ = 0;
	cholmod_start(&c_);
}

chol_solve::~chol_solve()
{
	cholmod_free_factor(&L_, &c_);
    cholmod_free_sparse(&A_, &c_);

	if (x_data_ != NULL) x_->x = x_data_;
    cholmod_free_dense(&x_, &c_);

	if (b_data_ != NULL) b_->x = b_data_;
    cholmod_free_dense(&b_, &c_);

	cholmod_finish(&c_);
}

// load matrix
void chol_solve::load_matrix(int n, int total_nnz, const double *off_diag_x,
	const int *off_diag_i, const int *off_diag_p, const double *diag)
{
	size_t nnz = (total_nnz - n)/2 + n; // only store upper triangular entries

	num_vars_ = n;

	cholmod_triplet *T;
	T = cholmod_allocate_triplet(n, n, nnz, STYPE_SYMMETRIC_UPPER, CHOLMOD_REAL, &c_);

	int *Ti = (int *)T->i;
	int *Tj = (int *)T->j;
	double *Tx = (double *)T->x;

	diag_offset_.resize(n);

	size_t index = 0;
	for (int i = 0; i < n; ++i)
	{
		for (int offset = off_diag_p[i]; offset < off_diag_p[i+1]; ++offset)
		{
			int j = off_diag_i[offset];
			double data = off_diag_x[offset];

			assert(j != i);

			if (j > i) break;

			Ti[index] = j;
			Tj[index] = i;
			Tx[index] = -data;
			index++;
		}

		Ti[index] = i;
		Tj[index] = i;
		Tx[index] = diag[i];
		diag_offset_[i] = index;
		index++;
	}

	assert(index == nnz);
	fprintf(stdout, "T->nnz = %d, nnz = %d\n", T->nnz, nnz);
	T->nnz = nnz;

	A_ = cholmod_triplet_to_sparse (T, nnz, &c_) ;
	cholmod_free_triplet(&T, &c_);

	// check the storage of diags
	for (int i = 0; i < n; ++i) {
		assert(diag[i] == *((double*)(A_->x)+diag_offset_[i]));
	}
}

void chol_solve::update_matrix_diag(const double *diag)
{
	for (size_t i = 0; i < num_vars_; ++i) {
		*((double*)(A_->x)+diag_offset_[i]) = diag[i];
	}
}

/*
double lu_nics::solve(double x[], const double b[])
{
	std::copy(b, b+num_vars_, x);

	NicsLU_MySolve(&env_, x);

//	double err;
//	NicsLU_ResidualError(&env_, x, const_cast<double *>(b), &err);

	double ret = 0;
	for (size_t i = 0; i < num_vars_; ++i)
		ret += x[i]*b[i];
	return ret;
}
*/

void chol_solve::solve(double x[], const double b[])
{
	//cholmod_dense *r;

	//double *b_data = (double *)b_->x;
	//std::copy(b, b+num_vars_, b_data);
    //x_ = cholmod_solve(CHOLMOD_A, L_, b_, &c_); // solve Ax=b

	x_->x = (void *)x;
	b_->x = (void *)b;
    cholmod_direct_solve(CHOLMOD_A, L_, b_, &x_, &c_); // solve Ax=b

/*
	double one [2] = {1,0}, m1 [2] = {-1,0}; // basic scalars
    r = cholmod_copy_dense(b_, &c_); // r = b
    cholmod_sdmult(A_, 0, m1, one, x_, r, &c_); // r = r-Ax
    fprintf(stdout, "norm(b-Ax) %8.1e\n",
	  cholmod_norm_dense(r, 0, &c_)); // print norm(r)
*/

	//double *x_data = (double *)x_->x;
	//std::copy(x_data, x_data+num_vars_, x);

	//cholmod_free_dense(&r, &c_) ;
	//cholmod_free_dense(&x_, &c_) ;
}

void chol_solve::factorize()
{
	assert(A_ != NULL);

	if (L_ != NULL) {
		cholmod_free_factor(&L_, &c_);
	}

	os::timer2 t;
	t.start_now();

    L_ = cholmod_analyze(A_, &c_); /* analyze */
    bool factor_ok = cholmod_factorize(A_, L_, &c_); /* factorize */

	t.stop_now();

	if (!factor_ok)
	{
		fprintf(stdout,
			"Choleskyfactorization failed!\n");
		exit(0);
	}

#ifndef NDEBUG
	fprintf(stdout,
		"@chol_solve::factorize: lu_user %.3f, lu_sys %.3f, lu_real %.3f\n",
		t.user(), t.sys(), t.real());
#endif

	// allocate vector x and b
	x_ = cholmod_ones(A_->nrow, 1, A_->xtype, &c_); // x = ones(n,1)
	b_ = cholmod_ones(A_->nrow, 1, A_->xtype, &c_); // b = ones(n,1)

	x_data_ = x_->x;
	b_data_ = b_->x;
}

void chol_solve::re_factorize_stable()
{
	assert((A_ != NULL) && (L_ != NULL));

	os::timer2 t;
	t.start_now();

    bool factor_ok = cholmod_factorize(A_, L_, &c_); /* factorize */

	t.stop_now();

	if (!factor_ok)
	{
		fprintf(stdout,
			"Choleskyfactorization failed!\n");
		exit(0);
	}

#ifndef NDEBUG
	fprintf(stdout,
		"@chol_solve::re_factorize: lu_user %.3f, lu_sys %.3f, lu_real %.3f\n",
		t.user(), t.sys(), t.real());
#endif
}
