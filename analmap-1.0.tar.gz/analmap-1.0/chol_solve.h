#ifndef CHOL_SOLVE_H
#define CHOL_SOLVE_H

#include "cholmod.h"
//#include "../nicslu/nicslu.h"

class chol_solve 
{
public:
	chol_solve();
	~chol_solve();

	void load_matrix(int n, int nnz, const double *off_diag_x,
		const int *off_diag_i, const int *off_diag_p, const double *diag);
	void update_matrix_diag(const double *diag);
	void factorize();
	//void re_factorize();
	void re_factorize_stable();
	void solve(double x[], const double b[]);

protected:

	size_t num_vars_;
	cholmod_sparse *A_;
	cholmod_dense *x_, *b_;
	cholmod_factor *L_;
	cholmod_common c_;
	void *x_data_;
	void *b_data_;
	std::vector<int> diag_offset_;

}; // class chol_solve

#endif // CHOL_SOLVE_H
