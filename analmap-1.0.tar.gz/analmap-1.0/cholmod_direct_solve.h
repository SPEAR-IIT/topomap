#ifndef CHOLMOD_DIRECT_SOLVE
#define CHOLMOD_DIRECT_SOLVE

#include "cholmod.h"

#ifdef __cplusplus
extern "C" {
#endif

int cholmod_direct_solve    /* returns the solution X */
(   
    /* ---- input ---- */
    int sys,            /* system to solve */
    cholmod_factor *L,  /* factorization to use */
    cholmod_dense *B,   /* right-hand-side */
    cholmod_dense **X,   /* X */
    /* --------------- */
    cholmod_common *Common
) ;

#ifdef __cplusplus
}
#endif

#endif // CHOLMOD_DIRECT_SOLVE
