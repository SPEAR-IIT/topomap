#ifndef DEFS_H
#define DEFS_H

#define METIS51

#endif
