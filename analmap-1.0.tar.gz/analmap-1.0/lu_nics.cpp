#include "misc/common.h"
#include "misc/options.h"
#include "misc/trace.h"
#include "misc/timer.h"

#include "lu_nics.h"

lu_nics::lu_nics()
{
	NicsLU_Initialize(&env_);
}

lu_nics::~lu_nics()
{
	NicsLU_Destroy(&env_);
}

// load matrix
void lu_nics::load_matrix(int n, int nnz, const double *off_diag_x,
	const int *off_diag_i, const int *off_diag_p, const double *diag)
{
	num_vars_ = n;

	ax_.clear();
	ai_.clear();
	ap_.clear();
	diag_offset_.clear();

	ax_.reserve(nnz);
	ai_.reserve(nnz);
	ap_.reserve(n+1);
	diag_offset_.reserve(n);

	for (int i = 0; i < n; ++i)
	{
		ap_.push_back(ax_.size());
		bool push_diag = false;
		for (int j = off_diag_p[i]; j < off_diag_p[i+1]; ++j)
		{
			int var = off_diag_i[j];
			double data = off_diag_x[j];

			assert(var != i);

			if (!push_diag && (var > i))
			{
				push_diag = true;
				diag_offset_.push_back(ax_.size());
				ax_.push_back(diag[i]);
				ai_.push_back(i);
			}

			ax_.push_back(-data);
			ai_.push_back(var);
		}

		if (!push_diag)
		{
			diag_offset_.push_back(ax_.size());
			ax_.push_back(diag[i]);
			ai_.push_back(i);
		}
	}

	ap_.push_back(ax_.size());

	assert(ax_.size() == (size_t)nnz);
	assert(ai_.size() == (size_t)nnz);
	assert(ap_.size() == (size_t)n+1);

	NicsLU_CreateMatrix(&env_, n, nnz, &ax_[0], &ai_[0], &ap_[0]);
	num_vars_ = n;
}

void lu_nics::update_matrix_diag(const double *diag)
{
	for (size_t i = 0; i < num_vars_; ++i) {
		ax_[diag_offset_[i]] = diag[i];
	}
}

void lu_nics::factorize()
{
	os::timer2 t;

	t.start_now();

	int__t analyze_ok = NicsLU_Analyze(&env_);

	if (analyze_ok != 0) {
		fprintf(stdout, "LU analyze failed: %d\n", analyze_ok);
		exit(-1);
	}

	int__t factor_ok = NicsLU_Factorize(&env_);

	t.stop_now();

	if (factor_ok != 0)
	{
		fprintf(stdout,
			"LU factorization failed: %d\n", factor_ok);
		exit(-1);
	}

#ifndef NDEBUG
	fprintf(stdout,
		"@l_nnz %u, u_nnz %u, ana_time %.3f, fact_time %.3f\n",
		env_.l_nnz, env_.u_nnz, env_.analysis_time, env_.fact_time);

	fprintf(stdout,
		"@lu_user %.3f, lu_sys %.3f, lu_real %.3f\n",
		t.user(), t.sys(), t.real());
#endif
}

void lu_nics::re_factorize()
{
	os::timer2 t;

	t.start_now();

	int__t factor_ok = NicsLU_ReFactorize(&env_, &ax_[0]);

	t.stop_now();

	if (factor_ok != 0)
	{
		fprintf(stdout,
			"LU factorization failed: %u\n", factor_ok);
		exit(0);
	}

#ifndef NDEBUG
	fprintf(stdout,
		"@l_nnz %u, u_nnz %u, ana_time %.3f, fact_time %.3f\n",
		env_.l_nnz, env_.u_nnz, env_.analysis_time, env_.fact_time);

	fprintf(stdout,
		"@lu_user %.3f, lu_sys %.3f, lu_real %.3f\n",
		t.user(), t.sys(), t.real());
#endif
}

void lu_nics::re_factorize_stable()
{
	os::timer2 t;

	t.start_now();

	NicsLU_ResetMatrixData(&env_, &ax_[0]);
	//NicsLU_Analyze(&env_); // do not need to run Analyze again !!!!!!
	int__t factor_ok = NicsLU_Factorize(&env_);

	t.stop_now();

	if (factor_ok != 0)
	{
		fprintf(stdout,
			"LU factorization failed: %u\n", factor_ok);
		exit(0);
	}

#ifndef NDEBUG
	fprintf(stdout,
		"@l_nnz %u, u_nnz %u, ana_time %.3f, fact_time %.3f\n",
		env_.l_nnz, env_.u_nnz, env_.analysis_time, env_.fact_time);

	fprintf(stdout,
		"@lu_user %.3f, lu_sys %.3f, lu_real %.3f\n",
		t.user(), t.sys(), t.real());
#endif
}

/*
void lu_nics::Parallel_precondition_prepare()
{
	os::timer2 t;

	// a simple heuristic to determine the number of threads
	int nth;
	nth = nthreads;

	t.start_now();

	NicsLU_Analyze(&env_);
	//NicsLU_CreateThreads(&env_, nthreads, TRUE);
	NicsLU_CreateThreads(&env_, nth, TRUE);

	int__t scheduler_ok = NicsLU_CreateScheduler(&env_);
	int__t factor_ok;

	if (scheduler_ok == 0) {
		fprintf(stdout,
			"use %d threads for parallel factorization\n", nth);
		factor_ok = NicsLU_Factorize_MT(&env_);
	}
	else {
		fprintf(stdout,
			"the matrix is not suitable for parallel factorization\n");
		fprintf(stdout,
			"use the serial factorization\n");
		factor_ok = NicsLU_Factorize(&env_);
	}

	t.stop_now();

	if (factor_ok != 0)
	{
		fprintf(stdout,
			"LU factorization failed: %u\n", factor_ok);
		exit(0);
	}

	fprintf(stdout,
		"@l_nnz %u, u_nnz %u, ana_time %.3f, fact_time %.3f\n",
		env_.l_nnz, env_.u_nnz, env_.analysis_time, env_.fact_time);

	fprintf(stdout,
		"@lu_user %.3f, lu_sys %.3f, lu_real %.3f\n",
		t.user(), t.sys(), t.real());
} */

void lu_nics::solve(double x[], const double b[])
{
	std::copy(b, b+num_vars_, x);
	NicsLU_Solve(&env_, x);
}
