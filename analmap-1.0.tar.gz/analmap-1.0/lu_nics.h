#ifndef LU_NICS_H
#define LU_NICS_H

#include "nicslu/nicslu.h"

class lu_nics
{
public:
	lu_nics();
	~lu_nics();

	SNicsLU &get_env() {return env_;}
	const size_t num_vars() const {return num_vars_;}

	void load_matrix(int n, int nnz, const double *off_diag_x,
		const int *off_diag_i, const int *off_diag_p, const double *diag);

	void update_matrix_diag(const double *diag);
	void factorize();
	void re_factorize();
	void re_factorize_stable();

	void solve(double x[], const double b[]);

protected:

	SNicsLU env_;
	size_t num_vars_;

	std::vector<real__t> ax_;
	std::vector<uint__t> ai_, ap_;

	std::vector<int> diag_offset_;

}; // class lu_nics

#endif // LU_NICS_H
