/*
 * Copyright (c) 2004-2007 Northwestern University.
 *                         NuCAD Group.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * counting_sort.h - Counting sort.
 *
 * Authors: Jia Wang, jwa112@ece.northwestern.edu
 *
 */

#ifndef COUNTING_SORT_H
#define COUNTING_SORT_H

namespace misc
{

// counting sort is too useful in constructing graphs
// to be not written everywhere in our codes
// assume key is in [0, key_max)
template <class Key, class Swap, class Iter>
void counting_sort(
	Iter begin,
	Iter end,
	size_t key_max,
	std::vector<size_t> *p_offsets = 0,
	Key key = Key(),
	Swap swap = Swap())
{
	std::vector<size_t> my_offsets, my_counts;

	std::vector<size_t> &offsets = (p_offsets == 0)? my_offsets: *p_offsets;
	std::vector<size_t> &counts = my_counts;

	// count
	counts.assign(key_max, 0);
	for (Iter i = begin; i != end; ++i)
	{
		size_t k = key(*i);

		assert(k < key_max);

		++counts[k];
	}

	// accumulate
	offsets.resize(key_max+1);
	offsets[0] = 0;
	for (size_t i = 0; i < key_max; ++i)
	{
		offsets[i+1] = offsets[i]+counts[i];
		counts[i] = offsets[i];
	}

	// inplace re-arrange
	for (size_t k = 0; k < key_max; ++k)
	{
		Iter itk = begin;
		std::advance(itk, counts[k]);
		
		for (; counts[k] < offsets[k+1]; ++itk)
		{
			for (;;)
			{
				size_t j = key(*itk);

				assert(counts[j] < offsets[j+1]);

				if (j == k)
				{
					++counts[k];
					break;
				}

				// skip those already there
				Iter itj = begin;
				std::advance(itj, counts[j]);
				for (; key(*itj) == j;)
				{
					++counts[j];
					++itj;
					assert(counts[j] < offsets[j+1]);
				}

				swap(*itk, *itj);

				++counts[j];
			}
		}
	}
}

} // namespace misc

#endif // COUNTING_SORT_H
