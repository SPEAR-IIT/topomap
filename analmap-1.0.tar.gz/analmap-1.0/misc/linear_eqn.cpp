/*
 * Copyright (c) 2004-2005 Northwestern University.
 *                         NuCAD Group.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * linear_eqn.cpp - Solving linear equations.
 *
 * Authors: Jia Wang, jwa112@ece.northwestern.edu
 *
 */

#include "common.h"

#include "linear_eqn.h"

namespace linear
{

typedef std::vector<size_t> v_size_t;

bool GaussErr(size_t N, v_double eqn[], double rhs[], double err[])
{
	clock_t tb = clock();
	
	v_size_t col_order(N);
	const double eps = 1e-10;

	for (size_t i = 0; i < N; ++i)
		col_order[i] = i;

	// deduce
	for (size_t row = 0; row < N; ++row)
	{
		// select row max
		size_t cdmax = row;
		size_t colmax = col_order[cdmax];
		double valmax = fabs(eqn[row][colmax]);
		for (size_t i = row+1; i < N; ++i)
		{
			size_t col = col_order[i];
			double val = fabs(eqn[row][col]);
			if (valmax < val)
				valmax = val, colmax = col, cdmax = i;
		}
		if (valmax < eps)
		{
			fprintf(stderr, "Zero at row %u\n", row);
			return false;
		}

		// booking row max
		col_order[cdmax] = col_order[row];
		col_order[row] = colmax;

		// solve
		for (size_t j = row+1; j < N; ++j)
		{
			if (fabs(eqn[j][colmax]) < eps)
				continue;

			double mul = eqn[j][colmax]/eqn[row][colmax];
			for (size_t i = row+1; i < N; ++i)
			{
				size_t col = col_order[i];
				eqn[j][col] -= mul*eqn[row][col];
			}
			rhs[j] -= mul*rhs[row];
			err[j] += fabs(mul)*err[row];
		}
	}

	// solve for rhs and err
	v_double r(rhs, rhs+N), e(err, err+N);
	for (int j = int(N-1); j >= 0; --j)
	{
		size_t col = col_order[j];
		double rt = r[j];
		double et = e[j];
		for (size_t i = j+1; i < N; ++i)
		{
			size_t coll = col_order[i];
			rt -= rhs[coll]*eqn[j][coll];
			et += err[coll]*fabs(eqn[j][coll]);
		}
		rhs[col] = rt/eqn[j][col];
		err[col] = et/fabs(eqn[j][col]);
	}
	
	clock_t te = clock();
	
	fprintf(stderr, "LN gauss: %u vars in %.3lfs\n", N, double(te-tb)/CLOCKS_PER_SEC);
	
	return true;
}

bool Gauss(size_t N, v_double eqn[], double rhs[])
{
	clock_t tb = clock();
	
	v_size_t col_order(N);
	const double eps = 1e-10;

	for (size_t i = 0; i < N; ++i)
		col_order[i] = i;

	// deduce
	for (size_t row = 0; row < N; ++row)
	{
		// select row max
		size_t cdmax = row;
		size_t colmax = col_order[cdmax];
		double valmax = fabs(eqn[row][colmax]);
		for (size_t i = row+1; i < N; ++i)
		{
			size_t col = col_order[i];
			double val = fabs(eqn[row][col]);
			if (valmax < val)
				valmax = val, colmax = col, cdmax = i;
		}
		if (valmax < eps)
		{
			fprintf(stderr, "Zero at row %u\n", row);
			return false;
		}

		// booking row max
		col_order[cdmax] = col_order[row];
		col_order[row] = colmax;

		// solve
		for (size_t j = row+1; j < N; ++j)
		{
			if (fabs(eqn[j][colmax]) < eps)
				continue;

			double mul = eqn[j][colmax]/eqn[row][colmax];
			for (size_t i = row+1; i < N; ++i)
			{
				size_t col = col_order[i];
				eqn[j][col] -= mul*eqn[row][col];
			}
			rhs[j] -= mul*rhs[row];
		}
	}

	// solve for rhs
	v_double r(rhs, rhs+N);
	for (int j = int(N-1); j >= 0; --j)
	{
		size_t col = col_order[j];
		double rt = r[j];
		for (size_t i = j+1; i < N; ++i)
		{
			size_t coll = col_order[i];
			rt -= rhs[coll]*eqn[j][coll];
		}
		rhs[col] = rt/eqn[j][col];
	}
	
	clock_t te = clock();
	
//	fprintf(stderr, "LN gauss: %u vars in %.3lfs\n", N, double(te-tb)/CLOCKS_PER_SEC);
	
	return true;
}

bool Gauss2(size_t N, v_double eqn[], double rhs0[], double rhs1[])
{
	clock_t tb = clock();
	
	v_size_t col_order(N);
	const double eps = 1e-10;

	for (size_t i = 0; i < N; ++i)
		col_order[i] = i;

	// deduce
	for (size_t row = 0; row < N; ++row)
	{
		// select row max
		size_t cdmax = row;
		size_t colmax = col_order[cdmax];
		double valmax = fabs(eqn[row][colmax]);
		for (size_t i = row+1; i < N; ++i)
		{
			size_t col = col_order[i];
			double val = fabs(eqn[row][col]);
			if (valmax < val)
				valmax = val, colmax = col, cdmax = i;
		}
		if (valmax < eps)
		{
			fprintf(stderr, "Zero at row %u\n", row);
			return false;
		}

		// booking row max
		col_order[cdmax] = col_order[row];
		col_order[row] = colmax;

		// solve
		for (size_t j = row+1; j < N; ++j)
		{
			if (fabs(eqn[j][colmax]) < eps)
				continue;

			double mul = eqn[j][colmax]/eqn[row][colmax];
			for (size_t i = row+1; i < N; ++i)
			{
				size_t col = col_order[i];
				eqn[j][col] -= mul*eqn[row][col];
			}
			rhs0[j] -= mul*rhs0[row];
			rhs1[j] -= mul*rhs1[row];
		}
	}

	// solve for rhs
	v_double r0(rhs0, rhs0+N), r1(rhs1, rhs1+N);
	for (int j = int(N-1); j >= 0; --j)
	{
		size_t col = col_order[j];
		double rt0 = r0[j];
		double rt1 = r1[j];
		for (size_t i = j+1; i < N; ++i)
		{
			size_t coll = col_order[i];
			rt0 -= rhs0[coll]*eqn[j][coll];
			rt1 -= rhs1[coll]*eqn[j][coll];
		}
		rhs0[col] = rt0/eqn[j][col];
		rhs1[col] = rt1/eqn[j][col];
	}
	
	clock_t te = clock();
	
	fprintf(stderr, "LN gauss: %u vars in %.3lfs\n", N, double(te-tb)/CLOCKS_PER_SEC);
	
	return true;
}

} // namespace linear

#ifdef TEST_LINEAR_EQN
int main(int argc, char *argv[])
{
	using namespace linear;

	size_t N = 4;
	if (argc > 1)
		N = atoi(argv[1]);

	std::vector<v_double> eqn(N);
	v_double rhs(N, 0), err(N, 0);

	eqn[0].resize(N, 1);
	rhs[0] = N*(N-1)/2;
	for (size_t i = 1; i < N; ++i)
	{
		eqn[i].resize(N);
		for (size_t j = 0; j < N; ++j)
			rhs[i] += (eqn[i][j]=eqn[i-1][j]*j)*j;
	}

	for (size_t j = 0; j < N; ++j)
	{
		for (size_t i = 0; i < N; ++i)
			printf("%.6lf ", eqn[j][i]);
		printf("=%.6lf\n", rhs[j]);
	}
	
	Gauss(N, &eqn[0], &rhs[0], &err[0]);

	for (size_t k = 0; k < N; ++k)
		printf("%u: %.6lf\n", k, rhs[k]);
	
	return 0;
}
#endif // TEST_LINEAR_EQN
