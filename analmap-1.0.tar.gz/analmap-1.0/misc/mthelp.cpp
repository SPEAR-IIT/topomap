/*
 * Copyright (c) 2002-2005 Jia Wang.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * mthelp.cpp - multithread helper implementation
 *
 * Authors: Jia Wang, jwa112@ece.northwestern.edu
 */

#include "../misc/common.h"

// system headers
#ifdef _WIN32
// Win32 system
#include <windows.h>
#include <process.h>
#else // !defined(_WIN32)
// Unix like systems
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <signal.h>
#endif // _WIN32

#include "mthelp.h"

namespace os
{

struct _thread_proxy_param
{
	thread_func_t thread_func;
	void *param;
};

#ifdef _WIN32
// Win32 System

// __stdcall -> __cdecl
static unsigned __stdcall thread_func_proxy(void *param)
{
	_thread_proxy_param *tpp = (_thread_proxy_param *)param;

	void *ret = tpp->thread_func(tpp->param);

	delete tpp;

	return (unsigned)ret;
}

bool thread_create(thread_func_t thread_func, void *param)
{
	unsigned tid;
	
	_thread_proxy_param *tpp = new _thread_proxy_param;
	tpp->param = param;
	tpp->thread_func = thread_func;

	HANDLE h = (HANDLE)_beginthreadex(0, 0, thread_func_proxy, tpp, 0, &tid);
	if (h == 0)
	{
		delete tpp;
		return false;
	}
	else
	{
		CloseHandle(h);
		return true;
	}
}

void thread_sleep(long sec, long millisec)
{
	Sleep(sec*1000+millisec);
}

int thread_id()
{
	return (int)GetCurrentThreadId();
}

bool thread_set_affinity(int processor)
{
	DWORD_PTR pm, sm;

	if (GetProcessAffinityMask(GetCurrentProcess(), &pm, &sm) == 0)
		return false;

	DWORD_PTR tm = (1 << processor)&pm;

	if (tm == 0) tm = pm;

	tm = SetThreadAffinityMask(GetCurrentThread(), tm);

	return tm != 0;
}

fast_lock::fast_lock()
	: inner_(0)
{
	CRITICAL_SECTION *pcs = new CRITICAL_SECTION;
	InitializeCriticalSection(pcs);
	inner_ = pcs;
}

fast_lock::~fast_lock()
{
	if (inner_ != 0)
	{
		CRITICAL_SECTION *pcs = (CRITICAL_SECTION *)inner_;
		DeleteCriticalSection(pcs);
		delete pcs;
	}
}

bool fast_lock::try_lock()
{
	return TryEnterCriticalSection((CRITICAL_SECTION *)inner_) != 0;
}

void fast_lock::lock()
{
	EnterCriticalSection((CRITICAL_SECTION *)inner_);
}

void fast_lock::unlock()
{
	LeaveCriticalSection((CRITICAL_SECTION *)inner_);
}

semaphore::semaphore()
	: inner_(0)
{
	HANDLE h = CreateSemaphore(0, 0, 0X7FFFFFFF, 0);
	if (h == 0)
		throw std::runtime_error("CreateSemaphore");
	inner_ = (void *)h;
}
	
semaphore::~semaphore()
{
	if (inner_ != 0)
		CloseHandle((HANDLE)inner_);
}

void semaphore::wait()
{
	// skip errors
	while (WaitForSingleObject((HANDLE)inner_, INFINITE) != WAIT_OBJECT_0)
		;
}

void semaphore::post()
{
	if (ReleaseSemaphore((HANDLE)inner_, 1, 0) == 0)
		throw std::runtime_error("ReleaseSemaphore");
}

void semaphore::post_multiple(size_t count)
{
	if (ReleaseSemaphore((HANDLE)inner_, (LONG)count, 0) == 0)
		throw std::runtime_error("ReleaseSemaphore");
}

struct win32_barrier
{
	semaphore sems[2];
	size_t count;
	volatile int remaining;
	volatile int isem;
}; // struct win32_barrier

barrier::barrier(size_t count)
	: inner_(0)
{
	win32_barrier *bar = new win32_barrier;

	bar->count = count;
	bar->remaining = (LONG)count;
	bar->isem = 0;

	inner_ = bar;
}

barrier::~barrier()
{
	if (inner_ != 0)
	{
		win32_barrier *bar = (win32_barrier *)inner_;
		delete bar;
	}
}

bool barrier::wait()
{
	win32_barrier *bar = (win32_barrier *)inner_;

	// trivial case
	if (bar->count == 1)
		return true;

	LONG isem = bar->isem;

	if (atomic::xadd(&bar->remaining, -1) == 1)
	{
		// last thread
		bar->remaining = (LONG)bar->count;
		bar->sems[isem].post_multiple(bar->count-1);
	}
	else
	{
		// not the last thread
		bar->sems[isem].wait();
	}

	return atomic::cmpxchg(&bar->isem, 1-isem, isem) == isem;
}

#else // !defined(_WIN32)
// Unix like systems

// detach self
static void *thread_func_proxy(void *param)
{
	_thread_proxy_param *tpp = (_thread_proxy_param *)param;

	pthread_detach(pthread_self());

	void *ret = tpp->thread_func(tpp->param);

	delete tpp;

	return ret;
}

bool thread_create(thread_func_t thread_func, void *param)
{
	pthread_t tid;

	_thread_proxy_param *tpp = new _thread_proxy_param;
	tpp->param = param;
	tpp->thread_func = thread_func;

	if (pthread_create(&tid, 0, thread_func_proxy, tpp) == 0)
		return true;
	else
	{
		delete tpp;
		return false;
	}
}

void thread_sleep(long sec, long millisec)
{
	// Unix sleep will halt whole process, use select instead.
	// However, under win32, we cannot use select as this :(
	timeval tv = {sec, millisec};
	select(0, 0, 0, 0, &tv);
}

int thread_id()
{
	return (int)pthread_self();
}

bool thread_set_affinity(int processor)
{
	cpu_set_t cpuset;

	CPU_ZERO(&cpuset);
	CPU_SET(processor, &cpuset);

	int ret = pthread_setaffinity_np(pthread_self(),
		sizeof(cpu_set_t), &cpuset);

	return ret == 0;
}

fast_lock::fast_lock()
	: inner_(0)
{
	pthread_mutex_t *pmutex = new pthread_mutex_t;
	if (pthread_mutex_init(pmutex, 0) != 0)
	{
		delete pmutex;
		throw std::runtime_error("pthread_mutex_init");
	}

	inner_ = pmutex;
}

fast_lock::~fast_lock()
{
	if (inner_ != 0)
	{
		pthread_mutex_t *pmutex = (pthread_mutex_t *)inner_;
		pthread_mutex_destroy(pmutex);
		delete pmutex;
	}
}

bool fast_lock::try_lock()
{
	return pthread_mutex_trylock((pthread_mutex_t *)inner_) == 0;
}

void fast_lock::lock()
{
	if (pthread_mutex_lock((pthread_mutex_t *)inner_) != 0)
		throw std::runtime_error("pthread_mutex_lock");
}

void fast_lock::unlock()
{
	if (pthread_mutex_unlock((pthread_mutex_t *)inner_) != 0)
		throw std::runtime_error("pthread_mutex_unlock");
}

semaphore::semaphore()
	: inner_(0)
{
	sem_t *psem = new sem_t;
	if (sem_init(psem, 0, 0) != 0)
	{
		delete psem;
		throw std::runtime_error("sem_init");
	}
	inner_ = psem;
}
	
semaphore::~semaphore()
{
	if (inner_ != 0)
	{
		sem_t *psem = (sem_t *)inner_;
		sem_destroy(psem);
		delete psem;
	}
}

void semaphore::wait()
{
	if (sem_wait((sem_t *)inner_) != 0)
		throw std::runtime_error("sem_wait");
}

void semaphore::post()
{
	if (sem_post((sem_t *)inner_) != 0)
		throw std::runtime_error("sem_post");
}

barrier::barrier(size_t count)
	: inner_(0)
{
	pthread_barrier_t *bar = new pthread_barrier_t;
	if (pthread_barrier_init(bar, 0, count) != 0)
	{
		delete bar;
		throw std::runtime_error("pthread_barrier_init");
	}
	inner_ = bar;
}

barrier::~barrier()
{
	if (inner_ != 0)
	{
		pthread_barrier_t *bar = (pthread_barrier_t *)inner_;
		pthread_barrier_destroy(bar);
		delete bar;
	}
}

bool barrier::wait()
{
	int ret = pthread_barrier_wait((pthread_barrier_t *)inner_);
	
	if (ret == PTHREAD_BARRIER_SERIAL_THREAD)
		return true;
	else if (ret != 0)
		throw std::runtime_error("pthread_barrier_wait");

	return false;
}

#endif // _WIN32

} // namespace os
