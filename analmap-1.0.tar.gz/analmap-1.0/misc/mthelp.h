/*
 * Copyright (c) 2002-2005 Jia Wang.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * mthelp.h - multithread helper interface
 *
 * Authors: Jia Wang, jwa112@ece.northwestern.edu
 */

#ifndef MTHELP_H
#define MTHELP_H

#include "atomic.h"

namespace os
{

typedef void *(*thread_func_t)(void *);

// Create a 'free' style thread.
// We close the HANDLE under Win32 or detach the thread under POSIX.
bool thread_create(thread_func_t thread_func, void *param = 0);

// Make a thread sleep.
void thread_sleep(long sec, long millisec = 0);

// thread unique id
int thread_id();

// affinity with processor
bool thread_set_affinity(int processor);

// Synchronization Objects

// in-process fast lock
class fast_lock
{
	void *inner_;

	// no copy
	fast_lock(const fast_lock &);
	fast_lock &operator=(const fast_lock &);

public:
	fast_lock();
	~fast_lock();

	bool try_lock();

	void lock();
	void unlock();
}; // class fast_lock

// auto lock
template <class locker>
class auto_lock
{
	locker &l_;

	// no copy
	auto_lock(const auto_lock &);
	auto_lock &operator=(const auto_lock &);

public:
	auto_lock(locker &l) : l_(l) {l_.lock();}
	~auto_lock() {l_.unlock();}
}; // class auto_lock

// semaphore
class semaphore
{
	void *inner_;

	// no copy
	semaphore(const semaphore &);
	semaphore &operator=(const semaphore &);

public:
	semaphore();
	~semaphore();

	void wait();
	void post();
	void post_multiple(size_t count);

}; // class semaphore

class barrier
{
	void *inner_;

	// no copy
	barrier(const barrier &);
	barrier &operator=(const barrier &);

public:
	barrier(size_t count);
	~barrier();

	bool wait();

}; // class barrier

// multi-producer multi-consumer job control
template <class job>
class job_queue
{
	semaphore _jobs;
	fast_lock _queue_lock;
	std::list<job> _queue;
	const size_t _queue_max;

public:
	// queue_max should not exceed 1000000 in practical using.
	job_queue(size_t queue_max)	: _queue_max(queue_max) {}

	void get(job *pj)
	{
		// wait job
		_jobs.wait();
		// lock queue
		auto_lock<fast_lock> al(_queue_lock);
		// got job
		*pj = _queue.front();
		// update queue
		_queue.pop_front();
	}

	// return -1 if queue full, else return number of jobs in queue after put
	int put(const job &j)
	{
		// lock queue
		auto_lock<fast_lock> al(_queue_lock);
		// make sure queue not full
		if (_queue.size() >= _queue_max)
			return -1;
		// update queue
		_queue.push_back(j);
		// post job
		_jobs.post();

		return (int)_queue.size();
	}

	size_t size()
	{
		// lock queue
		auto_lock<fast_lock> al(_queue_lock);
		
		return _queue.size();
	}
}; // class job_queue

class thread_affinity
{
	volatile int next_processor_;

	size_t get_next_processor()
	{
		return atomic::xadd(&next_processor_, 1);
	}

public:
	thread_affinity() : next_processor_(0) {} // un-sync-ed initialization

	bool set_affinity() // sync-ed affinity setting
	{
		return thread_set_affinity(get_next_processor());
	}

}; // class thread_affinity

} // namespace os

#endif // MTHELP_H
