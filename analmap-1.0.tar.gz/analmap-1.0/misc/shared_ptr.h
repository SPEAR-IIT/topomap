/*
 * Copyright (c) 2004-2005 Northwestern University.
 *                         NuCAD Group.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * shared_ptr.h - Shared pointer enables GC with ref counting.
 *
 * Authors: Jia Wang, jwa112@ece.northwestern.edu
 *
 */

#ifndef SHARED_PTR_H
#define SHARED_PTR_H

// Use boost::shared_ptr if you want more.

namespace misc
{

namespace detail
{

// policies for copy and deallocate

template <class T>
struct shared_ptr_policy_new_delete
{
	static void release(T *t) {delete t;}
	static T *clone(T *t) {return new T(t);}
}; // struct shared_ptr_policy_new_delete<T>

template <class T>
struct shared_ptr_policy_clone_release
{
	static void release(T *t) {t->release();}
	static T *clone(T *t) {return t->clone();}
}; // struct shared_ptr_policy_clone_release<T>

} // namespace detail

template <class T,
	class Policy = detail::shared_ptr_policy_clone_release<T>,
	class Count = int>
class shared_ptr
{
	T *p_;
	Count *count_;

public:
	typedef shared_ptr<T, Policy, Count> this_type;

	explicit shared_ptr(T *p) : p_(p), count_(new Count(1)) {}

	shared_ptr(const this_type &s) : p_(s.p_), count_(s.count_) {++*count_;}
	
	~shared_ptr()
	{
		if (--*count_ == 0)
		{
			if (p_)
				Policy::release(p_);
			delete count_;
		}
	}

	// Should we have a shared_ptr<U> to shared_ptr<T> ctor?
	// So does the swap and the assignment.

	void swap(this_type &r)
	{
		std::swap(count_, r.count_);
		std::swap(p_, r.p_);
	}

	this_type &operator = (this_type r) {swap(r); return *this;}

	T &operator * () const {return *p_;}
	T *operator -> () const {return p_;}
	T *get() const {return p_;}

	this_type copy() const
	{
		if (p_)
			return this_type(Policy::clone(p_));
		else
			return this_type(0);
	}

}; // shared_ptr<T>

} // namespace misc

#endif // SHARED_PTR_H
