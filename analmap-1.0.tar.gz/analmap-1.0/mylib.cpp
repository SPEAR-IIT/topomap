#include "mylib.h"
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

int *alloc_int (int n)
{
	int *pointer;
	
	if ((pointer=(int *)malloc(n*sizeof(int)))==NULL) {
		printf("Fatal Error: out of memory!\n");
		exit(-1);
	}
	else {
		return pointer;
	}
}

double *alloc_double (int n)
{
	double *pointer;
	
	if ((pointer=(double *)malloc(n*sizeof(double)))==NULL) {
		printf("Fatal Error: out of memory!\n");
		exit(-1);
	}
	else {
		return pointer;
	}
}

/*
MSKboundkeye *alloc_MSKboundkeye (int n)
{
	MSKboundkeye *pointer;
	
	if ((pointer=(MSKboundkeye *)malloc(n*sizeof(MSKboundkeye)))==NULL) {
		printf("Fatal Error: out of memory!\n");
		exit(-1);
	}
	else {
		return pointer;
	}
}

MSKlidxt *alloc_MSKlidxt (int n)
{
	MSKlidxt *pointer;
	
	if ((pointer=(MSKlidxt *)malloc(n*sizeof(MSKlidxt)))==NULL) {
		printf("Fatal Error: out of memory!\n");
		exit(-1);
	}
	else {
		return pointer;
	}
}

MSKidxt *alloc_MSKidxt (int n)
{
	MSKidxt *pointer;
	
	if ((pointer=(MSKidxt *)malloc(n*sizeof(MSKidxt)))==NULL) {
		printf("Fatal Error: out of memory!\n");
		exit(-1);
	}
	else {
		return pointer;
	}
}
*/

int **alloc_int_matrix (int m, int n)
{
	int **pointer;
	int i;
	
	if ((pointer=(int **)malloc(m*sizeof(int*)))==NULL) {
		printf("Fatal Error: out of memory!\n");
		exit(-1);
	}
	else {
		for (i=0; i<m; i++) {
			if ((*(pointer+i)=(int *)malloc(n*sizeof(int)))==NULL) {
				printf("Fatal Error: out of memory!\n");
				exit(-1);
			}
		}
		return pointer;
	}
}

double **alloc_double_matrix (int m, int n)
{
	double **pointer;
	int i;
	
	if ((pointer=(double **)malloc(m*sizeof(double*)))==NULL) {
		printf("Fatal Error: out of memory!\n");
		exit(-1);
	}
	else {
		for (i=0; i<m; i++) {
			if ((*(pointer+i)=(double *)malloc(n*sizeof(double)))==NULL) {
				printf("Fatal Error: out of memory!\n");
				exit(-1);
			}
		}
		return pointer;
	}
}

void free_int_matrix (int **matrix, int m)
{
	int i;

	for (i=0; i<m; i++) free(*(matrix+i));
	free(matrix);
}

void free_double_matrix (double **matrix, int m)
{
	int i;

	for (i=0; i<m; i++) free(*(matrix+i));
	free(matrix);
}
/*
void convert_int_column_sparse_matrx(int m, int n, int **matrix,
							MSKlidxt *ptrb, MSKlidxt *ptre,
							MSKidxt *asub, double *aval)
{
  int i, j;
  int index;

  // number of none zeros
  int num_nz = 0;

  // number of none zeros for each column
  int *column_num_nz;

  column_num_nz = alloc_int(n);

  for (i=0; i<n; i++) column_num_nz[i] = 0;

  for (i=0; i<m; i++) {
	  for (j=0; j<n; j++) {
          if (matrix[i][j]!=0) column_num_nz[j]++;
      }
  }

  for (i=0; i<n; i++) {
      ptrb[i] = num_nz;
	  num_nz += column_num_nz[i];
	  ptre[i] = num_nz;
  }

  for (i=0; i<n; i++) column_num_nz[i] = 0;

  asub = alloc_MSKidxt(num_nz); 
  aval = alloc_double(num_nz);

  for (i=0; i<m; i++ ) {
      for (j=0; j<n; j++) {
          if (matrix[i][j]!=0) {
			  index = ptrb[j] + column_num_nz[j];
              asub[index] = i;
              //aval[index] = atof(matrix[i][j]);
              aval[index] = matrix[i][j];
			  column_num_nz[j]++;
          } 
      }
  }

  free(column_num_nz);
}

void convert_double_column_sparse_matrx(int m, int n, double **matrix,
							MSKlidxt *ptrb, MSKlidxt *ptre,
							MSKidxt *asub, double *aval)
{
  int i, j;
  int index;

  // number of none zeros
  int num_nz = 0;

  // number of none zeros for each column
  int *column_num_nz;

  column_num_nz = alloc_int(n);

  for (i=0; i<n; i++) column_num_nz[i] = 0;

  for (i=0; i<m; i++) {
	  for (j=0; j<n; j++) {
          if (matrix[i][j]!=0.0) column_num_nz[j]++;
      }
  }

  for (i=0; i<n; i++) {
      ptrb[i] = num_nz;
	  num_nz += column_num_nz[i];
	  ptre[i] = num_nz;
  }

  for (i=0; i<n; i++) column_num_nz[i] = 0;

  asub = alloc_MSKidxt(num_nz); 
  aval = alloc_double(num_nz);

  for (i=0; i<m; i++ ) {
      for (j=0; j<n; j++) {
          if (matrix[i][j]!=0.0) {
			  index = ptrb[j] + column_num_nz[j];
              asub[index] = i;
              //aval[index] = atof(matrix[i][j]);
              aval[index] = matrix[i][j];
			  column_num_nz[j]++;
          } 
      }
  }
  
  free(column_num_nz);
}
*/
void *alloc_worker(size_t size, const char *file, int line)
{
	void *ptr;

	if (size>0) {
		ptr = malloc(size);

		if(ptr==NULL) {
			//debug_error("Failure allocating %d bytes in file %s, line %d", size, file, line);
			error_msg("Failure allocating %d bytes in file %s, line %d", size, file, line);
		}

		return ptr;
	}
	else {
		return NULL;
	}
}

void free_worker(void *ptr, const char *file, int line)
{
	if (ptr!=NULL) {
		free(ptr);
	}
}


void error_msg( const char *fmt, ... )
{
	char message[256];
	va_list args;

	va_start( args, fmt );
	vsnprintf( message, 256, fmt, args );
	va_end( args );

	fprintf(stdout,"ERROR: %s\n",message);

	exit(-1);
}

#ifndef NDEBUG
void debug_msg( const char *fmt, ... )
{
	char message[256];
	va_list args;

	va_start( args, fmt );
	vsnprintf( message, 256, fmt, args );
	va_end( args );

	fprintf(stdout,"%s\n",message);
}
#endif

