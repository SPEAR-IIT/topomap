#ifndef __MYLIB_H__
#define __MYLIB_H__

#include "./misc/common.h"

#define round(x) ((int)( (x-floor(x)) >= 0.5 ? ceil(x) : floor(x)))
#define memory_alloc_bytes(size)  alloc_worker(size, __FILE__, __LINE__)
#define memory_alloc(type,size)   (type *)alloc_worker((size)*sizeof(type), __FILE__, __LINE__)
#define memory_free(ptr)          {free_worker(ptr,__FILE__,__LINE__); ptr = NULL; }

#ifndef NDEBUG
#define debug_assert(x) if (!(x)) {error_msg( "Assertion (%s) failed: %s line %u", #x, __FILE__, __LINE__ ); }
void debug_msg(const char *fmt, ...);
#else
#define debug_assert(x) 
#define debug_msg( ... )
#endif

int *alloc_int (int );

double *alloc_double (int );
/*
MSKboundkeye *alloc_MSKboundkeye (int );

MSKlidxt *alloc_MSKlidxt (int );

MSKidxt *alloc_MSKidxt (int );
*/
int **alloc_int_matrix (int , int );

double **alloc_double_matrix (int , int );

void free_int_matrix (int **, int );

void free_double_matrix (double **, int );

/*
void convert_int_column_sparse_matrx(int , int , int **,
							MSKlidxt *, MSKlidxt *, MSKidxt *, double *);

void convert_double_column_sparse_matrx(int , int , double **,
							MSKlidxt *, MSKlidxt *, MSKidxt *, double *);
*/
void *alloc_worker(size_t size, const char *file, int line);

void free_worker(void *ptr, const char *file, int line);

void error_msg(const char *fmt, ...);

#endif
