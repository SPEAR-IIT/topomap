/*common configurations for NICS software*/

#ifndef __NICS_CONFIG_INCLUDE__
#define __NICS_CONFIG_INCLUDE__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>

/*return code*/
#define NICS_OK				(0)


#ifndef TRUE
#define TRUE				(1)
#endif
#ifndef FALSE
#define FALSE				(0)
#endif


/*typedef*/
typedef unsigned char		byte__t;
typedef unsigned short		word__t;
typedef unsigned int		dword__t;
#ifdef _WIN32
typedef unsigned __int64	qword__t;
#else
typedef unsigned long long	qword__t;
#endif

typedef char				int8__t;
typedef unsigned char		uint8__t;
typedef short				int16__t;
typedef unsigned short		uint16__t;
typedef int					int32__t;
typedef unsigned int		uint32__t;
#ifdef _WIN32
typedef __int64				int64__t;
typedef unsigned __int64	uint64__t;
#else
typedef long long			int64__t;
typedef unsigned long long	uint64__t;
#endif

typedef char				char__t;
typedef unsigned char		bool__t;
typedef int					int__t;
typedef unsigned int		uint__t;
typedef double				real__t;


#endif
