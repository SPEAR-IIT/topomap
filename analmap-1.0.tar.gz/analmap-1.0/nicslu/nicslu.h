/*the interface of NICSLU*/

#ifndef __NICSLU_INCLUDE__
#define __NICSLU_INCLUDE__

#include "nics_config.h"

/*return code*/
#define NICSLU_GENERAL_FAIL							(-1)
#define NICSLU_ARGUMENT_ERROR						(-2)
#define NICSLU_MEMORY_OVERFLOW						(-3)
#define NICSLU_FILE_CANNOT_OPEN						(-4)
#define NICSLU_MATRIX_STRUCTURAL_SINGULAR			(-5)
#define NICSLU_MATRIX_NUMERIC_SINGULAR				(-6)
#define NICSLU_MATRIX_INVALID						(-7)
#define NICSLU_MATRIX_ENTRY_DUPLICATED				(-8)
#define NICSLU_THREADS_NOT_INITIALIZED				(-9)
#define NICSLU_MATRIX_NOT_INITIALIZED				(-10)
#define NICSLU_SCHEDULER_NOT_INITIALIZED			(-11)
#define NICSLU_SINGLE_THREAD						(-12)
#define NICSLU_THREADS_INIT_FAIL					(-13)
#define NICSLU_MATRIX_NOT_ANALYZED					(-14)
#define NICSLU_MATRIX_NOT_FACTORIZED				(-15)

/*mode*/
enum NICSLU_MODE
{
	NICSLU_MODE_CSR = 0,
	NICSLU_MODE_CSC
};
#define NICSLU_MODE_DEFAULT				(NICSLU_MODE_CSR)


/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

/*the main data structure*/
typedef struct tagSNicsLU
{
	/*flags, 5 items*/
	bool__t matrix_inited;
	bool__t analyzed;
	bool__t mt_inited;
	bool__t facted;
	bool__t schdler_inited;

	/*statistical information, 7 items*/
	real__t analysis_time;	/*in seconds*/
	real__t fact_time;		/*in seconds*/
	real__t refact_time;	/*in seconds*/
	real__t solve_time;		/*in seconds*/
	real__t schdler_time;	/*in seconds*/
	real__t flops;			/*flops*/
	real__t cond;			/*condition number*/

	/*config, 7 items*/
	byte__t mode;			/*CSR or CSC, default CSR*/
	bool__t scale;			/*default true*/
	real__t pivot_tol;		/*the pivot tolerance, default 0.001*/
	uint__t schd_thres;		/*scheduling threshold, default 10*/
	real__t static_mem_mult;/*default 3.0*/
	uint__t static_rnz_ub;	/*static row nnz upper bound, default 2*/
	uint__t thread;			/*thread number*/

	/*matrix data, 6 items*/
	uint__t n;				/*dimension*/
	uint__t nnz;			/*nonzeros of A*/
	real__t *ax;			/*value*/
	uint__t *ai;			/*column/row index*/
	uint__t *ap;			/*row/column header*/
	real__t *rhs;			/*for solve and tsolve*/

	/*other matrix data, 13 items*/
	real__t **row_data_ptr;	/*permuted A*/
	uint__t **row_index_ptr;/*permuted A*/
	uint__t *row_nnz;		/*permuted A*/
	uint__t *row_perm;		/*row_perm[i]=j-->row i in the permuted matrix is row j in the original matrix*/
	uint__t *row_perm_inv;	/*row_perm_inv[i]=j-->row i in the original matrix is row j in the permuted matrix*/
	uint__t *col_perm;
	uint__t *col_perm_inv;
	real__t *row_scale_perm;/*permuted*/
	real__t *col_scale_perm;/*permuted*/
	real__t *row_scale;		/*not permuted*/
	real__t *col_scale;		/*not permuted*/
	int__t *pivot;			/*pivot[i]=j-->column j is the ith pivot column*/
	int__t *pivot_inv;		/*pivot_inv[i]=j-->column i is the jth pivot column*/

	/*lu matrix, 15 items*/
	size_t lu_nnz_est;		/*estimated total nnz by AMD*/
	size_t lu_nnz_static;	/*estimated total nnz by static symbolic*/
	size_t lu_nnz;			/*nonzeros of factorized matrix L+U-I*/
	size_t l_nnz;			/*inclu diag*/
	size_t u_nnz;			/*inclu diag*/
	real__t *ldiag;			/*udiag=1.0*/
	void *lu_array;			/*lu index and data*/
	size_t *up;				/*u row header, the header of each row*/
	uint__t *llen;			/*exclu diag*/
	uint__t *ulen;			/*exclu diag*/
	uint__t off_diag_pivot;	/*how many pivots are not on the diag*/
	size_t *len_est;		/*estimated len, for parallelism, in bytes*/
	uint__t *ulen_est;		/*estimated ulen, for parallelism*/
	byte__t *row_state;		/*row state, finished or un-finished*/
	void **lu_array2;		/*for parallelism*/

	/*work space, 3 items*/
	void *workspace;
	void **workspace_mt1;
	void **workspace_mt2;

	/*for parallelism, 10 items*/
	int__t thread_work;
	void *thread_id;		/*thread id, internal structure, not open*/
	void *thread_arg;		/*thread argument, internal structure, not open*/
	bool__t *thread_active;
	bool__t *thread_finish;
	uint__t *cluster_start;
	uint__t *cluster_end;
	uint__t pipeline_start;
	uint__t pipeline_end;
	uint__t last_busy;

	/*aegraph, 6 items*/
	uint__t aeg_level;
	uint__t *aeg_data;
	uint__t *aeg_header;
	uint__t aeg_refact_level;
	uint__t *aeg_refact_data;
	uint__t *aeg_refact_header;

	/*timer, internal structure, not open*/
	void *timer;

} SNicsLU, *LPSNicsLU;


/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

/*argument flags*/
#define IN__
#define OUT__
#define INOUT__

#define NICSLU_API__

#ifdef _WIN32
#ifdef _M_X64
#pragma comment(lib, "nicslu64.lib")
#else
#pragma comment(lib, "nicslu32.lib")
#endif
#endif


#ifdef __cplusplus
extern "C" {
#endif

/*******************************************************************************/
/*******************************************************************************/
/*create and destroy the main structure*/
int__t NICSLU_API__	NicsLU_Initialize( \
	INOUT__ SNicsLU *nicslu);

int__t NICSLU_API__	NicsLU_Destroy( \
	INOUT__ SNicsLU *nicslu);


/*******************************************************************************/
/*******************************************************************************/
/*create and destroy the matrix*/
int__t NICSLU_API__	NicsLU_CreateMatrix( \
	INOUT__ SNicsLU *nicslu, \
	IN__ uint__t n, \
	IN__ uint__t nnz, \
	IN__ real__t *ax, \
	IN__ uint__t *ai, \
	IN__ uint__t *ap);

int__t NICSLU_API__	NicsLU_DestroyMatrix( \
	INOUT__ SNicsLU *nicslu);


/*******************************************************************************/
/*******************************************************************************/
/*create and destroy the threads*/
int__t NICSLU_API__	NicsLU_CreateThreads( \
	INOUT__ SNicsLU *nicslu, \
	IN__ uint__t thread, \
	IN__ bool__t check);

int__t NICSLU_API__ NicsLU_DestroyThreads( \
	INOUT__ SNicsLU *nicslu);


/*******************************************************************************/
/*******************************************************************************/
/*create the scheduler, it must be called after NicsLU_CreateThreads and NicsLU_Analyze*/
/*return 0: suggest using parallel version*/
/*return >0: suggest using sequential version*/
int__t NICSLU_API__	NicsLU_CreateScheduler( \
	INOUT__ SNicsLU *nicslu);

/*destroy the scheduler*/
int__t NICSLU_API__	NicsLU_DestroyScheduler( \
	INOUT__ SNicsLU *nicslu);


/*******************************************************************************/
/*******************************************************************************/
/*kernel functions*/

/*preprocess, pivoting and ordering*/
int__t NICSLU_API__	NicsLU_Analyze( \
	INOUT__ SNicsLU *nicslu);

/*numeric factorization, with partial pivoting*/
int__t NICSLU_API__	NicsLU_Factorize( \
	INOUT__ SNicsLU *nicslu);

/*re-factorization, without partial pivoting*/
int__t NICSLU_API__	NicsLU_ReFactorize( \
	INOUT__ SNicsLU *nicslu, \
	IN__ real__t *ax);

/*multi threads*/
int__t NICSLU_API__	NicsLU_Factorize_MT( \
	INOUT__ SNicsLU *nicslu);

int__t NICSLU_API__	NicsLU_ReFactorize_MT( \
	INOUT__ SNicsLU *nicslu, \
	IN__ real__t *ax);

/*solve*/
int__t NICSLU_API__	NicsLU_Solve( \
	INOUT__ SNicsLU *nicslu, \
	INOUT__ real__t *rhs);/*for inputs, it's b, for outputs, it's overwritten by x*/

/*reset maxtrix data*/
int__t NICSLU_API__	NicsLU_ResetMatrixData( \
	INOUT__ SNicsLU *nicslu, \
	IN__ real__t *ax);

/*refine, when a matrix is ill-conditioned, it may be used, but it's not always ok*/
int__t NICSLU_API__ NicsLU_Refine( \
	INOUT__ SNicsLU *nicslu, \
	INOUT__ real__t *x, \
	IN__ real__t *b, \
	IN__ real__t eps, \
	IN__ uint__t maxiter);/*if set to 0, then no iteration count constraint*/


/*******************************************************************************/
/*******************************************************************************/
/*relative residual error, error = |Ax-b|/(|A||x|+|b|)*/
int__t NICSLU_API__	NicsLU_ResidualError( \
	IN__ SNicsLU *nicslu, \
	IN__ real__t *x, \
	IN__ real__t *b, \
	OUT__ real__t *error);

/*flops*/
int__t NICSLU_API__	NicsLU_Flops( \
	INOUT__ SNicsLU *nicslu, \
	OUT__ real__t *flops);

/*transpose the matrix*/
int__t NICSLU_API__	NicsLU_Transpose( \
	IN__ uint__t n, \
	IN__ uint__t nnz, \
	INOUT__ real__t *ax, \
	INOUT__ uint__t *ai, \
	INOUT__ uint__t *ap);

/*dump lu. inclu diag, udiag=1.0*/
int__t NICSLU_API__	NicsLU_DumpLU( \
	IN__ SNicsLU *nicslu, \
	OUT__ real__t **lx, \
	OUT__ uint__t **li, \
	OUT__ size_t **lp, \
	OUT__ real__t **ux, \
	OUT__ uint__t **ui, \
	OUT__ size_t **up);

/*condition number*/
int__t NICSLU_API__	NicsLU_ConditionNumber( \
	INOUT__ SNicsLU *nicslu, \
	OUT__ real__t *cond);


/*******************************************************************************/
/*******************************************************************************/
/*memory free, to avoid a dynamic linked memory problem*/
int__t NICSLU_API__	NicsLU_FreeMemory( \
	INOUT__ void **pp);


#ifdef __cplusplus
}
#endif

#endif
