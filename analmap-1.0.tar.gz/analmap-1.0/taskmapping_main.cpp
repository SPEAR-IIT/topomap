#include "misc/common.h"
#include "misc/options.h"
#include "analytical_mapping.h"
#include "mylib.h"
#include "timing.h"
#include "defs.h"

using misc::options;
using namespace timing;

int mesh_x;
int mesh_y;
int mesh_z;
bool is_torus;
bool enable_refine;

RegisterOption(torus, "false", "is torus topology?")
RegisterOption(refine, "true", "enable iterative local refinement?")
#ifdef METIS51 // no cholmod
RegisterOption(seed, "0", "seed for METIS5.1")
#endif
RegisterOption(pin_scheme, "1", "0 - breath first traversal; 1 - RCM ordering")
RegisterOption(max_iter, "10", "global mapping will terminate if no better solution found in \"max_iter\" iterations")
RegisterOption(gamma, "4", "global mapping will terminate if each node contains at most \"gamma\" processes")
RegisterOption(write_original, "false", "write original mapping file?")
RegisterOption(write_libtopomap, "false", "write topolgoy and mapping files for libtopomap")
RegisterOption(select_opt, "false", "select optimal mapping between default and computed mapping")
//RegisterOption(cache_opt, "false", "use RCM ordering for cache efficiency")
RegisterOption(solver, "0", "0 - NICSLU, 1 - CHOLMOD")
RegisterOption(scale_edge_weight, "true", "scale the edge weight for topology mapping?")
RegisterOption(write_rank_map, "false", "write rank to newrank mapping?")
RegisterOption(write_scaled_comm, "false", "write scaled comm_map_file?")
RegisterOption(mm_format, "false", "input file in matrix market format (row/col id start with 1)?")

int main(int argc, char *argv[])
{
	options::get().load_options(argc, argv);

	// check argument
	if (argc < 3) {
		//fprintf(stdout, "usage: %s topo(e.g.4x4x4) mesh0torus1 comm_map_file (reference_map_file)\n\n",
		fprintf(stdout, "usage: %s topo(e.g.4x4x4) comm_map_file options\n",
			argv[0]);

		options::get().show_options(stdout);
		return -1;
	}

	options::get().show_options(stdout);

	sscanf(argv[1], "%d%*c%d%*c%d", &mesh_x, &mesh_y, &mesh_z);

	is_torus = options::get().as_bool("torus");
	enable_refine = options::get().as_bool("refine");
	if (is_torus) {
		fprintf(stdout, "torus size: %dx%dx%d\n", mesh_x, mesh_y, mesh_z);
	}
	else {
		fprintf(stdout, "mesh size: %dx%dx%d\n", mesh_x, mesh_y, mesh_z);
	}

	start_timer(TOTAL);

	// perform analytical task mapping
	analytical_mapping(argv[2]);

	//if (argc >= 5) { 
	//	compare_mapping(argv[4]);
	//}

	// write top files for comparison with libtop
	//write_top_files();
	
	//write_mapping_file();

	bool write_original = options::get().as_bool("write_original");
	if (write_original) {
		write_original_mapping_file();
	}

	bool write_libtopomap = options::get().as_bool("write_libtopomap");
	if (write_libtopomap) {
		write_topology_for_libtopomap();
		write_original_mapping_file_for_libtopomap();
	}

	end_timer(TOTAL);

	print_timers();

	return 0;
}
