#include "misc/common.h"
#include "timing.h"

timing::timer timers[NUM_TIMERS];

namespace timing {
const char *timer_name[] = {
 	"total          ",
	"io             ",
	"graph part.    ",
	"preprocess     ",
	"solve          ",
	"shift          ",
	"other          ",
	"global mapping ",
	"legalization   ",
	"total mapping  "
};

void init_timers()
{
	for (size_t i = 0; i < NUM_TIMERS; ++i)
	{
		timers[i].status = 0;
		timers[i].user = 0.0;
		timers[i].sys = 0.0;
		timers[i].real = 0.0;
	}
}

void start_timer(size_t timerid)
{
	assert(timerid < NUM_TIMERS);
	assert(timers[timerid].status == 0);

	timers[timerid].t.start_now();
	timers[timerid].status = 1;
}

void end_timer(size_t timerid)
{
	assert(timerid < NUM_TIMERS);
	assert(timers[timerid].status == 1);

	timers[timerid].t.stop_now();
	timers[timerid].user += timers[timerid].t.user();
	timers[timerid].sys += timers[timerid].t.sys();
	timers[timerid].real += timers[timerid].t.real();
	timers[timerid].status = 0;
}

void print_timers()
{
	fprintf(stdout,
		"\n##################################################\n");
	fprintf(stdout, "Timer Statistics:\n");
	fprintf(stdout, "TimerName       \tuser\tsys\treal\n");

	for (size_t i = 0; i < NUM_TIMERS; ++i)
		fprintf(stdout, "%s\t%.3f\t%.3f\t%.3f\n",
			timer_name[i], timers[i].user, timers[i].sys,
			timers[i].real);
}
}
