#ifndef TIMING_H
#define TIMING_H

#include "misc/timer.h"

#define NUM_TIMERS     10

#define TOTAL          0
#define IO             1
#define GP             2
#define PREPROCESS     3
#define SOLVE          4
#define SHIFT          5
#define OTHER          6
#define GLOBALMAP      7
#define LEGALIZATION   8
#define TOTALMAP       9

namespace timing {

typedef struct TIMER {
	os::timer2 t;
	int    status;
	double user, sys, real;
} timer;

void init_timers();

void start_timer(size_t timerid);

void end_timer(size_t timerid);

void print_timers();

}

#endif // TIMING_H
