#include "hiertopomap.h"

// the fuctions in this file are used to support the fat-tree topology 
// (non-contiguous allocation), specifically - TACC Stampede
#ifdef FAT_TREE_TOPOLOGY

#define OPT_QUERY // only query the node pair (i, j), i < j
#define MASTER_QUERY // only use the master node to query the topology
//#define JUST_READ_QUERY_LOG // just read the query log of previous runs, used on Stampede
                            // to avoid multiple queries (of different runs) in the same job

// query the hop distances between nodes
static void query_hopdis(MPI_Comm comm, hop_distances &hopdis,
  std::vector<std::string> &all_nodenames)
{
  char hostname[NAME_LENGTH];
  int proc;
  int i;
  FILE *fp, *fout;
  char script_name[NAME_LENGTH];
  char log_name[NAME_LENGTH];
  char node_log_name[NAME_LENGTH];
  char command_string[NAME_LENGTH];
#ifdef MASTER_QUERY
  char *all_command_strings;
#endif
  char linebuf[LINE_LENGTH];
  int check_next_line;
  int count;
  int search_fail = 0;

  int nranks, myrank;
  MPI_Comm_size(comm, &nranks); // note: only one process on each compute node in the communicator
  MPI_Comm_rank(comm, &myrank); // in fact, nranks = number of nodes, myrank = my node id

  // create a temporary directory
  char tmp_directory[NAME_LENGTH] = ".hiertopomap.tmp";
  if (!myrank) { // node 0 creates the tmp directory
    sprintf(command_string, "mkdir %s", tmp_directory);
    system(command_string);
	// delete the temporary files if any (produced by previous runs if the directory already exists)
#ifndef JUST_READ_QUERY_LOG
    sprintf(command_string, "rm -rf %s/*", tmp_directory);
    system(command_string);
#else
	printf("just read query logs of the previous run to get the topology!\n");
#endif
  }

  MPI_Barrier(comm); // synchronize all nodes, so that the tmp directory can be accessed

  sprintf(node_log_name, "%s/node.%03u.log",
    tmp_directory, myrank);
  fout = fopen(node_log_name, "w");
  if (fout == NULL) {
    fprintf(stderr, "Error: node %d cannot open %s for writing!\n",
      myrank, node_log_name);
    MPI_Abort(MPI_COMM_WORLD, 1);
  }

  fprintf(fout, "node name: %s\n", all_nodenames[myrank].c_str());
  fprintf(fout, "node id: %d\n", myrank);

  // create the expect script for querying the network topology
  sprintf(script_name, "%s/query.%03u.exp",
    tmp_directory, myrank);
  fp = fopen(script_name, "w");
  if (fp == NULL) {
    fprintf(fout, "Error: node %d cannot open %s for writing!\n",
      myrank, script_name);
    fflush(fout);
    fprintf(stderr, "Error: node %d cannot open %s for writing!\n",
      myrank, script_name);
    MPI_Abort(MPI_COMM_WORLD, 1);
  }

  fprintf(fp, "#!/bin/expect\n");
  fprintf(fp, "spawn nc topo.stampede.tacc.utexas.edu 5678\n");
  //fprintf(fp, "expect \"'^]'.\"\n");

  hopdis.assign(nranks, -1);
  hopdis[myrank] = 0; // set self distance to be 0

#ifdef OPT_QUERY
  for (proc = myrank+1; proc < nranks; proc++) {
    assert(all_nodenames[myrank] != all_nodenames[proc]);
    fprintf(fp, "send \"query %s:%s\\n\"\n",
      all_nodenames[myrank].c_str(), all_nodenames[proc].c_str());
    fprintf(fp, "expect \" %s \"\n",
      all_nodenames[proc].c_str());
  }
#else
  for (proc = 0; proc < nranks; proc++) {
    if (proc != myrank) {
      assert(all_nodenames[myrank] != all_nodenames[proc]);
      fprintf(fp, "send \"query %s:%s\\n\"\n",
        all_nodenames[myrank].c_str(), all_nodenames[proc].c_str());
      fprintf(fp, "expect \" %s \"\n",
        all_nodenames[proc].c_str());
    }
  }
#endif

  fprintf(fp, "send \"quit\\n\"\n");
  fprintf(fp, "exit\n");
  fclose(fp);

  // run the expect script
  sprintf(log_name, "%s/query.%03u.log",
    tmp_directory, myrank);
  sprintf(command_string, "expect %s > %s",
    script_name, log_name);

#ifdef MASTER_QUERY
  all_command_strings = new char [nranks*NAME_LENGTH];
  MPI_Allgather(command_string, NAME_LENGTH, MPI_CHAR, all_command_strings,
    NAME_LENGTH, MPI_CHAR, comm);

  std::vector<int> all_search_fails(nranks, 0);
#endif


  // run script to query hopdis until all nodes have received the responses
  int iter = 0;
  int query_fail = 0;
  do {
  if ((search_fail == 1) || (iter == 0)) {
#ifdef MASTER_QUERY
  if (!myrank) {
    for (proc = 0; proc < nranks; proc++) {
      if ((iter == 0) || (all_search_fails[proc] == 1)) {
#ifndef JUST_READ_QUERY_LOG
        system(&all_command_strings[proc*NAME_LENGTH]);
#endif
      }
    }
  }
  MPI_Barrier(comm);
#else
#ifndef JUST_READ_QUERY_LOG
  system(command_string);
#endif
#endif

  fp = fopen(log_name, "r");
  if (fp == NULL) {
    fprintf(fout, "Error: node %d cannot open %s for reading!\n",
      myrank, log_name);
    fflush(fout);
    fprintf(stderr, "Error: node %d cannot open %s for reading!\n",
      myrank, log_name);
    MPI_Abort(MPI_COMM_WORLD, 1);
  }

#ifdef OPT_QUERY
  proc = myrank + 1;
#else
  proc = 0;
#endif
  search_fail = 0;
  check_next_line = 0;
  while (fgets(linebuf, sizeof(linebuf), fp)) {

    if (check_next_line == 1) {
#ifndef OPT_QUERY
      if (proc == myrank) proc++;
#endif

      // check the number of tokens by
      // counting the number of spaces
      count = 0;
      for (i = 0; i < sizeof(linebuf)-1; i++) {
        if ((linebuf[i] == '0') && (linebuf[i+1] == 'x')) {
          count++;
        }
        else if ((linebuf[i] == '\n') ||
                 (linebuf[i] == '\0') ||
                 (linebuf[i] == EOF)) {
          break;
        }
      }

      if (count == 0) { // search fail
        search_fail = 1;
        break;
      }
      else if (hopdis[proc] == -1) {
        //hopdis[proc] = count + 1; // the number of hops
		// hop count should only include the number of switches in between
		// the minimum hop coount between two nodes is 1 (not 2)
        hopdis[proc] = count; // the number of hops
      }

      fprintf(fout, "hopdis[%d] = %d\n",
        proc, hopdis[proc]);

      check_next_line = 0;
      proc++;
    }
    else if ((linebuf[0] == 'q') && (linebuf[1] == 'u') &&
             (linebuf[2] == 'e') && (linebuf[3] == 'r') &&
             (linebuf[4] == 'y')) {
      check_next_line = 1;
    }
  }

  fclose(fp);

  if (check_next_line == 1) search_fail = 1;
  //fprintf(fout, "First search_fail = %d\n", search_fail);
  }

#ifdef MASTER_QUERY
  MPI_Allgather(&search_fail, 1, MPI_INT, &all_search_fails[0], 1, MPI_INT, comm);
  query_fail = *std::max_element(all_search_fails.begin(), all_search_fails.end());
#else
  MPI_Allreduce(&search_fail, &query_fail, 1, MPI_INT, MPI_MAX, comm);  
#endif

  iter++;
  } while (query_fail == 1);

#ifdef PRINT_INFO
  if (!myrank) printf("total %d query iterations!\n", iter);
#endif

  fclose(fout);

/*
//  all_command_strings = new char [nranks*NAME_LENGTH];
//  MPI_Allgather(command_string, NAME_LENGTH, MPI_CHAR, all_command_strings,
//    NAME_LENGTH, MPI_CHAR, comm);

  for (proc = 0; proc < nranks; proc++) {
    if (all_search_fails[proc] == 0) { // first successful rank
      break;
    }
  }

  if (myrank == proc) {
    for (proc = 0; proc < nranks; proc++) {
      if (all_search_fails[proc] == 1) {
//        system(&all_command_strings[proc*NAME_LENGTH]);
      }
    }
  }

  MPI_Barrier(comm);

  if (search_fail == 1) {

    fp = fopen(log_name, "r");
    if (fp == NULL) {
      fprintf(fout, "Error: node %d cannot open %s for reading!\n",
        myrank, log_name);
      fflush(fout);
      fprintf(stderr, "Error: node %d cannot open %s for reading!\n",
        myrank, log_name);
      MPI_Abort(MPI_COMM_WORLD, 1);
    }

    proc = 0;
    search_fail = 0;
    check_next_line = 0;
    while (fgets(linebuf, sizeof(linebuf), fp)) {

      if (check_next_line == 1) {
        if (proc == myrank) proc++;

        // check the number of tokens by
        // counting the number of spaces
        count = 0;
        for (i = 0; i < sizeof(linebuf)-1; i++) {
          if ((linebuf[i] == '0') && (linebuf[i+1] == 'x')) {
            count++;
          }
          else if ((linebuf[i] == '\n') ||
                   (linebuf[i] == '\0') ||
                   (linebuf[i] == EOF)) {
            break;
          }
        }

        if (count == 0) { // search fail
          search_fail = 1;
          break;
        }
        else if (hopdis[proc] == -1) {
          hopdis[proc] = count + 1; // the number of hops
        }

        fprintf(fout, "hopdis[%d] = %d\n",
          proc, hopdis[proc]);

        check_next_line = 0;
        proc++;
      }
      else if ((linebuf[0] == 'q') && (linebuf[1] == 'u') &&
               (linebuf[2] == 'e') && (linebuf[3] == 'r') &&
               (linebuf[4] == 'y')) {
        check_next_line = 1;
      }
    }

    fclose(fp);

    if (check_next_line == 1) search_fail = 1;
    fprintf(fout, "Second search_fail = %d\n", search_fail);

    if (search_fail == 1) {
      fprintf(stderr, "Error: node %d query network topology fail!\n",
        myrank);
      MPI_Abort(MPI_COMM_WORLD, 1);
    }
  }
*/

//  delete [] all_command_strings;
}

// This function uses the neighbor joining algorithm to derive the
// fat-tree topology according to the hopdis matrix. Details of the
// neighbor joining algorithm can be found in the following paper:
// Subramoni et al. "Design of a Scalable InfiniBand Topology Service to Enable
// Network-Topology-Aware Placement of Processes", in Proc. SC'12, Nov. 2012.
static void neighbor_joining(int nnodes, std::vector<int> &all_hopdis, // hopdis matrix
  tree &nj_tree, int myrank) // neigbor joined tree
{
  std::vector<std::vector<int> > d(nnodes); // distance matrix, d[i][j] - distance between node i and j
  for (int i = 0; i < nnodes; i++) { // fill the distance matrix
    d[i].resize(nnodes);
    std::vector<int>::iterator it = all_hopdis.begin()+i*nnodes;
    std::copy(it, it+nnodes, d[i].begin());
  }
// all_hopdis.clear(); // save memory

  typedef std::pair<int, int> node_pair;
  std::vector<std::list<node_pair> > rd; // rd(m) mapping from distance m to list of node pairs
  for (int i = 0; i < nnodes; i++) { // fill rd
    for (int j = i+1; j < nnodes; j++) { // only check the pairs (i, j), which satisfy i < j
      int dis = d[i][j]; // distance between node i and j
      if (rd.size() < (size_t)dis+1) { // make sure that rd[dis] is accessible
        rd.resize(dis+1);
      }
      rd[dis].push_back(std::make_pair(i, j));
    }
  }

  std::vector<bool> a(nnodes, true); // a(i) - node i is active or not

  nj_tree.clear();
  int iter = 1;
  while (1) {
    int i, j; // node id variables
    bool found = false; // an active pair is found or not
    for (size_t dis = 0; dis < rd.size(); ++dis) {
      for (std::list<node_pair>::iterator it = rd[dis].begin(); it != rd[dis].end(); ) {
        i = it->first;
        j = it->second;
        if (a[i] && a[j]) {
          found = true; // an active pair is found
#ifdef PRINT_DEBUG
		  if (!myrank) fprintf(stderr, "inter %d: find active edge (%d, %d)\n", iter, i, j);
#endif
          break;
        }
        else { // remove inactive pairs
          rd[dis].erase(it++);
#ifdef PRINT_DEBUG
		  if (!myrank) fprintf(stderr, "inter %d: delete inactive edge (%d, %d)\n", iter, i, j);
#endif
        }
      }
      
      if (found) break;
    }

    if (!found) break; // terminate if no active edges

    // an active edge is found, we need to add a joined tree node "n"
    treenode n;
    nj_tree.push_back(n);
    int new_node = nnodes + nj_tree.size() - 1; // the id of the new non-leaf node
    nj_tree.back().id = new_node;
    std::vector<int> &children = nj_tree.back().children;
    std::vector<int> &subtree_size = nj_tree.back().subtree_size;

    children.push_back(i);
    children.push_back(j);

    int dij = d[i][j];
    // find the nearest neighbors
    for (size_t k = 0; k < d[i].size(); ++k) {
      if ((a[k]) && (d[i][k] == dij)) {
        bool add_k = true;
        for (size_t index = 1; index < children.size(); ++index) { // the first one in L is i
          int id = children[index];
          if (d[k][id] != dij) { // in fact, dij is the minimum distance value of current active node pairs
            // so it must be ture that d[k][id] >= dij
            add_k = false;
            break;
          }
        }

        if (add_k) {
		  children.push_back(k);
#ifdef PRINT_DEBUG
		  if (!myrank) fprintf(stderr, "inter %d: add node %ld\n", iter, k);
#endif
		}
      }
    }

    // children are ready, fill subtree_size
    subtree_size.resize(children.size());
    for (size_t index = 0; index < subtree_size.size(); ++index) {
      int id = children[index];
      a[id] = false; // set the joined nodes to be invalid
      if (id < nnodes) subtree_size[index] = 1; // just a leaf node
      else subtree_size[index] = nj_tree[id-nnodes].total_size; // a non-leaf node
    }
    nj_tree.back().total_size = std::accumulate(subtree_size.begin(), subtree_size.end(), 0);
#ifdef PRINT_DEBUG
	if (!myrank) fprintf(stderr, "inter %d: compute subtree_size done!\n", iter);
#endif

    // now, the joined tree node is ready
    // we need to update the distance maps: d & rd
    	std::vector<int> d_new_node;
	d.push_back(d_new_node);
	d.back().assign(a.size()+1, 0);
    for (size_t id = 0; id < a.size(); ++id) {
      if (a[id]) {
        int dis = 0;
        for (size_t index = 0; index < children.size(); ++index) {
          int k = children[index];
          if (d[id][k] > dis) dis = d[id][k]; // take max distance
        }
        d[id].push_back(dis); // add the distance between id and new_node 
		d[new_node][id] = dis;
        rd[dis].push_back(std::make_pair(id, new_node));
      }
    }
    a.push_back(true); // the joined tree node is valid
#ifdef PRINT_DEBUG
	if (!myrank) fprintf(stderr, "inter %d: update d and rd done!\n", iter);
#endif
    iter++;
  }
}

// get the topology related information
// all_hopdis: node hop distance matrix 
int TM_Gettopo_fattree(TM_env *env, MPI_Comm distgr)
{
  hwproc_info &myinfo = env->myinfo; // my hardware process information
  all_hwproc_info &allinfo = env->allinfo; // the information of all hardware processes
  hop_distances &all_hopdis = env->all_hopdis; // node hop distance matrix 
  int &nnodes = env->nnodes; // number of nodes
  tree &nj_tree = env->nj_tree; // neighbor joining tree (only store non-leaf nodes) 
  int &nranks = env->nranks;
  int &myrank = env->myrank;
  double &t_query = env->t_query;
  double &t_nj = env->t_nj;

  // get the number of ranks and my rank
  MPI_Comm_size(distgr, &nranks);
  MPI_Comm_rank(distgr, &myrank); // myrank is not used in the current function

  gethostname(myinfo.nodename, NAME_LENGTH); // node name
  for (int i = 0; i < NAME_LENGTH; ++i) {
    if (myinfo.nodename[i] == '.') {
      myinfo.nodename[i] = '\0';
      break;
    }
  }  
  // node id and core id will be determined later

  allinfo.resize(nranks);
  MPI_Allgather(&myinfo, sizeof(hwproc_info), MPI_BYTE, &allinfo[0], sizeof(hwproc_info),
    MPI_BYTE, distgr); // gather allinfo
  // As nodeid and coreid are not valid at this time, this gather may not be optimal.

  std::map<std::string, int> nodeproc; // <node name, number of processes on it>
  for (int i = 0; i < nranks; i++) {
    std::string name = allinfo[i].nodename;
    std::map<std::string, int>::iterator it = nodeproc.find(name);
    if (it == nodeproc.end()) { // not found
      nodeproc[name] = 1; // add the node 
    }
    else { // found
      it->second++; // update the counter
    }
  }

  nnodes = nodeproc.size(); // number of compute nodes
  assert(nranks%nnodes == 0);
  int nprocs_per_node = nranks/nnodes;

#ifdef PRINT_INFO
  if (!myrank) printf("nranks = %d, nnodes = %d, nprocs_per_node = %d\n",
    nranks, nnodes, nprocs_per_node);
#endif

  for (std::map<std::string, int>::const_iterator it = nodeproc.begin();
    it != nodeproc.end(); it++) {
    assert(it->second == nprocs_per_node);
  }

  // fill nodeid and coreid, make sure that each node is assigned contiguous processes 
  // This is the assumption of current implementation, we only support the default
  // consective mapping as the input. In order to support random input mappings,
  // we need to use the hwloc library to get the core id.
  std::string current_nodename;
  std::vector<std::string> all_nodenames(nnodes);
  for (int i = 0; i < nranks; i++) {

    int nodeid = i / nprocs_per_node;
    allinfo[i].nodeid = nodeid; // fill node id

    int coreid = i % nprocs_per_node;
    allinfo[i].coreid = coreid; // fill core id

    if (coreid == 0) {
      current_nodename = allinfo[i].nodename;
      all_nodenames[nodeid] = current_nodename;
    }
    else {
      std::string name = allinfo[i].nodename;
      assert(current_nodename == name); // check node name
    }
  }
  myinfo = allinfo[myrank];

  // now, allinfo is ready at each process
  
  // create a new communicator, so that we can query the network
  // topology by using one process on each compute node
  int color;
  if (myinfo.coreid == 0) color = 0; 
  else color = MPI_UNDEFINED;
  int key = myinfo.nodeid;

  MPI_Comm node_comm;
  MPI_Comm_split(distgr, color, key, &node_comm);

  all_hopdis.resize(nnodes*nnodes); // hopdis matrix
  // query the inter-node topology, i.e., the distance between nodes
  t_query = 0; // running time of query operation
  if (color == 0) {
	hop_distances hopdis;
	t_query = -MPI_Wtime();
    query_hopdis(node_comm, hopdis, all_nodenames);
	t_query += MPI_Wtime();
    //MPI_Allgather(&hopdis[0], nnodes, MPI_INT, &all_hopdis[0], nnodes, MPI_INT, node_comm);
    MPI_Gather(&hopdis[0], nnodes, MPI_INT, &all_hopdis[0], nnodes, MPI_INT, 0, node_comm);
#ifdef OPT_QUERY
	if (!myrank) { // root node
      for (int i = 0; i < nnodes; ++i) {
	    for (int j = 0; j < i; ++j) {
		  all_hopdis[i*nnodes+j] = all_hopdis[j*nnodes+i];
	    }
	  }
	}
#endif
  }

#ifdef PRINT_INFO
  if (!myrank) printf("query topology done! t_query = %f\n", t_query);
#endif

  t_nj = 0;
  t_nj = -MPI_Wtime();
  //if (nnodes < nranks) // multiple processes per node
    MPI_Bcast(&all_hopdis[0], nnodes*nnodes, MPI_INT, 0, distgr); // broadcast all_hopdis to all ranks

  neighbor_joining(nnodes, all_hopdis, nj_tree, myrank);
  t_nj += MPI_Wtime();

#ifdef PRINT_INFO
  if (!myrank) printf("neighbor joining done! t_nj = %f\n", t_nj);
#endif

  return TM_SUCCESS;
}

#endif // FAT_TREE_TOPOLOGY
