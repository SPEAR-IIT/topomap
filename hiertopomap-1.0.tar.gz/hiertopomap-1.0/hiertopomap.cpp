#include "hiertopomap.h"
#include <parmetis.h>
#include <metis.h>

// build the virtual topology graph by using the distributed graph communicator
int TM_Build_vtg(MPI_Comm distgr, TM_Graph &vtg, TM_Graph_ewgts &vtg_ewgts)
{
  // get the number of ranks and my rank
  int nranks, myrank;
  MPI_Comm_size(distgr, &nranks);
  MPI_Comm_rank(distgr, &myrank); // myrank is not used in the current function

  // get the indegree and the outdegree 
  int indegree, outdegree, weighted;
  MPI_Dist_graph_neighbors_count(distgr, &indegree, &outdegree, &weighted);

  // get the edges and their weights
  std::vector<int> sources(indegree), sourceweights(indegree); // incoming edges
  std::vector<int> destinations(outdegree), destweights(outdegree); // outgoing edges
  MPI_Dist_graph_neighbors(distgr, indegree, &sources[0], &sourceweights[0],
    outdegree, &destinations[0], &destweights[0]);

  // combine the incoming edges and the outgoing edges to get a symmetric virtual topology graph
  std::vector<int> neighbors, weights;

  // deal with the incoming edges first
  for (size_t i = 0; i < sources.size(); i++) {
    // search the edge, add it if not found; otherwise, update the edge weight
    std::vector<int>::iterator it = std::find(neighbors.begin(), neighbors.end(), sources[i]);
    if (it == neighbors.end()) { // not found 
        neighbors.push_back(sources[i]); // add the edge
        if (weighted) weights.push_back(sourceweights[i]); // store edge weight
        else weights.push_back(1); // if not weighted, set the weight to 1
    }
    else { // found
        assert(*it == sources[i]); // edge already exists
        int offset = it - neighbors.begin();
        if (weighted) weights[offset] += sourceweights[i]; // accumulate edge weights
        else weights[offset]++; // if not weighted, just increase the weight by 1
    }
  }

  // now, deal with the outgoing edges
  for (size_t i = 0; i < destinations.size(); i++) {
    // search the edge, add it if not found; otherwise, update the edge weight
    std::vector<int>::iterator it = std::find(neighbors.begin(), neighbors.end(), destinations[i]);
    if (it == neighbors.end()) { // not found 
        neighbors.push_back(destinations[i]); // add the edge
        if (weighted) weights.push_back(destweights[i]); // store edge weight
        else weights.push_back(1); // if not weighted, set the weight to 1
    }
    else { // found
        assert(*it == destinations[i]); // edge already exists
        int offset = it - neighbors.begin();
        if (weighted) weights[offset] += destweights[i]; // accumulate edge weights
        else weights[offset]++; // if not weighted, just increase the weight by 1
    }
  }

  assert(neighbors.size() == weights.size()); // check the edge counts

  // calculate the buffer size to store the whole virtual topology graph
  int degree = neighbors.size();
  std::vector<int> all_degrees(nranks);
  MPI_Allgather(&degree, 1, MPI_INT, &all_degrees[0], 1, MPI_INT, distgr); // gather degree info
  int edge_cnts = std::accumulate(all_degrees.begin(), all_degrees.end(), 0); // in fact, it is 2*number_of_edges

  std::vector<int> all_edges(edge_cnts); // all edges, note that each edge is included twice
  std::vector<int> displs(nranks); // displacement array
  displs[0] = 0;
  for (int i = 1; i < nranks; i++) {
    displs[i] = displs[i-1] + all_degrees[i-1];
  }
  MPI_Allgatherv(&neighbors[0], degree, MPI_INT, &all_edges[0], &all_degrees[0], &displs[0], MPI_INT, distgr); // gather edge info

  std::vector<int> all_ewgts(edge_cnts); // all edge weights, note that each edge is included twice
  MPI_Allgatherv(&weights[0], degree, MPI_INT, &all_ewgts[0], &all_degrees[0], &displs[0], MPI_INT, distgr); // gather edge weight info

  // save full graph in vtg
  vtg.resize(nranks);
  vtg_ewgts.resize(nranks);
  for (int i = 0; i < nranks; i++) {
    vtg[i].resize(all_degrees[i]);
    vtg_ewgts[i].resize(all_degrees[i]);
    int offset = displs[i];
    for (int j = 0; j < all_degrees[i]; j++) {
      vtg[i][j] = all_edges[offset+j];
      vtg_ewgts[i][j] = all_ewgts[offset+j];
    }
  }

  // at this point, each process has access to the virtual topology graph - vtg

#ifdef CHECK
  // check the symmetry of the virtual topology graph - vtg
  for (int i = 0; i < nranks; i++) {
    for (size_t index = 0; index < vtg[i].size(); index++) {
      int j = vtg[i][index]; // other vertex j
      std::vector<int>::iterator it = std::find(vtg[j].begin(), vtg[j].end(), i);
      if (it == vtg[j].end()) { // other edge not found
        assert(false);
      }
      else { // other edge found
        int offset = it - vtg[j].begin();
        assert(vtg_ewgts[i][index] == vtg_ewgts[j][offset]); // check the edge weight
      }
    }
  }
#endif

#ifdef PRINT_INFO
  if (!myrank) printf("build virtual topology graph done!\n");
#endif

  return 0;
}

// move vertices from overloaded parts to underloaded parts to achieve
// load balance, this function can achieve perfect balance if possible,
// otherwise, it derives the best balanced parts, i.e. the part sizes only differ by 1 
// it returns the cost (the change in edgecut)
static int balance_parts(TM_Graph &vtg, TM_Graph_ewgts &vtg_ewgts, // graph and its edge weights
  vertex_part &vpart, part_vertices &pvertices) // partition results
{
  assert(vpart.size() == vtg.size()); // partition results must be ready
  assert(pvertices.size() > 0);

  int total_cost = 0; // the change in edgecut

  int nparts = pvertices.size();
  size_t partsize = vtg.size()/nparts; // number of vertices in each part
  //assert(vtg.size()%nparts == 0); // equal partition

  // deal with imbalanced parts, move vertices from overloaded parts to underloaded parts
  int ol_part = -1; // overloaded part
  int ul_part = -1; // underloaded part
  int index1, index2; // search indices 
  index1 = 0;
  index2 = 0;
  int num_moves = 0;
  // In each iteration of this while loop, we move a vertex from an overload part
  // to an underloaded part till perfectly balance is achieved.
  while (1) {
    // search an overloaded part
    if (ol_part == -1) {
      for (; index1 < nparts; index1++) {
        if (pvertices[index1].size() > partsize) {
          ol_part = index1++;
          break;
        }
      }
    }

    // search a underloaded part
    if (ul_part == -1) {
      for (; index2 < nparts; index2++) {
        if (pvertices[index2].size() < partsize) {
          ul_part = index2++;
          break;
        }
      }
    }

    //if ((ol_part == -1) && (ul_part == -1))  // perfectly balanced, break the loop
    if (ul_part == -1) { // already balanced, break the loop
      // note that ol_part may or may not be euqal -1, 
      // it depends on if perfect balance is durable or not.
      break;
    }
    else {
      assert((ol_part != -1) && (ul_part != -1));
      // select a vertex to move from ol_part to ul_part
      int ol_partsize = pvertices[ol_part].size();
      // evaluate the cost in terms of edgecut
      std::vector<int> cost(ol_partsize, 0);
      for (int i = 0; i < ol_partsize; i++) {
        int vertex = pvertices[ol_part][i];
        int degree = vtg[vertex].size();
        for (int j = 0; j < degree; j++) {
          int other_vertex = vtg[vertex][j];
          if (vpart[other_vertex] == ol_part) cost[i] += vtg_ewgts[vertex][j];
          else if (vpart[other_vertex] == ul_part) cost[i] -= vtg_ewgts[vertex][j];
        }
      }

      // move the vertex with the minimum cost
      std::vector<int>::iterator it = std::min_element(cost.begin(), cost.end());
      total_cost += *it;
      int offset = it - cost.begin();
      int move_vertex = pvertices[ol_part][offset];
      pvertices[ol_part].erase(pvertices[ol_part].begin() + offset);
      pvertices[ul_part].push_back(move_vertex);
      vpart[move_vertex] = ul_part;
      if (pvertices[ol_part].size() == partsize) ol_part = -1;
      if (pvertices[ul_part].size() == partsize) ul_part = -1;
      num_moves++;
    }
  }

  // sort part_vertices
  for (int i = 0; i < nparts; i++) {
    assert((pvertices[i].size() == partsize) || (pvertices[i].size() == partsize+1)); // check partsize
    std::sort(pvertices[i].begin(), pvertices[i].end());
  }

  return total_cost;
}

// partition the graph into nparts
// must ensure the best balanced partition
// return the edgecut
static int graph_partition(TM_Graph &vtg, TM_Graph_ewgts &vtg_ewgts, // graph and its edge weights
  int nparts, int seed, vertex_part &vpart, part_vertices &pvertices) // partition results
{
  assert(sizeof(idx_t) == sizeof(int)); // note: type "idx_t" must be "int"
  idx_t nvtxs = vtg.size(); // number of vertices
  idx_t ncon = 1; // number of balancing constraints
  std::vector<idx_t> xadj(nvtxs+1); // edge offsets
  std::vector<idx_t> adjncy; // edges
  idx_t *vwgt = NULL; // no vertex weight, 
  idx_t *vsize= NULL; // do not specify vertex size
  std::vector<idx_t> adjwgt; // edge weight

  // fill edge information
  for (size_t i = 0 ; i < vtg.size(); i++) {
    xadj[i] = adjncy.size();
    for (size_t j = 0; j < vtg[i].size(); j++) {
      adjncy.push_back(vtg[i][j]); // edge
      adjwgt.push_back(vtg_ewgts[i][j]); // edge weight
    }
  }
  xadj[nvtxs] = adjncy.size(); // last element

  //idx_t nparts = 2; // number of parts
  real_t *tpwgts = NULL; // equal partition
  real_t *ubvec = NULL; // load imbalance tolerance, default 1.001
  idx_t options[METIS_NOPTIONS]; // METIS options
  METIS_SetDefaultOptions(options);
  options[METIS_OPTION_NUMBERING] = 0; // C style numbering
  options[METIS_OPTION_OBJTYPE] = METIS_OBJTYPE_CUT; // minimize edgecut
  options[METIS_OPTION_SEED] = seed; // random seed
  idx_t objval; // edgecut

  vpart.resize(vtg.size());
  // call METIS for paritioning
  METIS_PartGraphRecursive(&nvtxs, &ncon, &xadj[0], &adjncy[0],
    vwgt, vsize, &adjwgt[0], &nparts, tpwgts,
    ubvec, options, &objval, &vpart[0]);

  // fill part_vertices
  pvertices.resize(nparts);
  for (size_t i = 0; i < vtg.size(); i++) pvertices[vpart[i]].push_back(i);

  int edgecut = objval;
  edgecut += balance_parts(vtg, vtg_ewgts, vpart, pvertices); // balance the parts if necessary 

  return edgecut;
}

#ifdef USE_PARMETIS
// partition the virtual topology graph into balanced parts,
// where each part will be mapped onto a compute node.
// virtual topology graph - vtg; partitioned virtual topology graph - pvtg
int TM_Part_vtg(MPI_Comm distgr, TM_Graph &vtg, TM_Graph_ewgts &vtg_ewgts,
    int nparts, vertex_part &vpart, part_vertices &pvertices,
    TM_Graph &pvtg, TM_Graph_ewgts &pvtg_ewgts)
{
  // get the number of ranks and my rank
  int nranks, myrank;
  MPI_Comm_size(distgr, &nranks);
  MPI_Comm_rank(distgr, &myrank);

  // must be equally divisable
  assert(nranks%nparts == 0);
  assert(nranks/nparts > 1);

  int nprocs_per_node = nranks / nparts;

  assert(sizeof(idx_t) == sizeof(int)); // type "idx_t" must be "int"

  assert(vtg.size() == (size_t)nranks); // vtg must be ready
  std::vector<idx_t> vtxdist(nranks+1), // vertex distribution
                     xadj(2); // CSR index
                     //adjncy(vtg[myrank].size()); // CSR list
  for (int i = 0; i < nranks+1; i++) vtxdist[i] = i; // each process has a vertex
  xadj[0] = 0; xadj[1] = vtg[myrank].size();

  std::vector<idx_t> &adjncy = vtg[myrank]; // CSR list
  //std::copy(vtg[myrank].begin(), vtg[myrank].end(), adjncy.begin());

  //for (size_t i = 0; i < adjncy.size(); i++) { // we can use std::copy here if "idx_t" is "int".
  //  adjncy[i] = vtg[myrank][i];
  //}

  //std::vector<idx_t> vwgt(1,1); // set vertex weight to 1

  //std::vector<idx_t> adjwgt(vtg_ewgts[myrank].size()); // edge weights
  //std::copy(vtg_ewgts[myrank].begin(), vtg_ewgts[myrank].end(), adjwgt.begin());

  std::vector<idx_t> &adjwgt = vtg_ewgts[myrank]; // edge weights

  //for (size_t i = 0; i < adjwgt.size(); i++) { // we can use std::copy here if "idx_t" is "int".
  //  adjwgt[i] = vtg_ewgts[myrank][i];
  //}

  assert(adjncy.size() == adjwgt.size());

  //idx_t wgtflag = 3; // both vertices and edges have weights
  idx_t wgtflag = 1; // only edges have weights, vwgt is NULL
  idx_t numflag = 0; // C-style numbering that starts from 0
  idx_t ncon = 1; // number of weights that each edge has
  // note that "nparts" is the number of parts
  std::vector<real_t> tpwgts(ncon*nparts, 1.0/(real_t)nparts); // the fraction of vertex weight for each part
  std::vector<real_t> ubvec(ncon, 1.05); // imbalance tolerance for each vertex weight
  idx_t options[3] = {1,0,0}; // use 0 as random seed, so the results of different runs would be consistent
  idx_t edgecut; // edge cut 
  std::vector<idx_t> part(1); // the part id of the local vertex

  double t_parmetis = 0; // running of ParMETIS time
  MPI_Barrier(distgr); // Barrier is just used for timing
  t_parmetis = -MPI_Wtime();
  // use ParMETIS to partition the virtual topology graph
  ParMETIS_V3_PartKway(&vtxdist[0], &xadj[0], &adjncy[0], NULL, &adjwgt[0], &wgtflag, &numflag, 
    &ncon, &nparts, &tpwgts[0], &ubvec[0], options, &edgecut, &part[0], &distgr);
  MPI_Barrier(distgr);
  t_parmetis += MPI_Wtime();

#ifdef PRINT_INFO
  if (!myrank) printf("ParMETIS: running time = %.6f s, nranks = %d, nparts = %d, edgecut = %d\n",
    t_parmetis, nranks, nparts, edgecut);
#endif

  vpart.resize(nranks); // vertex_part
  MPI_Allgather(&part[0], 1, MPI_INT, &vpart[0], 1, MPI_INT, distgr); // gather partition results

  // calculate the original edgecut (for the naive parititon)
  size_t original_edgecut = 0;
  size_t metis_edgecut = 0;
  size_t total_comm = 0;
  for (int i = 0; i < nranks; ++i) {
    int node1 = i / nprocs_per_node;
	int n1 = vpart[i];
	int degree = vtg[i].size();
    for (int j = 0; j < degree; ++j) {
	  int other_vertex = vtg[i][j];
	  if (other_vertex < i) { // only count half of the edges
	    int node2 = other_vertex / nprocs_per_node;
	    int n2 = vpart[other_vertex];
		int weight = vtg_ewgts[i][j];
	    if (node1 != node2) original_edgecut += weight;
	    if (n1 != n2) metis_edgecut += weight;
	    total_comm += weight;
	  }
	}
  }

  if (original_edgecut <= metis_edgecut) {
    part[0] = myrank / nprocs_per_node;
    MPI_Allgather(&part[0], 1, MPI_INT, &vpart[0], 1, MPI_INT, distgr); // re-gather partition results
#ifdef PRINT_INFO
    if (!myrank) printf("original_edgecut = %ld, metis_edgecut = %ld, total_comm = %ld, use the naive partition\n",
	  original_edgecut, metis_edgecut, total_comm);
#endif
  }
  else {
#ifdef PRINT_INFO
    if (!myrank) printf("original_edgecut = %ld, metis_edgecut = %ld, total_comm = %ld, use the ParMETIS partition\n",
	  original_edgecut, metis_edgecut, total_comm);
#endif
  }

  // fill part_vertices
  pvertices.resize(nparts); // part_vertices
  for (int i = 0; i < nparts; i++) pvertices[i].clear();
  for (int i = 0; i < nranks; i++) pvertices[vpart[i]].push_back(i);

  balance_parts(vtg, vtg_ewgts, vpart, pvertices); // balance the parts if necessary

//#ifdef PRINT_INFO
//  if (!myrank) printf("%d moves to achieve perfect balance!\n");
//#endif

  // at this point, each process has access to the balanced partition results - vpart & pvertices 
  // Although each process adjusts the partition independently, the balanced partition is unique.
  // We may also just use one process to compute the balanced partition, and then solve broadcast
  // the solution to all the processes.

  // build the partitioned virtual topology graph, which is infact the node level communication graph
  pvtg.resize(nparts);
  for (int i = 0; i < nparts; i++) pvtg[i].clear();
  pvtg_ewgts.resize(nparts);
  for (int i = 0; i < nparts; i++) pvtg_ewgts[i].clear();
  
  for (int i = 0; i < nranks; i++) {
    int v1 = vpart[i];
    int degree = vtg[i].size();
    for (int j = 0; j < degree; j++) {
      int v2 = vpart[vtg[i][j]];
      int weight = vtg_ewgts[i][j];
      std::vector<int>::iterator it = std::find(pvtg[v1].begin(), pvtg[v1].end(), v2);
      if (it == pvtg[v1].end()) { // edge not found, add the edge
        pvtg[v1].push_back(v2);
        pvtg_ewgts[v1].push_back(weight);
      }
      else { // edge found, accumulate the edge weight
        int offset = it - pvtg[v1].begin();
        pvtg_ewgts[v1][offset] += weight;
      }
    }
  }

#ifdef CHECK
  // check the symmetry of the partitioned virtual topology graph - pvtg
  for (int i = 0; i < nparts; i++) {
    for (size_t index = 0; index < pvtg[i].size(); index++) {
      int j = pvtg[i][index]; // other vertex j
      std::vector<int>::iterator it = std::find(pvtg[j].begin(), pvtg[j].end(), i);
      if (it == pvtg[j].end()) { // other edge not found
        assert(false);
      }
      else { // other edge found
        int offset = it - pvtg[j].begin();
        assert(pvtg_ewgts[i][index] == pvtg_ewgts[j][offset]); // check the edge weight
      }
    }
  }
#endif

#ifdef PRINT_INFO
  if (!myrank) printf("build partitioned virtual topology graph done!\n");
#endif

  return 0;
}
#else
// partition the virtual topology graph into balanced parts,
// where each part will be mapped onto a compute node.
// virtual topology graph - vtg; partitioned virtual topology graph - pvtg
int TM_Part_vtg(MPI_Comm distgr, TM_Graph &vtg, TM_Graph_ewgts &vtg_ewgts,
    int nparts, vertex_part &vpart, part_vertices &pvertices,
    TM_Graph &pvtg, TM_Graph_ewgts &pvtg_ewgts)
{
  // get the number of ranks and my rank
  int nranks, myrank;
  MPI_Comm_size(distgr, &nranks);
  MPI_Comm_rank(distgr, &myrank);

  // must be equally divisable
  assert(nranks%nparts == 0);
  assert(nranks/nparts > 1);

  int nprocs_per_node = nranks / nparts;

  assert(sizeof(idx_t) == sizeof(int)); // type "idx_t" must be "int"

  double t_metis = 0; // running of ParMETIS time
  t_metis = -MPI_Wtime();
  // use METIS to partition the virtual topology graph
  int edgecut = graph_partition(vtg, vtg_ewgts, nparts, myrank, vpart, pvertices); // partition results
  t_metis += MPI_Wtime();

  std::vector<int> all_edgecuts(nranks);
  MPI_Gather(&edgecut, 1, MPI_INT, &all_edgecuts[0], 1, MPI_INT, 0, distgr);
  int opt_rank;
  if (!myrank) {
	std::vector<int>::iterator it = std::min_element(all_edgecuts.begin(), all_edgecuts.end());
    opt_rank = it - all_edgecuts.begin();
	edgecut = *it;
  }
  MPI_Bcast(&opt_rank, 1, MPI_INT, 0, distgr);
  MPI_Bcast(&vpart[0], nranks, MPI_INT, opt_rank, distgr);

#ifdef PRINT_INFO
  if (!myrank) printf("METIS: running time = %.6f s, nranks = %d, nparts = %d, edgecut = %d\n",
    t_metis, nranks, nparts, edgecut);
#endif

  // calculate the original edgecut (for the naive parititon)
  size_t original_edgecut = 0;
  size_t metis_edgecut = 0;
  size_t total_comm = 0;
  for (int i = 0; i < nranks; ++i) {
    int node1 = i / nprocs_per_node;
	int n1 = vpart[i];
	int degree = vtg[i].size();
    for (int j = 0; j < degree; ++j) {
	  int other_vertex = vtg[i][j];
	  if (other_vertex < i) { // only count half of the edges
	    int node2 = other_vertex / nprocs_per_node;
	    int n2 = vpart[other_vertex];
		int weight = vtg_ewgts[i][j];
	    if (node1 != node2) original_edgecut += weight;
	    if (n1 != n2) metis_edgecut += weight;
	    total_comm += weight;
	  }
	}
  }

  if (original_edgecut <= metis_edgecut) {
	for (int i = 0; i < nranks; ++i) vpart[i] = i / nprocs_per_node;
#ifdef PRINT_INFO
    if (!myrank) printf("original_edgecut = %ld, metis_edgecut = %ld, total_comm = %ld, use the naive partition\n",
	  original_edgecut, metis_edgecut, total_comm);
#endif
  }
  else {
#ifdef PRINT_INFO
    if (!myrank) printf("original_edgecut = %ld, metis_edgecut = %ld, total_comm = %ld, use the ParMETIS partition\n",
	  original_edgecut, metis_edgecut, total_comm);
#endif
  }

  // fill part_vertices
  pvertices.resize(nparts); // part_vertices
  for (int i = 0; i < nparts; i++) pvertices[i].clear();
  for (int i = 0; i < nranks; i++) pvertices[vpart[i]].push_back(i);

  // at this point, each process has access to the balanced partition results - vpart & pvertices 
  // Although each process adjusts the partition independently, the balanced partition is unique.
  // We may also just use one process to compute the balanced partition, and then solve broadcast
  // the solution to all the processes.

  // build the partitioned virtual topology graph, which is infact the node level communication graph
  pvtg.resize(nparts);
  for (int i = 0; i < nparts; i++) pvtg[i].clear();
  pvtg_ewgts.resize(nparts);
  for (int i = 0; i < nparts; i++) pvtg_ewgts[i].clear();
  
  for (int i = 0; i < nranks; i++) {
    int v1 = vpart[i];
    int degree = vtg[i].size();
    for (int j = 0; j < degree; j++) {
      int v2 = vpart[vtg[i][j]];
      int weight = vtg_ewgts[i][j];
      std::vector<int>::iterator it = std::find(pvtg[v1].begin(), pvtg[v1].end(), v2);
      if (it == pvtg[v1].end()) { // edge not found, add the edge
        pvtg[v1].push_back(v2);
        pvtg_ewgts[v1].push_back(weight);
      }
      else { // edge found, accumulate the edge weight
        int offset = it - pvtg[v1].begin();
        pvtg_ewgts[v1][offset] += weight;
      }
    }
  }

#ifdef CHECK
  // check the symmetry of the partitioned virtual topology graph - pvtg
  for (int i = 0; i < nparts; i++) {
    for (size_t index = 0; index < pvtg[i].size(); index++) {
      int j = pvtg[i][index]; // other vertex j
      std::vector<int>::iterator it = std::find(pvtg[j].begin(), pvtg[j].end(), i);
      if (it == pvtg[j].end()) { // other edge not found
        assert(false);
      }
      else { // other edge found
        int offset = it - pvtg[j].begin();
        assert(pvtg_ewgts[i][index] == pvtg_ewgts[j][offset]); // check the edge weight
      }
    }
  }
#endif

#ifdef PRINT_INFO
  if (!myrank) printf("build partitioned virtual topology graph done!\n");
#endif

  return 0;
}
#endif // USE_PARMETIS

// get the maximum inter-socket message size
// precondition: the graph has already been partitioned properly,
// and each part will be mapped onto a numa node (i.e. a CPU socket).
static int get_mims(TM_Graph &vtg, TM_Graph_ewgts &vtg_ewgts, vertex_part &vpart, // graph and its partition
  edge &mims_edge) // the edge with the maximum inter-socket message size
{
  assert(vpart.size() > 0); // already partitioned

  // we simply check all the edges to find the mims_edge
  // the cost is relatively high, but consider that the number of 
  // iterations for reducing mimis will be very small, the cost of
  // this routine may be acceptable
  int mims = 0;
  for (size_t i = 0; i < vtg.size(); i++) {
    int parti = vpart[i];
    for (size_t j = 0; j < vtg[i].size(); j++) {
      int k = vtg[i][j]; // edge (i, k)
      int weight = vtg_ewgts[i][j];
      int partk = vpart[k];
      if ((parti != partk) && (weight > mims)) { // not in the same part
        mims = weight;
        mims_edge = std::make_pair(i, k);
      }
    }
  }

  return mims;
}

// get the maximum intra-socket message size for a process (i.e. a vertex)
static int get_ims(TM_Graph &vtg, TM_Graph_ewgts &vtg_ewgts, vertex_part &vpart, // graph and its partition
  int vertex) // the vertex id
{
  int ims = 0;
  int p1 = vpart[vertex];
  for (size_t i = 0; i < vtg[vertex].size(); i++) {
    int other_vertex = vtg[vertex][i];
    int p2 = vpart[other_vertex];
    int weight = vtg_ewgts[vertex][i];
    if ((p1 == p2) && (weight > ims)) {
      ims = weight;
    }
  }

  return ims;
}

// iteratively exchange vertices between parts to reduce MIMS
// it returns the final MIMS value
static int refine_mims(TM_Graph &vtg, TM_Graph_ewgts &vtg_ewgts, // graph and its edge weights
  vertex_part &vpart, part_vertices &pvertices) // partition results
{
  int last_mims = -1;
  int mims;
  edge mims_edge;
  int niter = 0; // number of iterations

  while (1) {
    mims = get_mims(vtg, vtg_ewgts, vpart, mims_edge); // find the edge with MIMS
    if (mims == 0) break; // terminate if there is no inter-scoket message
    if (last_mims != -1) assert(mims <= last_mims); // mims must be non-increasing
    last_mims = mims;

    // we need to reduce mims if possible
    int v1 = mims_edge.first;
    int v2 = mims_edge.second;
    int p1 = vpart[v1];
    int p2 = vpart[v2];
    int v1_ims = get_ims(vtg, vtg_ewgts, vpart, v1);
    int v2_ims = get_ims(vtg, vtg_ewgts, vpart, v2);

    std::vector<int> p1_ims(pvertices[p1].size(), mims);
    std::vector<int> p2_ims(pvertices[p2].size(), mims);
    int v1_cost, min_p2_ims, min_p2_vertex;
    int v2_cost, min_p1_ims, min_p1_vertex;
    if (v1_ims < mims) {
      for (size_t i = 0; i < pvertices[p2].size(); i++) {
        int vertex = pvertices[p2][i];
        if (vertex != v2) {
          p2_ims[i] = get_ims(vtg, vtg_ewgts, vpart, vertex);
        }
      }
      std::vector<int>::iterator it = std::min_element(p2_ims.begin(), p2_ims.end());
      min_p2_ims = *it;
      int offset = it - p2_ims.begin();
      min_p2_vertex = pvertices[p2][offset];
      v1_cost = std::max(v1_ims, min_p2_ims);
    }
    else {
      v1_cost = v1_ims;
    }
    if (v2_ims < mims) {
      for (size_t i = 0; i < pvertices[p1].size(); i++) {
        int vertex = pvertices[p1][i];
        if (vertex != v1) {
          p1_ims[i] = get_ims(vtg, vtg_ewgts, vpart, vertex);
        }
      }
      std::vector<int>::iterator it = std::min_element(p1_ims.begin(), p1_ims.end());
      min_p1_ims = *it;
      int offset = it - p1_ims.begin();
      min_p1_vertex = pvertices[p1][offset];
      v2_cost = std::max(v2_ims, min_p1_ims);
    }
    else {
      v2_cost = v2_ims;
    }

    if (std::min(v1_cost, v2_cost) >= mims) {
      break; // we cannot reduce mims anymore, terminate
    }
    else if (v1_cost <= v2_cost) { // exchange v1 <-> min_p2_vertex
      vpart[v1] = p2;
      vpart[min_p2_vertex] = p1;
      *std::find(pvertices[p1].begin(), pvertices[p1].end(), v1) = min_p2_vertex;
      *std::find(pvertices[p2].begin(), pvertices[p2].end(), min_p2_vertex) = v1;
    }
    else { // must be v2_cost < v1_cost, exchange v2 <-> min_p1_vertex
      vpart[v2] = p1;
      vpart[min_p1_vertex] = p2;
      *std::find(pvertices[p2].begin(), pvertices[p2].end(), v2) = min_p1_vertex;
      *std::find(pvertices[p1].begin(), pvertices[p1].end(), min_p1_vertex) = v2;
    }

    niter++;
  }

  for (size_t i = 0; i < pvertices.size(); ++i)
    std::sort(pvertices[i].begin(), pvertices[i].end());

  return mims;
}

// functor for comparing node coordinates
class compare_coords {
  const coords &coords_;
  int order_[3]; // the order of the dimension sizes
  // 0, 1, 2 means x_dimension >= y_dimension >= z_dimension
public:
  explicit compare_coords(const coords &r) : coords_(r) {
    // find the range of each dimension
    //fprintf(stderr, "compare_coords ctor: 1\n");
    int min_x, max_x;
    int min_y, max_y;
    int min_z, max_z;
    min_x = coords_[0].x;
    max_x = coords_[0].x;
    min_y = coords_[0].y;
    max_y = coords_[0].y;
    min_z = coords_[0].z;
    max_z = coords_[0].z;
    //fprintf(stderr, "compare_coords ctor: 2\n");
    for (size_t i = 1; i < coords_.size(); i++) {
      if (coords_[i].x < min_x) min_x = coords_[i].x;
      else if (coords_[i].x > max_x) max_x = coords_[i].x;
      if (coords_[i].y < min_y) min_y = coords_[i].y;
      else if (coords_[i].y > max_y) max_y = coords_[i].y;
      if (coords_[i].z < min_z) min_z = coords_[i].z;
      else if (coords_[i].z > max_z) max_z = coords_[i].z;
    }
    //fprintf(stderr, "compare_coords ctor: 3\n");
    int range[3];
    range[0] = max_x - min_x + 1;
    range[1] = max_y - min_y + 1;
    range[2] = max_z - min_z + 1;
    // use insertion sort
    order_[0] = 0;
    for (int i = 1; i < 3; i++) {
      int j = i - 1;
      while ((j >= 0) && (range[i] > range[order_[j]])) {
        order_[j+1] = order_[j];
        j--;
      }
      order_[j+1] = i;
    }
    //fprintf(stderr, "order: %d %d %d\n", order_[0], order_[1], order_[2]);
  }

  bool operator()(const size_t &i, const size_t &j) const {
    //assert((i < coords_.size()) && (j < coords_.size()));
    //if ((coords_[i].x == coords_[j].x) && (coords_[i].y == coords_[j].y) && (coords_[i].z == coords_[j].z)) {
    //  fprintf(stderr, "coord[%d] = (%d,%d,%d); coord[%d] = (%d,%d,%d)\n",
    //    i, coords_[i].x, coords_[i].y, coords_[i].z, j, coords_[j].x, coords_[j].y, coords_[j].z);
    //}
    //assert(!((coords_[i].x == coords_[j].x) && (coords_[i].y == coords_[j].y) && (coords_[i].z == coords_[j].z)));
    bool ret = false; // return false if coords_[i] == coords_[j]
    for (int k = 0; k < 3; ++k) {
      if (order_[k] == 0) { // check X dimension
        if (coords_[i].x != coords_[j].x) {
          ret = (coords_[i].x < coords_[j].x);
          break;
        }
      }
      else if (order_[k] == 1) { // check Y dimension
        if (coords_[i].y != coords_[j].y) {
          ret = (coords_[i].y < coords_[j].y);
          break;
        }
      }
      else if (order_[k] == 2) { // check Z dimension
        if (coords_[i].z != coords_[j].z) {
          ret = (coords_[i].z < coords_[j].z);
          break;
        }
      }
    }
    return ret; 
  }
}; // class index_less

// perform geometric partitioning by sorting the nodes into a linear list,
// and dividing it into two parts
// we partition along the largest dimension
static void coord_bipartition(int seed, coords &node_coords, // node coordinates
  part_vertices &pcoords) // partition results
{
  //if (!seed) fprintf(stderr, "coord_bipartition: node_coords.size() = %ld\n", node_coords.size());

  // sort the nodes
  compare_coords mycompare(node_coords);
  //if (!seed) fprintf(stderr, "coord_bipartition: 1\n");

  //for (size_t i = 0; i < node_coords.size(); ++i) {
//    fprintf(stderr, "node_coords[%ld] = (%d, %d, %d)\n", i, node_coords[i].x, node_coords[i].y, node_coords[i].z);
//  }

  std::vector<int> indices(node_coords.size());
  for (size_t i = 0; i < indices.size(); i++) indices[i] = i;
//  if (!seed) fprintf(stderr, "coord_bipartition: 1.5\n");
  std::sort(indices.begin(), indices.end(), mycompare);

//  if (!seed) fprintf(stderr, "coord_bipartition: 2\n");

  // partition the nodes into two parts
  pcoords.resize(2);
  pcoords[0].resize(indices.size()/2);
  pcoords[1].resize(indices.size() - pcoords[0].size());
  std::copy(indices.begin(), indices.begin()+pcoords[0].size(), pcoords[0].begin());
  std::copy(indices.begin()+pcoords[0].size(), indices.end(), pcoords[1].begin());

  //if (!seed) fprintf(stderr, "coord_bipartition: 3\n");
}

// recursive bipartitioning mapping: find the one to one mapping of process groups to nodes
static void TM_Recursive_mapping(int level, TM_Graph &vtg, TM_Graph_ewgts &vtg_ewgts, // graph and its edge weights
  coords &node_coords, // node coordinates
#ifdef OPT_MAP
  std::vector<int> &vcomm, hop_distances &nhopdis, // vertex comm, node total_hopdis
#endif
  int seed, // random seed for METIS
  std::vector<int> &node2vertex) // mapping solution
{
  //if (!seed) fprintf(stderr, "level = %d, vtg.size() = %ld\n", level, vtg.size());

  assert(vtg.size() == node_coords.size()); // one to one mapping

  if (node_coords.size() == 1) { // just single node
    node2vertex.resize(node_coords.size());
    node2vertex[0] = 0;
    //if (!seed) fprintf(stderr, "level = %d, recursive mapping done!\n", level);
    return;
  } 

  vertex_part vpart; // graph bipartition results
  part_vertices pvertices;
  graph_partition(vtg, vtg_ewgts, 2, seed, vpart, pvertices); // vertex sets -> part0 & part1

  //if (!seed) fprintf(stderr, "level = %d, partition graph done!\n", level);

  std::vector<int> vid(vtg.size()); // vertex -> id in the subgraphs
  for (size_t i = 0; i < pvertices[0].size(); i++) vid[pvertices[0][i]] = i;
  for (size_t i = 0; i < pvertices[1].size(); i++) vid[pvertices[1][i]] = i;

  // build subgraphs
  TM_Graph vtg0(pvertices[0].size()), vtg1(pvertices[1].size());
  TM_Graph_ewgts vtg0_ewgts(pvertices[0].size()), vtg1_ewgts(pvertices[1].size());
  for (size_t i = 0; i < vtg.size(); i++) {
    int id = vid[i];
    if (vpart[i] == 0) { // build vtg0
      for (size_t j = 0; j < vtg[i].size(); j++) {
        int k = vtg[i][j];
        if (vpart[k] == 0) {
          vtg0[id].push_back(vid[k]); // add edge
          vtg0_ewgts[id].push_back(vtg_ewgts[i][j]); // add edge weight
        }
      }
    }
    else { // build vtg1
      assert(vpart[i] == 1);
      for (size_t j = 0; j < vtg[i].size(); j++) {
        int k = vtg[i][j];
        if (vpart[k] == 1) {
          vtg1[id].push_back(vid[k]); // add edge
          vtg1_ewgts[id].push_back(vtg_ewgts[i][j]); // add edge weight
        }
      }
    }
  }
#ifdef OPT_MAP
  assert(vcomm.size() == vtg.size());
  std::vector<int> vcomm0(pvertices[0].size()), vcomm1(pvertices[1].size()); // vcomm for subgraphs
  for (size_t i = 0; i < pvertices[0].size(); i++) vcomm0[i] = vcomm[pvertices[0][i]];
  for (size_t i = 0; i < pvertices[1].size(); i++) vcomm1[i] = vcomm[pvertices[1][i]];
  vcomm.clear(); // save memory
#endif

  //if (!seed) fprintf(stderr, "level = %d, build sub-graphs done!\n", level);

  // save memory
  if (level > 0) { // note: only free vtg of higher levels, we need to use the original vtg later on
    vtg.clear();
    vtg_ewgts.clear();
  }
  vid.clear();
  vpart.clear();

  //vertex_part cpart; 
  part_vertices pcoords; // coordinates bipartition results
  coord_bipartition(seed, node_coords, pcoords); // node sets -> part0 & part1

  //if (!seed) fprintf(stderr, "level = %d, partition node coords done!\n", level);

  // build subsets of nodes
  coords node_coords0(pcoords[0].size()), node_coords1(pcoords[1].size());
  for (size_t i = 0; i < pcoords[0].size(); i++) node_coords0[i] = node_coords[pcoords[0][i]];
  for (size_t i = 0; i < pcoords[1].size(); i++) node_coords1[i] = node_coords[pcoords[1][i]];

#ifdef OPT_MAP
  assert(nhopdis.size() == node_coords.size());
  hop_distances nhopdis0(pcoords[0].size()), nhopdis1(pcoords[1].size());
  for (size_t i = 0; i < pcoords[0].size(); i++) nhopdis0[i] = nhopdis[pcoords[0][i]];
  for (size_t i = 0; i < pcoords[1].size(); i++) nhopdis1[i] = nhopdis[pcoords[1][i]];
  nhopdis.clear(); // save memory
#endif
  
  // save memory (we need to keep the original node_coords at level 0)
  if (level > 0) node_coords.clear();

  bool use_direct_mapping = false; // use direct mapping (0 -> 0, 1 -> 1), otherwise, use exchanged mapping (0 -> 1, 1 -> 0)
  if (pvertices[0].size() == pvertices[1].size()) { // perfectly balanced partition
    assert(pcoords[0].size() == pcoords[1].size());
    // there are two possible mappings, we need to use the heuristic to choose the optimal one 
#ifdef OPT_MAP
    double c0 = (double)(std::accumulate(vcomm0.begin(), vcomm0.end(), 0))/(double)(vcomm0.size());
    double c1 = (double)(std::accumulate(vcomm1.begin(), vcomm1.end(), 0))/(double)(vcomm1.size());
    double d0 = (double)(std::accumulate(nhopdis0.begin(), nhopdis0.end(), 0))/(double)(nhopdis0.size());
    double d1 = (double)(std::accumulate(nhopdis1.begin(), nhopdis1.end(), 0))/(double)(nhopdis1.size());
    if (c0*d0+c1*d1 <= c0*d1+c1*d0) use_direct_mapping = true; // use direct mapping
    else use_direct_mapping = false; // use exchanged mapping
#else
    use_direct_mapping = true; // use direct mapping by default
#endif
  }
  else { // imbalanced partition, partition sizes differ by 1
    assert(abs((int)pvertices[0].size() - (int)pvertices[1].size()) == 1);
    assert(abs((int)pcoords[0].size() - (int)pcoords[1].size()) == 1);
    if (pvertices[0].size() == pcoords[0].size()) {
      assert(pvertices[1].size() == pcoords[1].size());
      use_direct_mapping = true; // use direct mapping
    }
    else {
      assert(pvertices[0].size() == pcoords[1].size());
      assert(pvertices[1].size() == pcoords[0].size());
      use_direct_mapping = false; // use exchanged mapping
    }
  }

  //if (!seed) fprintf(stderr, "level = %d, choose direct/exchanged mapping done!\n", level);

  std::vector<int> n2v0, n2v1; // node2vertex0, node2vertex1
  if (use_direct_mapping) { // use direct mapping
#ifdef OPT_MAP
    TM_Recursive_mapping(level+1, vtg0, vtg0_ewgts, node_coords0, vcomm0, nhopdis0, seed, n2v0);
    TM_Recursive_mapping(level+1, vtg1, vtg1_ewgts, node_coords1, vcomm1, nhopdis1, seed, n2v1);
#else
    TM_Recursive_mapping(level+1, vtg0, vtg0_ewgts, node_coords0, seed, n2v0);
    TM_Recursive_mapping(level+1, vtg1, vtg1_ewgts, node_coords1, seed, n2v1);
#endif
    //if (!seed) fprintf(stderr, "level = %d, generate direct mapping done!\n", level);
    //node2vertex.resize(node_coords.size());
    node2vertex.resize(pcoords[0].size() + pcoords[1].size());
    //fprintf(stderr, "node2vertex.size() = %ld, pcoords.size() = %ld, pccords[0].size() = %ld, pccords[1].size() = %ld, n2v0.size() = %ld\n",
    //  node2vertex.size(), pcoords.size(), pcoords[0].size(), pcoords[1].size(), n2v0.size());
    for (size_t i = 0; i < n2v0.size(); i++) {
    //  fprintf(stderr, "pcoords[0][%d] = %d, n2v0[%d] = %d\n",
    //    i, pcoords[0][i], i, n2v0[i]);
      node2vertex[pcoords[0][i]] = pvertices[0][n2v0[i]];
    }
    for (size_t i = 0; i < n2v1.size(); i++) node2vertex[pcoords[1][i]] = pvertices[1][n2v1[i]];
  }
  else { // use exchanged mapping
#ifdef OPT_MAP
    TM_Recursive_mapping(level+1, vtg0, vtg0_ewgts, node_coords1, vcomm0, nhopdis1, seed, n2v0); // 0 -> 1
    TM_Recursive_mapping(level+1, vtg1, vtg1_ewgts, node_coords0, vcomm1, nhopdis0, seed, n2v1); // 1 -> 0
#else
    TM_Recursive_mapping(level+1, vtg0, vtg0_ewgts, node_coords1, seed, n2v0); // 0 -> 1
    TM_Recursive_mapping(level+1, vtg1, vtg1_ewgts, node_coords0, seed, n2v1); // 1 -> 0
#endif
    //if (!seed) fprintf(stderr, "level = %d, generate exchanged mapping done!\n", level);
    //node2vertex.resize(node_coords.size());
    node2vertex.resize(pcoords[0].size() + pcoords[1].size());
    for (size_t i = 0; i < n2v0.size(); i++) node2vertex[pcoords[1][i]] = pvertices[0][n2v0[i]];
    for (size_t i = 0; i < n2v1.size(); i++) node2vertex[pcoords[0][i]] = pvertices[1][n2v1[i]];
  }

  //if (!seed) fprintf(stderr, "level = %d, recursive mapping done!\n", level);
}

// move vertices from overloaded parts to underloaded parts to achieve
// load balance according to given part sizes
// it returns the cost (the change in edgecut)
static int balance_parts_givensize(TM_Graph &vtg, TM_Graph_ewgts &vtg_ewgts, // graph and its edge weights
  std::vector<int> &part_sizes, vertex_part &vpart, part_vertices &pvertices) // partition results
{
  assert(vpart.size() == vtg.size()); // partition results must be ready
  assert(pvertices.size() > 0);
  assert(part_sizes.size() == pvertices.size()); // part sizes are given

  int total_cost = 0; // the change in edgecut

  int nparts = pvertices.size();

  // deal with imbalanced parts, move vertices from overloaded parts to underloaded parts
  int ol_part = -1; // overloaded part
  int ul_part = -1; // underloaded part
  int index1, index2; // search indices 
  index1 = 0;
  index2 = 0;
  int num_moves = 0;
  // In each iteration of this while loop, we move a vertex from an overload part
  // to an underloaded part till perfectly balance is achieved.
  while (1) {
    // search an overloaded part
    if (ol_part == -1) {
      for (; index1 < nparts; index1++) {
        if (pvertices[index1].size() > part_sizes[index1]) {
          ol_part = index1++;
          break;
        }
      }
    }

    // search a underloaded part
    if (ul_part == -1) {
      for (; index2 < nparts; index2++) {
        if (pvertices[index2].size() < part_sizes[index2]) {
          ul_part = index2++;
          break;
        }
      }
    }

    //if ((ol_part == -1) && (ul_part == -1))  // perfectly balanced, break the loop
    if (ul_part == -1) { // already balanced, break the loop
      assert(ol_part == -1); // note that ol_part must be euqal -1, 
      break;
    }
    else {
      assert((ol_part != -1) && (ul_part != -1));
      // select a vertex to move from ol_part to ul_part
      int ol_partsize = pvertices[ol_part].size();
      // evaluate the cost in terms of edgecut
      std::vector<int> cost(ol_partsize, 0);
      for (int i = 0; i < ol_partsize; i++) {
        int vertex = pvertices[ol_part][i];
        int degree = vtg[vertex].size();
        for (int j = 0; j < degree; j++) {
          int other_vertex = vtg[vertex][j];
          if (vpart[other_vertex] == ol_part) cost[i] += vtg_ewgts[vertex][j];
          else if (vpart[other_vertex] == ul_part) cost[i] -= vtg_ewgts[vertex][j];
        }
      }

      // move the vertex with the minimum cost
      std::vector<int>::iterator it = std::min_element(cost.begin(), cost.end());
      total_cost += *it;
      int offset = it - cost.begin();
      int move_vertex = pvertices[ol_part][offset];
      pvertices[ol_part].erase(pvertices[ol_part].begin() + offset);
      pvertices[ul_part].push_back(move_vertex);
      vpart[move_vertex] = ul_part;
      if (pvertices[ol_part].size() == part_sizes[ol_part]) ol_part = -1;
      if (pvertices[ul_part].size() == part_sizes[ul_part]) ul_part = -1;
      num_moves++;
    }
  }

  // sort part_vertices
  for (int i = 0; i < nparts; i++) {
    assert(pvertices[i].size() == (size_t)part_sizes[i]); // check part sizes
    std::sort(pvertices[i].begin(), pvertices[i].end());
  }

  return total_cost;
}

// partition the graph into nparts according to the given part sizes
static int graph_partition_givensize(TM_Graph &vtg, TM_Graph_ewgts &vtg_ewgts, // graph and its edge weights
  int nparts, std::vector<int> &part_sizes, int seed, vertex_part &vpart, part_vertices &pvertices) // partition results
{
  assert(sizeof(idx_t) == sizeof(int)); // note: type "idx_t" must be "int"
  idx_t nvtxs = vtg.size(); // number of vertices
  idx_t ncon = 1; // number of balancing constraints
  std::vector<idx_t> xadj(nvtxs+1); // edge offsets
  std::vector<idx_t> adjncy; // edges
  idx_t *vwgt = NULL; // no vertex weight, 
  idx_t *vsize= NULL; // do not specify vertex size
  std::vector<idx_t> adjwgt; // edge weight

  // fill edge information
  for (size_t i = 0 ; i < vtg.size(); i++) {
    xadj[i] = adjncy.size();
    for (size_t j = 0; j < vtg[i].size(); j++) {
      adjncy.push_back(vtg[i][j]); // edge
      adjwgt.push_back(vtg_ewgts[i][j]); // edge weight
    }
  }
  xadj[nvtxs] = adjncy.size(); // last element

  assert(vtg.size() == (size_t)std::accumulate(part_sizes.begin(), part_sizes.end(), 0));
  assert(part_sizes.size() == (size_t)nparts);
  std::vector<real_t> tpwgts(nparts); // unequal partition
  for (int i = 0; i < nparts; ++i) tpwgts[i] = (double)part_sizes[i] / (double)vtg.size();

  real_t *ubvec = NULL; // load imbalance tolerance, default 1.001
  idx_t options[METIS_NOPTIONS]; // METIS options
  METIS_SetDefaultOptions(options);
  options[METIS_OPTION_NUMBERING] = 0; // C style numbering
  options[METIS_OPTION_OBJTYPE] = METIS_OBJTYPE_CUT; // minimize edgecut
  options[METIS_OPTION_SEED] = seed; // random seed
  idx_t objval; // edgecut

  vpart.resize(vtg.size());
  // call METIS for paritioning
  METIS_PartGraphRecursive(&nvtxs, &ncon, &xadj[0], &adjncy[0],
    vwgt, vsize, &adjwgt[0], &nparts, &tpwgts[0],
    ubvec, options, &objval, &vpart[0]);

  // fill part_vertices
  pvertices.resize(nparts);
  for (size_t i = 0; i < vtg.size(); ++i) pvertices[vpart[i]].push_back(i);

  int edgecut = objval;
  edgecut += balance_parts_givensize(vtg, vtg_ewgts, part_sizes, vpart, pvertices); // balance the parts if necessary 

  return edgecut;
}

// this function performs topology mapping according to the neighbor joining tree 
// it computes the one-to-one mapping of processes (or process groups) onto compute nodes
static void TM_Tree_mapping(int level, // level of recursion, currently not used (may be used for memory management)
  TM_Graph &vtg, TM_Graph_ewgts &vtg_ewgts, // graph and its edge weights
  tree &nj_tree, // neighbor joining tree
  int tree_root, // the root of the subtree for mapping
  std::vector<int> &vertices, // the subset of vertices (in the original communication graph) corresponding to tree_root
  int seed, // random seed for METIS
  std::vector<int> &node2vertex) // mapping solution
{
  int nnodes = nj_tree[0].id; // the id of the first non-leaf node of the tree is euqal to the number of nodes
  assert(node2vertex.size() == (size_t)nnodes);
  int tree_root_index = tree_root - nnodes;

  int &total_size = nj_tree[tree_root_index].total_size;
#ifdef PRINT_DEBUG
  if (!seed) fprintf(stderr, "level %d: vtg.size() = %ld, vertices.size() = %ld, tree_root_index = %d, total_size = %d\n",
    level, vtg.size(), vertices.size(), tree_root_index, total_size);
#endif
  assert(vertices.size() == (size_t)total_size);
  std::vector<int> &children = nj_tree[tree_root_index].children;
  std::vector<int> &subtree_size = nj_tree[tree_root_index].subtree_size;

  vertex_part vpart; // graph bipartition results
  part_vertices pvertices;
  int nparts = children.size();

  if (nparts == total_size) { // each part is just a single vertex, apply direct mapping
    for (int i = 0; i < nparts; ++i) {
      node2vertex[children[i]] = vertices[i];
    }
    return;
  }

  // partition the graph according to the subtree root
  graph_partition_givensize(vtg, vtg_ewgts, nparts, subtree_size, seed, vpart, pvertices);

  std::vector<int> vid(vtg.size()); // vertex -> id in the subgraphs
  for (size_t i = 0; i < pvertices.size(); ++i) {
    for (size_t j = 0; j < pvertices[i].size(); ++j) {
      vid[pvertices[i][j]] = j;
    }
  }

  // build subgraphs and perform recursive mapping
  for (size_t partid = 0; partid < pvertices.size(); ++partid) {
    if (pvertices[partid].size() == 1) { // just one vertex, direct mapping
      assert(children[partid] < nnodes);
      node2vertex[children[partid]] = vertices[pvertices[partid][0]];
      continue;
    }

    TM_Graph sub_vtg(pvertices[partid].size());
    TM_Graph_ewgts sub_vtg_ewgts(pvertices[partid].size());

    // build the subgraph
    for (size_t i = 0; i < pvertices[partid].size(); ++i) {
      int v1 = pvertices[partid][i];
      for (size_t j = 0; j < vtg[v1].size(); ++j) {
        int v2 = vtg[v1][j];
        if ((size_t)vpart[v2] == partid) { // the same part
          sub_vtg[i].push_back(vid[v2]); // add the edge
          sub_vtg_ewgts[i].push_back(vtg_ewgts[v1][j]); // edge weight
        }
      }
    }

    int subtree_root = children[partid];
    std::vector<int> sub_vertices(sub_vtg.size());
    for (size_t i = 0; i < pvertices[partid].size(); ++i) {
      sub_vertices[i] = vertices[pvertices[partid][i]];
    }
    TM_Tree_mapping(level+1, sub_vtg, sub_vtg_ewgts, nj_tree, subtree_root, sub_vertices, seed, node2vertex);
  }
}

static void subtree_map(tree &nj_tree, int nnodes, int subtree_root, std::vector<int> &node2vertex, int vertex)
{
  if (subtree_root < nnodes) {
    node2vertex[subtree_root] = vertex;
  }
  else {
    int subtree_root_index = subtree_root - nnodes;
    std::vector<int> &children = nj_tree[subtree_root_index].children;
	for (size_t i = 0; i < children.size(); ++i) {
      subtree_map(nj_tree, nnodes, children[i], node2vertex, vertex);
    }
  }
}

// this function performs topology mapping according to the intra-node topology tree
// it computes the mapping of processes onto processing units (PUs) 
// Note: the number of processing units may be larger than the number of processes
static void TM_Tree_mapping_intra_node(int level, // level of recursion, currently not used (may be used for memory management)
  TM_Graph &vtg, TM_Graph_ewgts &vtg_ewgts, // graph and its edge weights
  tree &nj_tree, // neighbor joining tree
  int tree_root, // the root of the subtree for mapping
  std::vector<int> &vertices, // the subset of vertices (in the original communication graph) corresponding to tree_root
  int seed, // random seed for METIS
  std::vector<int> &node2vertex) // mapping solution
{
  int nnodes = nj_tree[0].id; // the id of the first non-leaf node of the tree is euqal to the number of nodes
  assert(node2vertex.size() == (size_t)nnodes);
  int tree_root_index = tree_root - nnodes;

  int &total_size = nj_tree[tree_root_index].total_size;
#ifdef PRINT_DEBUG
  if (!seed) fprintf(stderr, "level %d: vtg.size() = %ld, vertices.size() = %ld, tree_root_index = %d, total_size = %d\n",
    level, vtg.size(), vertices.size(), tree_root_index, total_size);
#endif
  int npus_per_proc = total_size / vertices.size();
  assert(total_size % vertices.size() == 0);
  //assert(vertices.size() == (size_t)total_size);
  std::vector<int> &children = nj_tree[tree_root_index].children;
  std::vector<int> &subtree_size = nj_tree[tree_root_index].subtree_size;

  vertex_part vpart; // graph bipartition results
  part_vertices pvertices;
  int nparts = children.size();

  if (nparts == total_size) { // each child is just a leaf node (i.e. a PU), apply direct mapping
    int offset = 0;
    for (size_t i = 0; i < vertices.size(); ++i) {
	  for (int j = 0; j < npus_per_proc; ++j) {
        node2vertex[children[offset++]] = vertices[i];
	  }
    }
    return;
  }

  std::vector<int> part_sizes(subtree_size.size());
  std::copy(subtree_size.begin(), subtree_size.end(), part_sizes.begin());
  for (size_t i = 0; i < part_sizes.size(); ++i) {
	assert(part_sizes[i] % npus_per_proc == 0);
    part_sizes[i] /= npus_per_proc;
  }
  // partition the graph according to the subtree root
  graph_partition_givensize(vtg, vtg_ewgts, nparts, part_sizes, seed, vpart, pvertices);

  std::vector<int> vid(vtg.size()); // vertex -> id in the subgraphs
  for (size_t i = 0; i < pvertices.size(); ++i) {
    for (size_t j = 0; j < pvertices[i].size(); ++j) {
      vid[pvertices[i][j]] = j;
    }
  }

  // build subgraphs and perform recursive mapping
  for (size_t partid = 0; partid < pvertices.size(); ++partid) {
    if (pvertices[partid].size() == 1) { // just one vertex, direct mapping
      //assert(children[partid] < nnodes);
      //node2vertex[children[partid]] = vertices[pvertices[partid][0]];

	  int vertex = vertices[pvertices[partid][0]];
	  subtree_map(nj_tree, nnodes, children[partid], node2vertex, vertex);
      continue;
    }

    TM_Graph sub_vtg(pvertices[partid].size());
    TM_Graph_ewgts sub_vtg_ewgts(pvertices[partid].size());

    // build the subgraph
    for (size_t i = 0; i < pvertices[partid].size(); ++i) {
      int v1 = pvertices[partid][i];
      for (size_t j = 0; j < vtg[v1].size(); ++j) {
        int v2 = vtg[v1][j];
        if ((size_t)vpart[v2] == partid) { // the same part
          sub_vtg[i].push_back(vid[v2]); // add the edge
          sub_vtg_ewgts[i].push_back(vtg_ewgts[v1][j]); // edge weight
        }
      }
    }

    int subtree_root = children[partid];
    std::vector<int> sub_vertices(sub_vtg.size());
    for (size_t i = 0; i < pvertices[partid].size(); ++i) {
      sub_vertices[i] = vertices[pvertices[partid][i]];
    }
    TM_Tree_mapping(level+1, sub_vtg, sub_vtg_ewgts, nj_tree, subtree_root, sub_vertices, seed, node2vertex);
  }
}

// build intra-node virtual topology graph - ivtg
static int TM_Build_ivtg(TM_Graph &vtg, TM_Graph_ewgts &vtg_ewgts, // virtual topology graph - vtg
  int myrank, int nprocs_per_node, std::vector<int> &rank2newrank, // inter-node mapping solution
  TM_Graph &ivtg, TM_Graph_ewgts &ivtg_ewgts) // intra-node virtual topology graph - ivtg
{
  int nodeid = myrank/nprocs_per_node;
  int offset = nodeid*nprocs_per_node;
  // create local vertex id map 
  std::map<int, int> vid; // vertex id
  for (int i = 0; i < nprocs_per_node; i++) {
    vid[rank2newrank[offset+i]] = i;
  }

  ivtg.resize(nprocs_per_node); // ivtg - intra-node virtual topology graph
  ivtg_ewgts.resize(nprocs_per_node); // ivtg edge weights 

  // build ivtg
  for (int i = 0; i < nprocs_per_node; i++) {
    int v1 = rank2newrank[offset+i];
    for (size_t j = 0; j < vtg[v1].size(); j++) {
      int v2 = vtg[v1][j];
      std::map<int, int>::iterator it = vid.find(v2);
      if (it != vid.end()) {
        ivtg[i].push_back(it->second);
        ivtg_ewgts[i].push_back(vtg_ewgts[v1][j]);
      }
    }
  }

  return 0;
}

#ifdef FAT_TREE_TOPOLOGY // supports TACC Stampede, non-contiguous allocation

// print the statistics of evaluation metrics for the most recently
// computed mapping
int TM_Metrics_fattree(TM_env *env, MPI_Comm distgr)
{
  if (!env->map_ready) return TM_ERR_MAP;

  // get the number of ranks and my rank, check the communicator is consistent or not
  int nranks, myrank;
  MPI_Comm_size(distgr, &nranks);
  MPI_Comm_rank(distgr, &myrank);

#ifdef CHECK
  int err_comm;
  if ((nranks == env->nranks) && (myrank == env->myrank)) err_comm = 0;
  else err_comm = 1;

  int all_err_comm;
  MPI_Allreduce(&err_comm, &all_err_comm, 1, MPI_INT, MPI_MAX, distgr);

  if (all_err_comm == 1) return TM_ERR_COMM; 
#endif

  //hwproc_info &myinfo = env->myinfo; // my hardware process information
  all_hwproc_info &allinfo = env->allinfo; // the information of all hardware processes
  hop_distances &all_hopdis = env->all_hopdis; // node hop distance matrix 
  int &nnodes = env->nnodes; // number of nodes
  //tree &nj_tree = env->nj_tree; // neighbor joining tree (only store non-leaf nodes) 
  TM_Graph &vtg = env->vtg; // vtg - virtual topology graph
  TM_Graph_ewgts &vtg_ewgts = env->vtg_ewgts; // vtg edge weights
  int &mapper = env->mapper;
  int &intra_obj = env->intra_obj;
  size_t &hop_bytes = env->hop_bytes;
  int &newrank = env->newrank;
  std::vector<int> &rank2newrank = env->rank2newrank; // mapping from rank to newrank
  std::vector<int> &newrank2rank = env->newrank2rank; // mapping from newrank to rank

  MPI_Gather(&newrank, 1, MPI_INT, &rank2newrank[0], 1, MPI_INT, 0, distgr);
  
  newrank2rank.resize(nranks); // mapping from newrank to rank
  for (int i = 0; i < nranks; i++) newrank2rank[rank2newrank[i]] = i;

  // compute metrics and print
  if (!myrank) {
	
    printf("**************************************************************\n");
    printf("statistics of topology mapping metrics:\n");
	if (mapper == TM_MAPPER_INTER) printf("mapper = TM_MAPPER_INTER: inter-node mapping only\n");
	else if (mapper == TM_MAPPER_HIER) {
	  printf("mapper = TM_MAPPER_HIER: hierarchical mapping, including both inter- and intra-node mapping\n");
	  if (intra_obj == TM_OBJ_EDGECUT) printf("intra_obj = TM_OBJ_EDGECUT: minimize edgecut for intra-node mapping\n");
	  else if (intra_obj == TM_OBJ_MIMS) printf("intra_obj = TM_OBJ_MIMS: minimize MIMS for intra-node mapping\n");
	}

    printf("execution time: t_gettopo = %f; major components: t_query = %f, t_nj = %f\n",
	  env->t_gettopo, env->t_query, env->t_nj);
    printf("execution time: t_topomap = %f; major components: t_vtg = %f, t_inter_map = %f, t_intra_map = %f\n",
	  env->t_topomap, env->t_vtg, env->t_inter_map, env->t_intra_map);
				 
    // compute and print hop-bytes
    size_t default_hop_bytes = 0;
    for (size_t i = 0; i < vtg.size(); i++) { // proc
      for (size_t j = 0; j < vtg[i].size(); j++) { // edge
        int hop = all_hopdis[allinfo[i].nodeid * nnodes + allinfo[vtg[i][j]].nodeid];
        default_hop_bytes += hop * vtg_ewgts[i][j];
      }
    }
    printf("default_hop_bytes = %ld, hop_bytes = %ld, reduction = %.2f%%\n",
      default_hop_bytes, hop_bytes, ((double)default_hop_bytes - (double)hop_bytes)/(double)default_hop_bytes*100.0);

	// compute and print average hops
	size_t total_bytes = 0;
	for (size_t i = 0; i < vtg.size(); ++i) {
	  for (size_t j = 0; j < vtg[i].size(); ++j) {
		total_bytes += vtg_ewgts[i][j];
	  }
	}
	double default_average_hops = (double)default_hop_bytes/(double)total_bytes;
	double average_hops = (double)hop_bytes/(double)total_bytes;
    printf("default_average_hops = %f, average_hops = %f, reduction = %.2f%%\n",
      default_average_hops, average_hops, (default_average_hops - average_hops)/default_average_hops*100.0);

	// compute default communication statistics
	std::vector<size_t> total_comm_dis(10, 0);
	std::vector<std::vector<size_t> > comm_dis(vtg.size());
    for (size_t i = 0; i < vtg.size(); ++i) comm_dis[i].assign(10, 0);

	int nprocs_per_node = nranks / nnodes;
	int nprocs_per_socket = nprocs_per_node / 2;
	assert(nranks % nnodes == 0);
	assert(nprocs_per_node % 2 == 0);

	int avg_intra_socket_comm;
	size_t total_intra_socket_comm = 0;
	size_t total_intra_socket_comm_cnt = 0;
    int max_intra_socket_comm = 0;

    int avg_inter_socket_comm;
	size_t total_inter_socket_comm = 0;
	size_t total_inter_socket_comm_cnt = 0;
    int max_inter_socket_comm = 0;
	
    for (size_t i = 0; i < vtg.size(); i++) { // proc
	  //int hwproc1 = newrank2rank[i];
	  int hwproc1 = i; 
	  int node1 = hwproc1 / nprocs_per_node;
	  int socket1 = hwproc1 / nprocs_per_socket;
      for (size_t j = 0; j < vtg[i].size(); j++) { // edge
		//int hwproc2 = newrank2rank[vtg[i][j]];
		int hwproc2 = vtg[i][j];
	    int node2 = hwproc2 / nprocs_per_node;
		int socket2 = hwproc2 / nprocs_per_socket;

		if (node1 == node2) { // on the same node
		  if (socket1 == socket2) { // on the same socket
			total_comm_dis[0] += vtg_ewgts[i][j]; // intra-socket communication
			comm_dis[i][0] += vtg_ewgts[i][j]; // intra-socket communication

			total_intra_socket_comm += vtg_ewgts[i][j];
			total_intra_socket_comm_cnt++;
			if (vtg_ewgts[i][j] > max_intra_socket_comm) max_intra_socket_comm = vtg_ewgts[i][j];
		  }
		  else {
			total_comm_dis[1] += vtg_ewgts[i][j]; // inter-socket communication
			comm_dis[i][1] += vtg_ewgts[i][j]; // inter-socket communication

			total_inter_socket_comm += vtg_ewgts[i][j];
			total_inter_socket_comm_cnt++;
			if (vtg_ewgts[i][j] > max_inter_socket_comm) max_inter_socket_comm = vtg_ewgts[i][j];
		  }
		}
		else {
          int hop = all_hopdis[allinfo[hwproc1].nodeid * nnodes + allinfo[hwproc2].nodeid];
		  assert(hop >= 1);
		  if (hop <= 7) {
			total_comm_dis[hop+1] += vtg_ewgts[i][j]; // inter-node communication, <= 7 hops
			comm_dis[i][hop+1] += vtg_ewgts[i][j]; // inter-node communication, <= 7 hops
		  }
		  else {
			total_comm_dis[9] += vtg_ewgts[i][j]; // inter-node communication, >= 8 hops
			comm_dis[i][9] += vtg_ewgts[i][j]; // inter-node communication, >= 8 hops
		  }
		}
      }
    }

	avg_intra_socket_comm = total_intra_socket_comm / total_intra_socket_comm_cnt;
	avg_inter_socket_comm = total_inter_socket_comm / total_inter_socket_comm_cnt;

	std::vector<double> total_comm_dis_percentage(10);
	std::vector<std::vector<double> > comm_dis_percentage(vtg.size());
    for (size_t i = 0; i < vtg.size(); ++i) comm_dis_percentage[i].resize(10);

	size_t total_comm = std::accumulate(total_comm_dis.begin(), total_comm_dis.end(), 0);
	for (int i = 0; i < 10; ++i) total_comm_dis_percentage[i] = (double)total_comm_dis[i] / (double)total_comm * 100.0;

	for (size_t i = 0; i < vtg.size(); ++i) {
	  size_t total_comm_i = std::accumulate(comm_dis[i].begin(), comm_dis[i].end(), 0);
	  for (int j = 0; j < 10; ++j) comm_dis_percentage[i][j] = (double)comm_dis[i][j] / (double)total_comm_i * 100.0;
	}

	printf("original avg_intra_socket_comm = %d, max_intra_socket_comm = %d\n",
	  avg_intra_socket_comm, max_intra_socket_comm);
	printf("original avg_inter_socket_comm = %d, max_inter_socket_comm = %d\n",
	  avg_inter_socket_comm, max_inter_socket_comm);
	printf("original communication statistics (up to 64 processes, in percentage, %% is omitted):\n");
	printf("total/process id");
	for (int i = 0; i < 10; ++i) {
	  if (i == 0) printf("\tintra-socket");
	  else if (i == 1) printf("\tinter-socket");
	  else if (i == 2) printf("\t1 hop");
	  else if (i <= 8) printf("\t%d hops", i-1);
	  else printf("\t>=8 hops\n");
	}
	printf("total");
	for (int i = 0; i < 10; ++i) printf("\t%f", total_comm_dis_percentage[i]);
	printf("\n");
	for (size_t i = 0; i < std::min(vtg.size(), (size_t)64); ++i) {
	  printf("%ld", i);
	  for (int j = 0; j < 10; ++j) printf("\t%f", comm_dis_percentage[i][j]);
	  printf("\n");
	}

	// compute mapped communication statistics
	total_comm_dis.assign(10, 0);
	comm_dis.resize(vtg.size());
    for (size_t i = 0; i < vtg.size(); ++i) comm_dis[i].assign(10, 0);

	total_intra_socket_comm = 0;
	total_intra_socket_comm_cnt = 0;
    max_intra_socket_comm = 0;

	total_inter_socket_comm = 0;
	total_inter_socket_comm_cnt = 0;
    max_inter_socket_comm = 0;

    for (size_t i = 0; i < vtg.size(); i++) { // proc
	  int hwproc1 = newrank2rank[i];
	  //int hwproc1 = i; 
	  int node1 = hwproc1 / nprocs_per_node;
	  int socket1 = hwproc1 / nprocs_per_socket;
      for (size_t j = 0; j < vtg[i].size(); j++) { // edge
		int hwproc2 = newrank2rank[vtg[i][j]];
		//int hwproc2 = vtg[i][j];
	    int node2 = hwproc2 / nprocs_per_node;
		int socket2 = hwproc2 / nprocs_per_socket;

		if (node1 == node2) { // on the same node
		  if (socket1 == socket2) { // on the same socket
			total_comm_dis[0] += vtg_ewgts[i][j]; // intra-socket communication
			comm_dis[i][0] += vtg_ewgts[i][j]; // intra-socket communication

			total_intra_socket_comm += vtg_ewgts[i][j];
			total_intra_socket_comm_cnt++;
			if (vtg_ewgts[i][j] > max_intra_socket_comm) max_intra_socket_comm = vtg_ewgts[i][j];
		  }
		  else {
			total_comm_dis[1] += vtg_ewgts[i][j]; // inter-socket communication
			comm_dis[i][1] += vtg_ewgts[i][j]; // intra-socket communication

			total_inter_socket_comm += vtg_ewgts[i][j];
			total_inter_socket_comm_cnt++;
			if (vtg_ewgts[i][j] > max_inter_socket_comm) max_inter_socket_comm = vtg_ewgts[i][j];
		  }
		}
		else {
          int hop = all_hopdis[allinfo[hwproc1].nodeid * nnodes + allinfo[hwproc2].nodeid];
		  assert(hop >= 1);
		  if (hop <= 7) {
			total_comm_dis[hop+1] += vtg_ewgts[i][j]; // inter-node communication, <= 7 hops
			comm_dis[i][hop+1] += vtg_ewgts[i][j]; // inter-node communication, <= 7 hops
		  }
		  else {
			total_comm_dis[9] += vtg_ewgts[i][j]; // inter-node communication, >= 8 hops
			comm_dis[i][9] += vtg_ewgts[i][j]; // inter-node communication, >= 8 hops
		  }
		}
      }
    }

	avg_intra_socket_comm = total_intra_socket_comm / total_intra_socket_comm_cnt;
	avg_inter_socket_comm = total_inter_socket_comm / total_inter_socket_comm_cnt;

	total_comm = std::accumulate(total_comm_dis.begin(), total_comm_dis.end(), 0);
	for (int i = 0; i < 10; ++i) total_comm_dis_percentage[i] = (double)total_comm_dis[i] / (double)total_comm * 100.0;

	for (size_t i = 0; i < vtg.size(); ++i) {
	  size_t total_comm_i = std::accumulate(comm_dis[i].begin(), comm_dis[i].end(), 0);
	  for (int j = 0; j < 10; ++j) comm_dis_percentage[i][j] = (double)comm_dis[i][j] / (double)total_comm_i * 100.0;
	}

	printf("mapped avg_intra_socket_comm = %d, max_intra_socket_comm = %d\n",
	  avg_intra_socket_comm, max_intra_socket_comm);
	printf("mapped avg_inter_socket_comm = %d, max_inter_socket_comm = %d\n",
	  avg_inter_socket_comm, max_inter_socket_comm);
	printf("mapped communication statistics (up to 64 processes, in percentage, %% is omitted):\n");
	printf("total/process id");
	for (int i = 0; i < 10; ++i) {
	  if (i == 0) printf("\tintra-socket");
	  else if (i == 1) printf("\tinter-socket");
	  else if (i == 2) printf("\t1 hop");
	  else if (i <= 8) printf("\t%d hops", i-1);
	  else printf("\t>=8 hops\n");
	}
	printf("total");
	for (int i = 0; i < 10; ++i) printf("\t%f", total_comm_dis_percentage[i]);
	printf("\n");
	for (size_t i = 0; i < std::min(vtg.size(), (size_t)64); ++i) {
	  printf("%ld", i);
	  for (int j = 0; j < 10; ++j) printf("\t%f", comm_dis_percentage[i][j]);
	  printf("\n");
	}
  }

  return TM_SUCCESS;
}

int TM_Topomap_fattree(TM_env *env, MPI_Comm distgr, int *newrank)
{
  if (!env->topo_ready) return TM_ERR_TOPO;

  // get the number of ranks and my rank
  int nranks, myrank;
  MPI_Comm_size(distgr, &nranks);
  MPI_Comm_rank(distgr, &myrank);

#ifdef CHECK
  int err_comm;
  if ((nranks == env->nranks) && (myrank == env->myrank)) err_comm = 0;
  else err_comm = 1;

  int all_err_comm;
  MPI_Allreduce(&err_comm, &all_err_comm, 1, MPI_INT, MPI_MAX, distgr);

  if (all_err_comm == 1) return TM_ERR_COMM; 
#endif
  
/*
  const int TM_MAPPER_INTER = 0; // inter-node mapping 
  const int TM_MAPPER_HIER = 1; // hierarchical mapping, i.e. both inter-node and intra-node

  // optimization objective for intra-node mapping: edgecut and MIMS
  const int TM_OBJ_EDGECUT = 0;
  const int TM_OBJ_MIMS = 1;

  int mapper = TM_MAPPER_HIER; // default - hierarchical mapping
  int intra_obj = TM_OBJ_EDGECUT; // default - use edgecut as objective

  // check environment variables, mainly for testing purposes
  char *env = getenv("TM_STRATEGY");
  if(env != NULL) if(!strcmp(env,"internode")) mapper = TM_MAPPER_INTER;
                  else if(!strcmp(env,"hierarchical")) mapper = TM_MAPPER_HIER;
  env = getenv("TM_INTRANODE_OBJ");
  if(env != NULL) if(!strcmp(env,"edgecut")) intra_obj = TM_OBJ_EDGECUT;
                  else if(!strcmp(env,"mims")) intra_obj = TM_OBJ_MIMS;
*/

  hwproc_info &myinfo = env->myinfo; // my hardware process information
  all_hwproc_info &allinfo = env->allinfo; // the information of all hardware processes
  hop_distances &all_hopdis = env->all_hopdis; // node hop distance matrix 
  int &nnodes = env->nnodes; // number of nodes
  tree &nj_tree = env->nj_tree; // neighbor joining tree (only store non-leaf nodes) 
  TM_Graph &vtg = env->vtg; // vtg - virtual topology graph
  TM_Graph_ewgts &vtg_ewgts = env->vtg_ewgts; // vtg edge weights 

  int &mapper = env->mapper; // mapper 
  int &intra_obj = env->intra_obj; // intra-node mapping objective
  std::vector<int> &rank2newrank = env->rank2newrank; // mapping from rank to newrank
  std::vector<int> &newrank2rank = env->newrank2rank; // mapping from newrank to rank

  double &t_vtg = env->t_vtg;
  double &t_inter_map = env->t_inter_map;
  double &t_intra_map = env->t_intra_map;

  t_vtg = 0;
  t_inter_map = 0;
  t_intra_map = 0;

  MPI_Barrier(distgr);
  t_vtg = -MPI_Wtime();

  // build the virtual topology graph
  TM_Build_vtg(distgr, vtg, vtg_ewgts);

  assert(nranks%nnodes == 0);
  int nprocs_per_node = nranks/nnodes;
  assert(nprocs_per_node >= 1);

  vertex_part vpart; // vertex -> part id
  part_vertices pvertices; // part id -> vertices
  TM_Graph pvtg; // pvtg - partitioned virtual topology graph
  TM_Graph_ewgts pvtg_ewgts; // pvtg edge weights 

  if (nprocs_per_node > 1) // multiple processes per node, generate pvtg
    TM_Part_vtg(distgr, vtg, vtg_ewgts, nnodes, vpart, pvertices, pvtg, pvtg_ewgts);

  MPI_Barrier(distgr);
  t_vtg += MPI_Wtime();

  t_inter_map = -MPI_Wtime();

  std::vector<int> node2vertex(nnodes); // node to vertex (process or process groups) mapping
  rank2newrank.resize(nranks); // mapping from rank to newrank

  int tree_root = nnodes + nj_tree.size() - 1;
  std::vector<int> vertices(nnodes);
  for (size_t i = 0; i < vertices.size(); ++i) vertices[i] = i;

  if (nprocs_per_node > 1) { // mutiple processes per node, use pvtg
    TM_Tree_mapping(0, pvtg, pvtg_ewgts, nj_tree, tree_root, vertices, myrank, node2vertex);
    assert(node2vertex.size() == (size_t)nnodes);
    for (int i = 0; i < nnodes; i++) {
      int part_id = node2vertex[i];
      int offset = i * nprocs_per_node;
      std::copy(pvertices[part_id].begin(), pvertices[part_id].end(), rank2newrank.begin()+offset);
    }
  }
  else { // one process per node, use vtg
    assert(nprocs_per_node == 1);
    TM_Tree_mapping(0, vtg, vtg_ewgts, nj_tree, tree_root, vertices, myrank, node2vertex);
    assert(node2vertex.size() == (size_t)nnodes);
    std::copy(node2vertex.begin(), node2vertex.end(), rank2newrank.begin());
  }

/*
  // compute default hop-bytes
  size_t my_default_hb = 0;
  if (!myrank) {
    for (size_t i = 0; i < vtg.size(); i++) { // proc
      for (size_t j = 0; j < vtg[i].size(); j++) { // edge
        //int hop = estimate_hop_distance(allinfo[i], allinfo[vtg[i][j]]);
        int hop = all_hopdis[allinfo[i].nodeid * nnodes + allinfo[vtg[i][j]].nodeid];
        my_default_hb += hop * vtg_ewgts[i][j];
      }
    }
  }
*/

  newrank2rank.resize(nranks); // mapping from newrank to rank
  for (int i = 0; i < nranks; i++) newrank2rank[rank2newrank[i]] = i;

  // compute hop-bytes for the mapping solution - rank2newrank
  size_t my_hb = 0;
  for (size_t i = 0; i < vtg.size(); i++) { // proc
    for (size_t j = 0; j < vtg[i].size(); j++) { // edge
      //int hop = estimate_hop_distance(allinfo[newrank2rank[i]], allinfo[newrank2rank[vtg[i][j]]]);
      int hop = all_hopdis[allinfo[newrank2rank[i]].nodeid * nnodes + allinfo[newrank2rank[vtg[i][j]]].nodeid];
      my_hb += hop * vtg_ewgts[i][j];
    }
  }

  std::vector<size_t> all_hb(nranks);
  // gather hop bytes of all solutions
  MPI_Gather(&my_hb, sizeof(size_t), MPI_BYTE, &all_hb[0], sizeof(size_t), MPI_BYTE, 0, distgr);
  int opt_rank; // the rank with the optimal mapping solution
  if (!myrank) {
    std::vector<size_t>::iterator it = std::min_element(all_hb.begin(), all_hb.end());
    opt_rank = it - all_hb.begin(); // find opt_rank
    my_hb = *it; // minimum hop-bytes
    env->hop_bytes = my_hb;
  }
  MPI_Bcast(&opt_rank, 1, MPI_INT, 0, distgr); // broadcast opt_rank to all ranks
  MPI_Bcast(&rank2newrank[0], nranks, MPI_INT, opt_rank, distgr); // broadcast optimal mapping solution to all ranks

  MPI_Barrier(distgr);
  t_inter_map += MPI_Wtime();

#ifdef PRINT_INFO
//  if (!myrank) {
//    printf("inter-node mapping done: default_hop_bytes = %ld, hop_bytes = %ld, reduction = %.2f%%\n",
//      my_default_hb, my_hb, ((double)my_default_hb - (double)my_hb)/(double)my_default_hb*100.0);
//    printf("t_vtg = %f, t_inter_map = %f\n", t_vtg, t_inter_map);
//  }

  if (!myrank) {
    printf("inter-node mapping done: t_vtg = %f, t_inter_map = %f\n", t_vtg, t_inter_map);
  }
#endif

  if ((mapper == TM_MAPPER_INTER) || (nprocs_per_node == 1)) { // inter-node mapping only
    *newrank = rank2newrank[myrank]; // store newrank and return
	env->newrank = *newrank;
    return TM_SUCCESS;
  }

  t_intra_map = -MPI_Wtime();

  // at this point, the inter-node mapping is done!
  // now, deal with intra-node mapping if necessary
  if ((mapper == TM_MAPPER_HIER) && (nprocs_per_node > 1)) {

    TM_Graph ivtg; // ivtg - intra-node virtual topology graph
    TM_Graph_ewgts ivtg_ewgts; // ivtg edge weights 
    TM_Build_ivtg(vtg, vtg_ewgts, myrank, nprocs_per_node, rank2newrank, ivtg, ivtg_ewgts); // build ivtg

#ifdef INTRA_GRAPH_MAP
    int nsockets = 2;  // TACC Stampede has two sockets (i.e. numa nodes) on each compute node
    std::vector<int> ivpart; // intra-node vertex -> part
    part_vertices ipvertices; // intra-node part -> vertices
    int edgecut = graph_partition(ivtg, ivtg_ewgts, nsockets, myrank, ivpart, ipvertices); // partition results

    // evaluate MIMS - Maximum Inter-socket Message Size
    int mims;
    if (intra_obj == TM_OBJ_EDGECUT) {
      edge mims_edge;
      mims = get_mims(ivtg, ivtg_ewgts, ivpart, mims_edge); // get MIMS 
    }
    else if (intra_obj == TM_OBJ_MIMS) {
      mims = refine_mims(ivtg, ivtg_ewgts, ivpart, ipvertices); // iteratively refine MIMS
      // printf("[%d] finish refine mims!\n", myrank);
    }

    //int nodeid = myrank/nprocs_per_node;
    int nodeid = allinfo[myrank].nodeid;
      int offset = nodeid*nprocs_per_node;
    MPI_Comm intra_node_comm;
    MPI_Comm_split(distgr, nodeid, myrank, &intra_node_comm);

    int intra_nranks, intra_myrank;
    MPI_Comm_size(intra_node_comm, &intra_nranks);
    MPI_Comm_rank(intra_node_comm, &intra_myrank); // myrank is not used in the current function
    assert(intra_nranks == nprocs_per_node);

    std::vector<int> all_edgecut(intra_nranks);
    MPI_Gather(&edgecut, 1, MPI_INT, &all_edgecut[0], 1, MPI_INT, 0, intra_node_comm);
    std::vector<int> all_mims(intra_nranks);
    MPI_Gather(&mims, 1, MPI_INT, &all_mims[0], 1, MPI_INT, 0, intra_node_comm);
    int intra_opt_rank; // the rank with the optimal mapping solution
    if (!intra_myrank) {
      std::vector<int>::iterator it;
      if (intra_obj == TM_OBJ_EDGECUT) {
        it = std::min_element(all_edgecut.begin(), all_edgecut.end());
        intra_opt_rank = it - all_edgecut.begin(); // find opt_rank
      }
      else if (intra_obj == TM_OBJ_MIMS) {
        it = std::min_element(all_mims.begin(), all_mims.end());
        intra_opt_rank = it - all_mims.begin(); // find opt_rank
      }
      //my_hb = *it; // minimum hop-bytes
    }
    MPI_Bcast(&intra_opt_rank, 1, MPI_INT, 0, intra_node_comm);
    if (intra_myrank == intra_opt_rank) {
        //int nodeid = myrank/nprocs_per_node;
      std::vector<int> temp;
      for (size_t i = 0; i < ipvertices.size(); i++) {
        for (size_t j = 0; j < ipvertices[i].size(); j++) {
          temp.push_back(rank2newrank[offset+ipvertices[i][j]]);
        }
      }
      assert(temp.size() == (size_t)nprocs_per_node);
      std::copy(temp.begin(), temp.end(), rank2newrank.begin()+offset);
    }
    MPI_Bcast(&rank2newrank[offset], intra_nranks, MPI_INT, intra_opt_rank, intra_node_comm);
    *newrank = rank2newrank[myrank]; // store newrank and return
	env->newrank = *newrank;
#else
#ifdef INTRA_TREE_MAP
    int nodeid = allinfo[myrank].nodeid;
    int offset = nodeid * nprocs_per_node;
    MPI_Comm intra_node_comm;
    MPI_Comm_split(distgr, nodeid, myrank, &intra_node_comm);

    int intra_nranks, intra_myrank;
    MPI_Comm_size(intra_node_comm, &intra_nranks);
    MPI_Comm_rank(intra_node_comm, &intra_myrank); // myrank is not used in the current function
    assert(intra_nranks == nprocs_per_node);

	int &npus = env->npus;
    MPI_Bcast(&npus, 1, MPI_INT, 0, intra_node_comm);
    std::vector<int> pu2proc(npus);

	if (intra_myrank == 0) {
      int intra_tree_root = npus + env->intra_tree.size() - 1;
	  std::vector<int> intra_vertices(ivtg.size());
	  for (size_t i = 0; i < intra_vertices.size(); ++i) intra_vertices[i] = i;

      TM_Tree_mapping_intra_node(0, ivtg, ivtg_ewgts, env->intra_tree,
        intra_tree_root, intra_vertices, 0, pu2proc);
	}
    MPI_Bcast(&pu2proc[0], npus, MPI_INT, 0, intra_node_comm);
    *newrank = rank2newrank[offset+pu2proc[sched_getcpu()]];
	env->newrank = *newrank;
#endif // INTRA_TREE_MAP
#endif // INTRA_GRAPH_MAP
  }

  MPI_Barrier(distgr);
  t_intra_map += MPI_Wtime();

#ifdef PRINT_INFO
  if (!myrank) {
//    printf("intra-node mapping done: default_hop_bytes = %ld, hop_bytes = %ld, reduction = %.2f%%\n",
//      my_default_hb, my_hb, ((double)my_default_hb - (double)my_hb)/(double)my_default_hb*100.0);
    printf("intra-node mapping done: t_vtg = %f, t_inter_map = %f, t_intra_map = %f\n",
      t_vtg, t_inter_map, t_intra_map);
  }
#endif

  return TM_SUCCESS;
}

void TM_Destroy_fattree(TM_env *env)
{
  env->allinfo.clear(); // the information of all hardware processes
  env->all_hopdis.clear(); // node hop distance matrix 
  env->nj_tree.clear(); // neighbor joining tree (only store non-leaf nodes) 
  env->vtg.clear(); // vtg - virtual topology graph
  env->vtg_ewgts.clear(); // vtg edge weights 
  env->rank2newrank.clear(); // mapping from rank to newrank
  env->newrank2rank.clear(); // mapping from newrank to rank
}

#else
#if defined(TORUS_TOPOLOGY) || defined(REGULAR_TORUS_TOPOLOGY)
// TORUS_TOPOLOGY supports NICS Kraken, non-contiguous allocation
// REGULAR_TORUS_TOPOLOGY supports IBM BG/P, contiguous allocation, degenerates to mesh if < 512 nodes

// print the statistics of evaluation metrics for the most recently
// computed mapping
int TM_Metrics_torus(TM_env *env, MPI_Comm distgr)
{
  if (!env->map_ready) return TM_ERR_MAP;

  // get the number of ranks and my rank, check the communicator is consistent or not
  int nranks, myrank;
  MPI_Comm_size(distgr, &nranks);
  MPI_Comm_rank(distgr, &myrank);

#ifdef CHECK
  int err_comm;
  if ((nranks == env->nranks) && (myrank == env->myrank)) err_comm = 0;
  else err_comm = 1;

  int all_err_comm;
  MPI_Allreduce(&err_comm, &all_err_comm, 1, MPI_INT, MPI_MAX, distgr);

  if (all_err_comm == 1) return TM_ERR_COMM; 
#endif

  //hwproc_info &myinfo = env->myinfo; // my hardware process information
  all_hwproc_info &allinfo = env->allinfo; // the information of all hardware processes
  //hop_distances &hopdis = env->hopdis; // node hop distance matrix 
  int &nnodes = env->nnodes; // number of nodes
  TM_Graph &vtg = env->vtg; // vtg - virtual topology graph
  TM_Graph_ewgts &vtg_ewgts = env->vtg_ewgts; // vtg edge weights
  int &strategy = env->strategy;
  int &mapper = env->mapper;
  int &intra_obj = env->intra_obj;
  size_t &hop_bytes = env->hop_bytes;
  int &newrank = env->newrank;
  std::vector<int> &rank2newrank = env->rank2newrank; // mapping from rank to newrank
  std::vector<int> &newrank2rank = env->newrank2rank; // mapping from newrank to rank

  MPI_Gather(&newrank, 1, MPI_INT, &rank2newrank[0], 1, MPI_INT, 0, distgr);
  
  newrank2rank.resize(nranks); // mapping from newrank to rank
  for (int i = 0; i < nranks; i++) newrank2rank[rank2newrank[i]] = i;

  // compute metrics and print
  if (!myrank) {
	
	printf("**************************************************************\n");
    printf("statistics of topology mapping metrics:\n");
	if (strategy == TM_RECURSIVE) printf("strategy = TM_RECURSIVE: recursive mapping\n");
	else if (strategy == TM_NJ_TREE) printf("strategy = TM_NJ_TREE: neighbor joining tree based mapping\n");
	if (mapper == TM_MAPPER_INTER) printf("mapper = TM_MAPPER_INTER: inter-node mapping only\n");
	else if (mapper == TM_MAPPER_HIER) {
	  printf("mapper = TM_MAPPER_HIER: hierarchical mapping, including both inter- and intra-node mapping\n");
	  if (intra_obj == TM_OBJ_EDGECUT) printf("intra_obj = TM_OBJ_EDGECUT: minimize edgecut for intra-node mapping\n");
	  else if (intra_obj == TM_OBJ_MIMS) printf("intra_obj = TM_OBJ_MIMS: minimize MIMS for intra-node mapping\n");
	}

    printf("execution time: t_gettopo = %f; major components: t_nj = %f\n",
	  env->t_gettopo, env->t_nj);
    printf("execution time: t_topomap = %f; major components: t_vtg = %f, t_inter_map = %f, t_intra_map = %f\n",
	  env->t_topomap, env->t_vtg, env->t_inter_map, env->t_intra_map);
				 
    // compute and print hop-bytes
    size_t default_hop_bytes = 0;
    for (size_t i = 0; i < vtg.size(); i++) { // proc
      for (size_t j = 0; j < vtg[i].size(); j++) { // edge
		int hop = estimate_hop_distance(allinfo[i], allinfo[vtg[i][j]]);
        default_hop_bytes += hop * vtg_ewgts[i][j];
      }
    }
    printf("default_hop_bytes = %ld, hop_bytes = %ld, reduction = %.2f%%\n",
      default_hop_bytes, hop_bytes, ((double)default_hop_bytes - (double)hop_bytes)/(double)default_hop_bytes*100.0);

	// compute and print average hops
	size_t total_bytes = 0;
	for (size_t i = 0; i < vtg.size(); ++i) {
	  for (size_t j = 0; j < vtg[i].size(); ++j) {
		total_bytes += vtg_ewgts[i][j];
	  }
	}
	double default_average_hops = (double)default_hop_bytes/(double)total_bytes;
	double average_hops = (double)hop_bytes/(double)total_bytes;
    printf("default_average_hops = %f, average_hops = %f, reduction = %.2f%%\n",
      default_average_hops, average_hops, (default_average_hops - average_hops)/default_average_hops*100.0);

	// compute default communication statistics
	std::vector<size_t> total_comm_dis(10, 0);
	std::vector<std::vector<size_t> > comm_dis(vtg.size());
    for (size_t i = 0; i < vtg.size(); ++i) comm_dis[i].assign(10, 0);

	int nprocs_per_node = nranks / nnodes;
	int nprocs_per_socket = nprocs_per_node / 2;
	assert(nranks % nnodes == 0);
	assert(nprocs_per_node % 2 == 0);
	
	int avg_intra_socket_comm;
	size_t total_intra_socket_comm = 0;
	size_t total_intra_socket_comm_cnt = 0;
    int max_intra_socket_comm = 0;

    int avg_inter_socket_comm;
	size_t total_inter_socket_comm = 0;
	size_t total_inter_socket_comm_cnt = 0;
    int max_inter_socket_comm = 0;

    for (size_t i = 0; i < vtg.size(); i++) { // proc
	  //int hwproc1 = newrank2rank[i];
	  int hwproc1 = i; 
	  int node1 = hwproc1 / nprocs_per_node;
	  int socket1 = hwproc1 / nprocs_per_socket;
      for (size_t j = 0; j < vtg[i].size(); j++) { // edge
		//int hwproc2 = newrank2rank[vtg[i][j]];
		int hwproc2 = vtg[i][j];
	    int node2 = hwproc2 / nprocs_per_node;
		int socket2 = hwproc2 / nprocs_per_socket;

		if (node1 == node2) { // on the same node
		  if (socket1 == socket2) { // on the same socket
			total_comm_dis[0] += vtg_ewgts[i][j]; // intra-socket communication
			comm_dis[i][0] += vtg_ewgts[i][j]; // intra-socket communication

			total_intra_socket_comm += vtg_ewgts[i][j];
			total_intra_socket_comm_cnt++;
			if (vtg_ewgts[i][j] > max_intra_socket_comm) max_intra_socket_comm = vtg_ewgts[i][j];
		  }
		  else {
			total_comm_dis[1] += vtg_ewgts[i][j]; // inter-socket communication
			comm_dis[i][1] += vtg_ewgts[i][j]; // inter-socket communication

			total_inter_socket_comm += vtg_ewgts[i][j];
			total_inter_socket_comm_cnt++;
			if (vtg_ewgts[i][j] > max_inter_socket_comm) max_inter_socket_comm = vtg_ewgts[i][j];
		  }
		}
		else {
		  int hop = estimate_hop_distance(allinfo[hwproc1], allinfo[hwproc2]);
		  assert(hop >= 1);
		  if (hop <= 7) {
			total_comm_dis[hop+1] += vtg_ewgts[i][j]; // inter-node communication, <= 7 hops
			comm_dis[i][hop+1] += vtg_ewgts[i][j]; // inter-node communication, <= 7 hops
		  }
		  else {
			total_comm_dis[9] += vtg_ewgts[i][j]; // inter-node communication, >= 8 hops
			comm_dis[i][9] += vtg_ewgts[i][j]; // inter-node communication, >= 8 hops
		  }
		}
      }
    }

	avg_intra_socket_comm = total_intra_socket_comm / total_intra_socket_comm_cnt;
	avg_inter_socket_comm = total_inter_socket_comm / total_inter_socket_comm_cnt;

	std::vector<double> total_comm_dis_percentage(10);
	std::vector<std::vector<double> > comm_dis_percentage(vtg.size());
    for (size_t i = 0; i < vtg.size(); ++i) comm_dis_percentage[i].resize(10);

	size_t total_comm = std::accumulate(total_comm_dis.begin(), total_comm_dis.end(), 0);
	for (int i = 0; i < 10; ++i) total_comm_dis_percentage[i] = (double)total_comm_dis[i] / (double)total_comm * 100.0;

	for (size_t i = 0; i < vtg.size(); ++i) {
	  size_t total_comm_i = std::accumulate(comm_dis[i].begin(), comm_dis[i].end(), 0);
	  for (int j = 0; j < 10; ++j) comm_dis_percentage[i][j] = (double)comm_dis[i][j] / (double)total_comm_i * 100.0;
	}

	printf("original avg_intra_socket_comm = %d, max_intra_socket_comm = %d\n",
	  avg_intra_socket_comm, max_intra_socket_comm);
	printf("original avg_inter_socket_comm = %d, max_inter_socket_comm = %d\n",
	  avg_inter_socket_comm, max_inter_socket_comm);
	printf("original communication statistics (up to 64 processes, in percentage, %% is omitted):\n");
	printf("total/process id");
	for (int i = 0; i < 10; ++i) {
	  if (i == 0) printf("\tintra-socket");
	  else if (i == 1) printf("\tinter-socket");
	  else if (i == 2) printf("\t1 hop");
	  else if (i <= 8) printf("\t%d hops", i-1);
	  else printf("\t>=8 hops\n");
	}
	printf("total");
	for (int i = 0; i < 10; ++i) printf("\t%f", total_comm_dis_percentage[i]);
	printf("\n");
	for (size_t i = 0; i < std::min(vtg.size(), (size_t)64); ++i) {
	  printf("%ld", i);
	  for (int j = 0; j < 10; ++j) printf("\t%f", comm_dis_percentage[i][j]);
	  printf("\n");
	}

	// compute mapped communication statistics
	total_comm_dis.assign(10, 0);
	comm_dis.resize(vtg.size());
    for (size_t i = 0; i < vtg.size(); ++i) comm_dis[i].assign(10, 0);

	total_intra_socket_comm = 0;
	total_intra_socket_comm_cnt = 0;
    max_intra_socket_comm = 0;

	total_inter_socket_comm = 0;
	total_inter_socket_comm_cnt = 0;
    max_inter_socket_comm = 0;

    for (size_t i = 0; i < vtg.size(); i++) { // proc
	  int hwproc1 = newrank2rank[i];
	  //int hwproc1 = i; 
	  int node1 = hwproc1 / nprocs_per_node;
	  int socket1 = hwproc1 / nprocs_per_socket;
      for (size_t j = 0; j < vtg[i].size(); j++) { // edge
		int hwproc2 = newrank2rank[vtg[i][j]];
		//int hwproc2 = vtg[i][j];
	    int node2 = hwproc2 / nprocs_per_node;
		int socket2 = hwproc2 / nprocs_per_socket;

		if (node1 == node2) { // on the same node
		  if (socket1 == socket2) { // on the same socket
			total_comm_dis[0] += vtg_ewgts[i][j]; // intra-socket communication
			comm_dis[i][0] += vtg_ewgts[i][j]; // intra-socket communication

			total_intra_socket_comm += vtg_ewgts[i][j];
			total_intra_socket_comm_cnt++;
			if (vtg_ewgts[i][j] > max_intra_socket_comm) max_intra_socket_comm = vtg_ewgts[i][j];
		  }
		  else {
			total_comm_dis[1] += vtg_ewgts[i][j]; // inter-socket communication
			comm_dis[i][1] += vtg_ewgts[i][j]; // inter-socket communication

			total_inter_socket_comm += vtg_ewgts[i][j];
			total_inter_socket_comm_cnt++;
			if (vtg_ewgts[i][j] > max_inter_socket_comm) max_inter_socket_comm = vtg_ewgts[i][j];
		  }
		}
		else {
		  int hop = estimate_hop_distance(allinfo[hwproc1], allinfo[hwproc2]);
		  assert(hop >= 1);
		  if (hop <= 7) {
			total_comm_dis[hop+1] += vtg_ewgts[i][j]; // inter-node communication, <= 7 hops
			comm_dis[i][hop+1] += vtg_ewgts[i][j]; // inter-node communication, <= 7 hops
		  }
		  else {
			total_comm_dis[9] += vtg_ewgts[i][j]; // inter-node communication, >= 8 hops
			comm_dis[i][9] += vtg_ewgts[i][j]; // inter-node communication, >= 8 hops
		  }
		}
      }
    }

	avg_intra_socket_comm = total_intra_socket_comm / total_intra_socket_comm_cnt;
	avg_inter_socket_comm = total_inter_socket_comm / total_inter_socket_comm_cnt;

	total_comm = std::accumulate(total_comm_dis.begin(), total_comm_dis.end(), 0);
	for (int i = 0; i < 10; ++i) total_comm_dis_percentage[i] = (double)total_comm_dis[i] / (double)total_comm * 100.0;

	for (size_t i = 0; i < vtg.size(); ++i) {
	  size_t total_comm_i = std::accumulate(comm_dis[i].begin(), comm_dis[i].end(), 0);
	  for (int j = 0; j < 10; ++j) comm_dis_percentage[i][j] = (double)comm_dis[i][j] / (double)total_comm_i * 100.0;
	}

	printf("mapped avg_intra_socket_comm = %d, max_intra_socket_comm = %d\n",
	  avg_intra_socket_comm, max_intra_socket_comm);
	printf("mapped avg_inter_socket_comm = %d, max_inter_socket_comm = %d\n",
	  avg_inter_socket_comm, max_inter_socket_comm);
	printf("mapped communication statistics (up to 64 processes, in percentage, %% is omitted):\n");
	printf("total/process id");
	for (int i = 0; i < 10; ++i) {
	  if (i == 0) printf("\tintra-socket");
	  else if (i == 1) printf("\tinter-socket");
	  else if (i == 2) printf("\t1 hop");
	  else if (i <= 8) printf("\t%d hops", i-1);
	  else printf("\t>=8 hops\n");
	}
	printf("total");
	for (int i = 0; i < 10; ++i) printf("\t%f", total_comm_dis_percentage[i]);
	printf("\n");
	for (size_t i = 0; i < std::min(vtg.size(), (size_t)64); ++i) {
	  printf("%ld", i);
	  for (int j = 0; j < 10; ++j) printf("\t%f", comm_dis_percentage[i][j]);
	  printf("\n");
	}
  }

  return TM_SUCCESS;
}

int TM_Topomap_torus(TM_env *env, MPI_Comm distgr, int *newrank)
{
  if (!env->topo_ready) return TM_ERR_TOPO;

  // get the number of ranks and my rank
  int nranks, myrank;
  MPI_Comm_size(distgr, &nranks);
  MPI_Comm_rank(distgr, &myrank);

#ifdef CHECK
  int err_comm;
  if ((nranks == env->nranks) && (myrank == env->myrank)) err_comm = 0;
  else err_comm = 1;

  int all_err_comm;
  MPI_Allreduce(&err_comm, &all_err_comm, 1, MPI_INT, MPI_MAX, distgr);

  if (all_err_comm == 1) return TM_ERR_COMM; 
#endif

/*
  const int TM_MAPPER_INTER = 0; // inter-node mapping 
  const int TM_MAPPER_HIER = 1; // hierarchical mapping, i.e. both inter-node and intra-node

  // optimization objective for intra-node mapping: edgecut and MIMS
  const int TM_OBJ_EDGECUT = 0;
  const int TM_OBJ_MIMS = 1;

  int mapper = TM_MAPPER_HIER; // default - hierarchical mapping
  int intra_obj = TM_OBJ_EDGECUT; // default - use edgecut as objective

  // check environment variables, mainly for testing purposes
  char *env = getenv("TM_STRATEGY");
  if(env != NULL) if(!strcmp(env,"internode")) mapper = TM_MAPPER_INTER;
                  else if(!strcmp(env,"hierarchical")) mapper = TM_MAPPER_HIER;
  env = getenv("TM_INTRANODE_OBJ");
  if(env != NULL) if(!strcmp(env,"edgecut")) intra_obj = TM_OBJ_EDGECUT;
                  else if(!strcmp(env,"mims")) intra_obj = TM_OBJ_MIMS;
*/

  //hwproc_info &myinfo = env->myinfo; // my hardware process information
  all_hwproc_info &allinfo = env->allinfo; // the information of all hardware processes
#ifdef OPT_MAP
  hop_distances &hopdis = env->hopdis; // the distance (in hops) between current hardware process and other processes
#endif
  int &nnodes = env->nnodes; // number of nodes
  coords &node_coords = env->node_coords; // node coordinates
  //hop_distances &all_hopdis = env->all_hopdis; // node hop distance matrix 
  tree &nj_tree = env->nj_tree; // neighbor joining tree (only store non-leaf nodes)   
  TM_Graph &vtg = env->vtg; // vtg - virtual topology graph
  TM_Graph_ewgts &vtg_ewgts = env->vtg_ewgts; // vtg edge weights 

  int &strategy = env->strategy;
  int &mapper = env->mapper; // mapper 
  int &intra_obj = env->intra_obj; // intra-node mapping objective
  std::vector<int> &rank2newrank = env->rank2newrank; // mapping from rank to newrank
  std::vector<int> &newrank2rank = env->newrank2rank; // mapping from newrank to rank

  double &t_vtg = env->t_vtg;
  double &t_inter_map = env->t_inter_map;
  double &t_intra_map = env->t_intra_map;

  t_vtg = 0;
  t_inter_map = 0;
  t_intra_map = 0;

  MPI_Barrier(distgr);
  t_vtg = -MPI_Wtime();

  // build the virtual topology graph
  TM_Build_vtg(distgr, vtg, vtg_ewgts);

  assert(nranks%nnodes == 0);
  int nprocs_per_node = nranks/nnodes;
  assert(nprocs_per_node >= 1);

  vertex_part vpart; // vertex -> part id
  part_vertices pvertices; // part id -> vertices
  TM_Graph pvtg; // pvtg - partitioned virtual topology graph
  TM_Graph_ewgts pvtg_ewgts; // pvtg edge weights 

  if (nprocs_per_node > 1) // multiple processes per node, generate pvtg
    TM_Part_vtg(distgr, vtg, vtg_ewgts, nnodes, vpart, pvertices, pvtg, pvtg_ewgts);

  MPI_Barrier(distgr);
  t_vtg += MPI_Wtime();

  t_inter_map = -MPI_Wtime();

#ifdef OPT_MAP
  int mytotal_hopdis = std::accumulate(hopdis.begin(), hopdis.end(), 0);
  hop_distances alltotal_hopdis(nranks);
  MPI_Allgather(&mytotal_hopdis, 1, MPI_INT, &alltotal_hopdis[0], 1, MPI_INT, distgr); // gather total_hopdis 
  hop_distances nodetotal_hopdis(nnodes); // total_hopdis for each node
  // we still assume the default contiguous intra-node mapping
  // the following for loop need to be changed in order to support random input mapping
  for (int i = 0; i < nnodes; i++) nodetotal_hopdis[i] = alltotal_hopdis[i*nprocs_per_node]/nprocs_per_node;

  std::vector<int> vcomm(nnodes); // the total communication volume of each vertex
  if (nprocs_per_node > 1) { // mutiple processes per node, use pvtg
    assert(vcomm.size() == pvtg_ewgts.size());
    for (int i = 0; i < nnodes; i++)
      vcomm[i] = std::accumulate(pvtg_ewgts[i].begin(), pvtg_ewgts[i].end(), 0);
  }
  else { // one process per node, use vtg
    assert(vcomm.size() == vtg_ewgts.size());
    for (int i = 0; i < nnodes; i++)
      vcomm[i] = std::accumulate(vtg_ewgts[i].begin(), vtg_ewgts[i].end(), 0);
  }
#endif

  std::vector<int> node2vertex; // node to vertex (process or process groups) mapping
  rank2newrank.resize(nranks); // mapping from rank to newrank
  
  if (strategy == TM_RECURSIVE) {
  if (nprocs_per_node > 1) { // mutiple processes per node, use pvtg
    TM_Recursive_mapping(0, pvtg, pvtg_ewgts, node_coords,
#ifdef OPT_MAP
      vcomm, nodetotal_hopdis,
#endif
      myrank, node2vertex);
    assert(node2vertex.size() == (size_t)nnodes);
    for (int i = 0; i < nnodes; i++) {
      int part_id = node2vertex[i];
      int offset = i * nprocs_per_node;
      std::copy(pvertices[part_id].begin(), pvertices[part_id].end(), rank2newrank.begin()+offset);
    }
  }
  else { // one process per node, use vtg
    assert(nprocs_per_node == 1);
    TM_Recursive_mapping(0, vtg, vtg_ewgts, node_coords,
#ifdef OPT_MAP
      vcomm, nodetotal_hopdis,
#endif
      myrank, node2vertex);
    assert(node2vertex.size() == (size_t)nnodes);
    std::copy(node2vertex.begin(), node2vertex.end(), rank2newrank.begin());
  }
  }
  else if (strategy == TM_NJ_TREE) {

  node2vertex.resize(nnodes);

  int tree_root = nnodes + nj_tree.size() - 1;
  std::vector<int> vertices(nnodes);
  for (size_t i = 0; i < vertices.size(); ++i) vertices[i] = i;

  if (nprocs_per_node > 1) { // mutiple processes per node, use pvtg
    TM_Tree_mapping(0, pvtg, pvtg_ewgts, nj_tree, tree_root, vertices, myrank, node2vertex);
    assert(node2vertex.size() == (size_t)nnodes);
    for (int i = 0; i < nnodes; i++) {
      int part_id = node2vertex[i];
      int offset = i * nprocs_per_node;
      std::copy(pvertices[part_id].begin(), pvertices[part_id].end(), rank2newrank.begin()+offset);
    }
  }
  else { // one process per node, use vtg
    assert(nprocs_per_node == 1);
    TM_Tree_mapping(0, vtg, vtg_ewgts, nj_tree, tree_root, vertices, myrank, node2vertex);
    assert(node2vertex.size() == (size_t)nnodes);
    std::copy(node2vertex.begin(), node2vertex.end(), rank2newrank.begin());
  }
  }
  else {
    assert(false);
  }

/*  
  // compute default hop-bytes
  size_t my_default_hb = 0;
  if (!myrank) {
    for (size_t i = 0; i < vtg.size(); i++) { // proc
      for (size_t j = 0; j < vtg[i].size(); j++) { // edge
        int hop = estimate_hop_distance(allinfo[i], allinfo[vtg[i][j]]);
        my_default_hb += hop * vtg_ewgts[i][j];
      }
    }
  }
*/
  newrank2rank.resize(nranks); // mapping from newrank to rank
  for (int i = 0; i < nranks; i++) newrank2rank[rank2newrank[i]] = i;

  // compute hop-bytes for the mapping solution - rank2newrank
  size_t my_hb = 0;
  for (size_t i = 0; i < vtg.size(); i++) { // proc
    for (size_t j = 0; j < vtg[i].size(); j++) { // edge
      int hop = estimate_hop_distance(allinfo[newrank2rank[i]], allinfo[newrank2rank[vtg[i][j]]]);
      my_hb += hop * vtg_ewgts[i][j];
    }
  }

  std::vector<size_t> all_hb(nranks);
  // gather hop bytes of all solutions
  MPI_Gather(&my_hb, sizeof(size_t), MPI_BYTE, &all_hb[0], sizeof(size_t), MPI_BYTE, 0, distgr);
  int opt_rank; // the rank with the optimal mapping solution
  if (!myrank) {
    std::vector<size_t>::iterator it = std::min_element(all_hb.begin(), all_hb.end());
    opt_rank = it - all_hb.begin(); // find opt_rank
    my_hb = *it; // minimum hop-bytes
	env->hop_bytes = my_hb;
  }
  MPI_Bcast(&opt_rank, 1, MPI_INT, 0, distgr); // broadcast opt_rank to all ranks
  MPI_Bcast(&rank2newrank[0], nranks, MPI_INT, opt_rank, distgr); // broadcast optimal mapping solution to all ranks
  
  MPI_Barrier(distgr);
  t_inter_map += MPI_Wtime();
  
#ifdef PRINT_INFO
  if (!myrank) {
//    printf("inter-node mapping done: default_hop_bytes = %ld, hop_bytes = %ld, reduction = %.2f%%\n",
//      my_default_hb, my_hb, ((double)my_default_hb - (double)my_hb)/(double)my_default_hb*100.0);
//    printf("t_vtg = %f, t_inter_map = %f\n", t_vtg, t_inter_map);
	printf("inter-node mapping done: t_vtg = %f, t_inter_map = %f\n", t_vtg, t_inter_map);
  }
#endif

  if ((mapper == TM_MAPPER_INTER) || (nprocs_per_node == 1)) { // inter-node mapping only
    *newrank = rank2newrank[myrank]; // store newrank and return
	env->newrank = *newrank;
    return TM_SUCCESS;
  }

  t_intra_map = -MPI_Wtime();

  // at this point, the inter-node mapping is done!
  // now, deal with intra-node mapping if necessary
  if ((mapper == TM_MAPPER_HIER) && (nprocs_per_node > 1)) {

    TM_Graph ivtg; // ivtg - intra-node virtual topology graph
    TM_Graph_ewgts ivtg_ewgts; // ivtg edge weights 
    TM_Build_ivtg(vtg, vtg_ewgts, myrank, nprocs_per_node, rank2newrank, ivtg, ivtg_ewgts); // build ivtg

#ifdef INTRA_GRAPH_MAP
    int nsockets = 2; // NICS Kraken has two sockets (i.e. numa nodes) on each compute node
    std::vector<int> ivpart; // intra-node vertex -> part
    part_vertices ipvertices; // intra-node part -> vertices
    int edgecut = graph_partition(ivtg, ivtg_ewgts, nsockets, myrank, ivpart, ipvertices); // partition results

    // evaluate MIMS - Maximum Inter-socket Message Size
    int mims;
    if (intra_obj == TM_OBJ_EDGECUT) {
      edge mims_edge;
      mims = get_mims(ivtg, ivtg_ewgts, ivpart, mims_edge); // get MIMS 
    }
    else if (intra_obj == TM_OBJ_MIMS) {
      mims = refine_mims(ivtg, ivtg_ewgts, ivpart, ipvertices); // iteratively refine MIMS
    }

    //int nodeid = myrank/nprocs_per_node;
    int nodeid = allinfo[myrank].nodeid;
      int offset = nodeid*nprocs_per_node;
    MPI_Comm intra_node_comm;
    MPI_Comm_split(distgr, nodeid, myrank, &intra_node_comm);

    int intra_nranks, intra_myrank;
    MPI_Comm_size(intra_node_comm, &intra_nranks);
    MPI_Comm_rank(intra_node_comm, &intra_myrank); // myrank is not used in the current function
    assert(intra_nranks == nprocs_per_node);

    std::vector<int> all_edgecut(intra_nranks);
    MPI_Gather(&edgecut, 1, MPI_INT, &all_edgecut[0], 1, MPI_INT, 0, intra_node_comm);
    std::vector<int> all_mims(intra_nranks);
    MPI_Gather(&mims, 1, MPI_INT, &all_mims[0], 1, MPI_INT, 0, intra_node_comm);
    int intra_opt_rank; // the rank with the optimal mapping solution
    if (!intra_myrank) {
      std::vector<int>::iterator it;
      if (intra_obj == TM_OBJ_EDGECUT) {
        it = std::min_element(all_edgecut.begin(), all_edgecut.end());
        intra_opt_rank = it - all_edgecut.begin(); // find opt_rank
      }
      else if (intra_obj == TM_OBJ_MIMS) {
        it = std::min_element(all_mims.begin(), all_mims.end());
        intra_opt_rank = it - all_mims.begin(); // find opt_rank
      }
      //my_hb = *it; // minimum hop-bytes
    }
    MPI_Bcast(&intra_opt_rank, 1, MPI_INT, 0, intra_node_comm);
    if (intra_myrank == intra_opt_rank) {
        //int nodeid = myrank/nprocs_per_node;
      std::vector<int> temp;
      for (size_t i = 0; i < ipvertices.size(); i++) {
        for (size_t j = 0; j < ipvertices[i].size(); j++) {
          temp.push_back(rank2newrank[offset+ipvertices[i][j]]);
        }
      }
      assert(temp.size() == (size_t)nprocs_per_node);
      std::copy(temp.begin(), temp.end(), rank2newrank.begin()+offset);
    }
    MPI_Bcast(&rank2newrank[offset], intra_nranks, MPI_INT, intra_opt_rank, intra_node_comm);
    *newrank = rank2newrank[myrank]; // store newrank and return
	env->newrank = *newrank;
#else
#ifdef INTRA_TREE_MAP
    int nodeid = allinfo[myrank].nodeid;
    int offset = nodeid * nprocs_per_node;
    MPI_Comm intra_node_comm;
    MPI_Comm_split(distgr, nodeid, myrank, &intra_node_comm);

    int intra_nranks, intra_myrank;
    MPI_Comm_size(intra_node_comm, &intra_nranks);
    MPI_Comm_rank(intra_node_comm, &intra_myrank); // myrank is not used in the current function
    assert(intra_nranks == nprocs_per_node);

	int &npus = env->npus;
    MPI_Bcast(&npus, 1, MPI_INT, 0, intra_node_comm);
    std::vector<int> pu2proc(npus);

	if (intra_myrank == 0) {
      int intra_tree_root = npus + env->intra_tree.size() - 1;
	  std::vector<int> intra_vertices(ivtg.size());
	  for (size_t i = 0; i < intra_vertices.size(); ++i) intra_vertices[i] = i;

      TM_Tree_mapping_intra_node(0, ivtg, ivtg_ewgts, env->intra_tree,
        intra_tree_root, intra_vertices, 0, pu2proc);
	}
    MPI_Bcast(&pu2proc[0], npus, MPI_INT, 0, intra_node_comm);
    *newrank = rank2newrank[offset+pu2proc[sched_getcpu()]];
	env->newrank = *newrank;
#endif // INTRA_TREE_MAP
#endif // INTRA_GRAPH_MAP
  }

  MPI_Barrier(distgr);
  t_intra_map += MPI_Wtime();

#ifdef PRINT_INFO
  if (!myrank) {
//    printf("intra-node mapping done: default_hop_bytes = %ld, hop_bytes = %ld, reduction = %.2f%%\n",
//      my_default_hb, my_hb, ((double)my_default_hb - (double)my_hb)/(double)my_default_hb*100.0);
    printf("intra-node mapping done: t_vtg = %f, t_inter_map = %f, t_intra_map = %f\n",
      t_vtg, t_inter_map, t_intra_map);
  }
#endif

  return TM_SUCCESS;
}

void TM_Destroy_torus(TM_env *env)
{
  env->allinfo.clear(); // the information of all hardware processes
#ifdef OPT_MAP
  env->hopdis.clear(); // the distance (in hops) between current hardware process and other processes
#endif
  env->node_coords.clear(); // node coordinates
  env->all_hopdis.clear(); // node hop distance matrix 
  env->nj_tree.clear(); // neighbor joining tree (only store non-leaf nodes) 
  env->vtg.clear(); // vtg - virtual topology graph
  env->vtg_ewgts.clear(); // vtg edge weights 
  env->rank2newrank.clear(); // mapping from rank to newrank
  env->newrank2rank.clear(); // mapping from newrank to rank
}

#else
  #error "Must define the topology: FAT_TREE_TOPOLOGY, TORUS_TOPOLOGY or REGULAR_TORUS_TOPOLOGY"
#endif // TORUS_TOPOLOGY || REGULAR_TORUS_TOPOLOGY
#endif // FAT_TREE_TOPOLOGY

// get the topology information
int TM_Gettopo_env(TM_env *env, MPI_Comm distgr) {

  double &t_gettopo = env->t_gettopo;
  t_gettopo = 0;

  MPI_Barrier(distgr);
  t_gettopo = -MPI_Wtime();

#ifdef FAT_TREE_TOPOLOGY // supports TACC Stampede, non-contiguous allocation
  TM_Gettopo_fattree(env, distgr);
#else
#if defined(TORUS_TOPOLOGY) || defined(REGULAR_TORUS_TOPOLOGY)
// TORUS_TOPOLOGY supports NICS Kraken, non-contiguous allocation
// REGULAR_TORUS_TOPOLOGY supports IBM BG/P, contiguous allocation, degenerates to mesh if < 512 nodes
  TM_Gettopo_torus(env, distgr);
#else
  #error "Must define the topology: FAT_TREE_TOPOLOGY, TORUS_TOPOLOGY or REGULAR_TORUS_TOPOLOGY"
#endif // TORUS_TOPOLOGY || REGULAR_TORUS_TOPOLOGY
#endif // FAT_TREE_TOPOLOGY

  if (env->myinfo.coreid == 0) {
    TM_Gettopo_intra_node(env);
  }

  MPI_Barrier(distgr);
  t_gettopo += MPI_Wtime();

  env->topo_ready = true;

#ifdef PRINT_INFO
  if (!env->myrank) printf("get topology done! t_gettopo = %f\n", t_gettopo);
#endif

  return TM_SUCCESS;
}

// The hierarchical topology mapping function.
// It takes the distributed graph communicator as input, and genereates
// the new rank id for each MPI process. It calls the appropriate mapping
// function according to the network topology. Users must specify the
// topology by using the corresponding macrodefine in "hiertopomap.h".
int TM_Topomap_env(TM_env *env, MPI_Comm distgr, int *newrank) {

  int ret;

  double &t_topomap = env->t_topomap;
  t_topomap = 0;

  MPI_Barrier(distgr);
  t_topomap = -MPI_Wtime();

#ifdef FAT_TREE_TOPOLOGY // supports TACC Stampede, non-contiguous allocation
  ret = TM_Topomap_fattree(env, distgr, newrank);
#else
#if defined(TORUS_TOPOLOGY) || defined(REGULAR_TORUS_TOPOLOGY)
// TORUS_TOPOLOGY supports NICS Kraken, non-contiguous allocation
// REGULAR_TORUS_TOPOLOGY supports IBM BG/P, contiguous allocation, degenerates to mesh if < 512 nodes
  ret = TM_Topomap_torus(env, distgr, newrank);
#else
  #error "Must define the topology: FAT_TREE_TOPOLOGY, TORUS_TOPOLOGY or REGULAR_TORUS_TOPOLOGY"
#endif // TORUS_TOPOLOGY || REGULAR_TORUS_TOPOLOGY
#endif // FAT_TREE_TOPOLOGY

  MPI_Barrier(distgr);
  t_topomap += MPI_Wtime();

  if (ret == TM_SUCCESS) env->map_ready = true;

#ifdef PRINT_INFO
  if ((!env->myrank) && (ret == TM_SUCCESS)) printf("topology mapping done! t_topomap = %f\n", t_topomap);
#endif

  return ret;
}

// get the topology information
int TM_Metrics_env(TM_env *env, MPI_Comm distgr) {

  int ret;

#ifdef FAT_TREE_TOPOLOGY // supports TACC Stampede, non-contiguous allocation
  ret = TM_Metrics_fattree(env, distgr);
#else
#if defined(TORUS_TOPOLOGY) || defined(REGULAR_TORUS_TOPOLOGY)
// TORUS_TOPOLOGY supports NICS Kraken, non-contiguous allocation
// REGULAR_TORUS_TOPOLOGY supports IBM BG/P, contiguous allocation, degenerates to mesh if < 512 nodes
  ret = TM_Metrics_torus(env, distgr);
#else
  #error "Must define the topology: FAT_TREE_TOPOLOGY, TORUS_TOPOLOGY or REGULAR_TORUS_TOPOLOGY"
#endif // TORUS_TOPOLOGY || REGULAR_TORUS_TOPOLOGY
#endif // FAT_TREE_TOPOLOGY

  return ret;
}

// free TM_env 
void TM_Destroy_env(TM_env *env) {

#ifdef FAT_TREE_TOPOLOGY // supports TACC Stampede, non-contiguous allocation
  TM_Destroy_fattree(env);
#else
#if defined(TORUS_TOPOLOGY) || defined(REGULAR_TORUS_TOPOLOGY)
// TORUS_TOPOLOGY supports NICS Kraken, non-contiguous allocation
// REGULAR_TORUS_TOPOLOGY supports IBM BG/P, contiguous allocation, degenerates to mesh if < 512 nodes
  TM_Destroy_torus(env);
#else
  #error "Must define the topology: FAT_TREE_TOPOLOGY, TORUS_TOPOLOGY or REGULAR_TORUS_TOPOLOGY"
#endif // TORUS_TOPOLOGY || REGULAR_TORUS_TOPOLOGY
#endif // FAT_TREE_TOPOLOGY
}

// The hierarchical topology mapping function (without input TM_env).
int TM_Topomap(MPI_Comm distgr, int *newrank) {

  TM_env env;
  TM_Gettopo_env(&env, distgr);
  TM_Topomap_env(&env, distgr, newrank);
  TM_Destroy_env(&env);

  return TM_SUCCESS;
}

// The hierarchical topology mapping function (without input TM_env).
// use the recursive tree mapping algorithm
int TM_Topomap_tree(MPI_Comm distgr, int *newrank) {

  TM_env env;

#ifdef FAT_TREE_TOPOLOGY // supports TACC Stampede, non-contiguous allocation
#else
#if defined(TORUS_TOPOLOGY) || defined(REGULAR_TORUS_TOPOLOGY)
  env.strategy = TM_NJ_TREE; // use the neighbor joining based recursive tree mapping algorithm
#endif
#endif

  TM_Gettopo_env(&env, distgr);
  TM_Topomap_env(&env, distgr, newrank);
  TM_Destroy_env(&env);

  return TM_SUCCESS;
}

// The hierarchical topology mapping function (without input TM_env).
// use the recursive bipartitioning mapping algorithm
int TM_Topomap_bipart(MPI_Comm distgr, int *newrank) {

  TM_env env;

#ifdef FAT_TREE_TOPOLOGY // supports TACC Stampede, non-contiguous allocation
  MPI_Comm_rank(distgr, newrank); // return identity mapping
  return TM_ERR_CALL;
#else
#if defined(TORUS_TOPOLOGY) || defined(REGULAR_TORUS_TOPOLOGY)
// TORUS_TOPOLOGY supports NICS Kraken, non-contiguous allocation
// REGULAR_TORUS_TOPOLOGY supports IBM BG/P, contiguous allocation, degenerates to mesh if < 512 nodes
  env.strategy = TM_RECURSIVE; // use the recursive bipartitioning mapping algorithm
#endif // TORUS_TOPOLOGY || REGULAR_TORUS_TOPOLOGY
#endif // FAT_TREE_TOPOLOGY

  TM_Gettopo_env(&env, distgr);
  TM_Topomap_env(&env, distgr, newrank);
  TM_Destroy_env(&env);

  return TM_SUCCESS;
}
