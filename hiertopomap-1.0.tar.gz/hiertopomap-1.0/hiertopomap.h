#ifndef HIERTOPOMAP_H
#define HIERTOPOMAP_H

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sched.h>
#include <cstring>
#include <string>
#include <assert.h>
#include <vector>
#include <list>
#include <string>
#include <numeric>
#include <algorithm>
#include <map>
#include <limits>

#include <mpi.h>

#include "topo.h"

#define CHECK // enable un-necessary checks 

//#define PRINT_DEBUG // debug information 
#define PRINT_INFO // general information

//#define OPT_MAP // optimize the mapping for torus topology

//#define USE_PARMETIS // use ParMETIS to partition the virtual topology graph

//#define INTRA_GRAPH_MAP
#define INTRA_TREE_MAP

#define TM_SUCCESS   0
#define TM_ERR_TOPO -1 // topology information is not available
#define TM_ERR_COMM -2 // communicator is not consistent
#define TM_ERR_MAP  -3 // mapping is not ready
#define TM_ERR_CALL -4 // function is not supported for current configuration

#define TM_RECURSIVE 0 // recursive mapping for torus topology
#define TM_NJ_TREE   1 // neighbor joining tree based mapping

#define TM_MAPPER_INTER 0 // inter-node mapping
#define TM_MAPPER_HIER  1 // hierarchical mapping, i.e. both inter-node and intra-node

#define TM_OBJ_EDGECUT 0 // minimize edgecut for intra-node mapping 
#define TM_OBJ_MIMS    1 // minimize MIMS (Maximum Inter-socket Message Size) for intra-node mapping 

typedef std::vector<std::vector<int> > TM_Graph; // adjacency list grah representation
typedef std::vector<std::vector<int> > TM_Graph_ewgts; // edge weights
typedef std::vector<int> vertex_part; // mapping from each vertex to its part id 
typedef std::vector<std::vector<int> > part_vertices; // the vertices of each part 
typedef std::pair<int, int> edge; // edge

// Re-define the major API names
#define HTM_Topomap           TM_Topomap
#define HTM_Topomap_tree      TM_Topomap_tree
#define HTM_Topomap_bipart    TM_Topomap_bipart

// Major APIs: they accept an MPI distributed graph communicator, and computes
// the newrank id of each process. The first one "TM_Topomap" is the default mapping
// function, it applies recursive tree mapping for fat-tree topology, and recursive
// bipartioning for mesh/torus topology. The second one "TM_Topomap_tree" is the recursive
// tree mapping function, it can be used on either fat-tree or mesh/torus topology.
// The third one "TM_Topomap_bipart" is the recursive bipartitioning mapping function.
// It can only be used on mesh/torus topology.
int HTM_Topomap(MPI_Comm distgr, int *newrank);
int HTM_Topomap_tree(MPI_Comm distgr, int *newrank);
int HTM_Topomap_bipart(MPI_Comm distgr, int *newrank);


int TM_Gettopo_env(TM_env *env, MPI_Comm distgr);
int TM_Topomap_env(TM_env *env, MPI_Comm distgr, int *newrank);
int TM_Metrics_env(TM_env *env, MPI_Comm distgr);
void TM_Destroy_env(TM_env *env);


#ifdef FAT_TREE_TOPOLOGY // supports TACC Stampede, non-contiguous allocation

typedef struct TM_env {

  hwproc_info myinfo; // my hardware process information
  all_hwproc_info allinfo; // the information of all hardware processes
  hop_distances all_hopdis; // node hop distance matrix 
  int nnodes; // number of nodes
  tree nj_tree; // neighbor joining tree (only store non-leaf nodes) of the network topology
  int npus; // number of processing units on the corresponding compute node,
            // it is the number of leaves in the intra-node topology tree
  tree intra_tree; // the intra-node topology tree

  TM_Graph vtg; // vtg - virtual topology graph
  TM_Graph_ewgts vtg_ewgts; // vtg edge weights 

  int nranks; // number of ranks
  int myrank; // myrank in distributed graph communicator

  bool topo_ready; // topology information is ready or not?
  bool map_ready; // topology mapping is done or not?

  int mapper; // TM_MAPPER_INTER or TM_MAPPER_HIER
  int intra_obj; // TM_OBJ_EDGECUT or TM_OBJ_MIMS

  // timers
  double t_gettopo;
  double t_query; // query time
  double t_nj; // neighbor joining time

  // timers
  double t_topomap;
  double t_vtg; // execution time for building the virtual topology graph
  double t_inter_map;
  double t_intra_map;

  std::vector<int> rank2newrank; // mapping from rank to newrank
  std::vector<int> newrank2rank; // mapping from newrank to rank

  size_t hop_bytes; // hop-bytes compured during mapping, only valid for rank 0

  int newrank;

  TM_env(): topo_ready(false), map_ready(false),
    mapper(TM_MAPPER_INTER), intra_obj(TM_OBJ_EDGECUT),
    t_gettopo(0), t_query(0), t_nj(0),
    t_topomap(0), t_vtg(0), t_inter_map(0), t_intra_map(0) {} // public ctor

  ~TM_env(){} // public dtor

} TM_env;

#else
#if defined(TORUS_TOPOLOGY) || defined(REGULAR_TORUS_TOPOLOGY)

typedef struct TM_env {

  hwproc_info myinfo; // my hardware process information
  all_hwproc_info allinfo; // the information of all hardware processes
#ifdef OPT_MAP
  hop_distances hopdis; // the distance (in hops) between current hardware process and other processes
#endif
  int nnodes; // number of nodes
  coords node_coords; // node coordinates
  hop_distances all_hopdis; // node hop distance matrix 
  tree nj_tree; // neighbor joining tree (only store non-leaf nodes) of the network topology
  int npus; // number of processing units on the corresponding compute node,
            // it is the number of leaves in the intra-node topology tree
  tree intra_tree; // the intra-node topology tree

  TM_Graph vtg; // vtg - virtual topology graph
  TM_Graph_ewgts vtg_ewgts; // vtg edge weights 

  int nranks; // number of ranks
  int myrank; // myrank in distributed graph communicator

  bool topo_ready; // topology information is ready or not?
  bool map_ready; // topology mapping is done or not?

  int strategy; // TM_RECURSIVE TM_NJ_TREE
  int mapper; // TM_MAPPER_INTER or TM_MAPPER_HIER
  int intra_obj; // TM_OBJ_EDGECUT or TM_OBJ_MIMS

  // timers
  double t_gettopo;
  double t_nj;

  // timers
  double t_topomap;
  double t_vtg; // execution time for building the virtual topology graph
  double t_inter_map;
  double t_intra_map;

  std::vector<int> rank2newrank; // mapping from rank to newrank
  std::vector<int> newrank2rank; // mapping from newrank to rank

  size_t hop_bytes; // hop-bytes compured during mapping, only valid for rank 0

  int newrank;

  TM_env(): topo_ready(false), map_ready(false),
    strategy(TM_RECURSIVE), mapper(TM_MAPPER_INTER), intra_obj(TM_OBJ_EDGECUT),
    t_gettopo(0), t_topomap(0), t_vtg(0),
    t_inter_map(0), t_intra_map(0) {} // public ctor

  ~TM_env(){} // public dtor

} TM_env;

#else
  #error "Must define the topology: FAT_TREE_TOPOLOGY, TORUS_TOPOLOGY or REGULAR_TORUS_TOPOLOGY"
#endif // TORUS_TOPOLOGY || REGULAR_TORUS_TOPOLOGY
#endif // FAT_TREE_TOPOLOGY

#endif // HIERTOPOMAP_H
