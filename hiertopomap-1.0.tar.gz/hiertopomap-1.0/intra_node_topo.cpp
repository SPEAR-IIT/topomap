#include "hiertopomap.h"

#ifdef INTRA_TREE_MAP

extern "C" { // hwloc
#include <hwloc.h>
}

// recursively build the topology tree, it returns the id 
// of the root of the tree (or subtree)
static int build_topology_tree(hwloc_topology_t topology,
  hwloc_obj_t obj, int depth, tree &intra_tree, const int npus)
{
  int root_id;
  int arity = obj->arity;

  if (arity > 1) { // multiple children, add a tree node
    treenode node;
    node.children.resize(arity);
    node.subtree_size.resize(arity);
    for (unsigned int i = 0; i < arity; i++) {
      int subtree_root_id = build_topology_tree(topology, obj->children[i], depth + 1, intra_tree, npus);
      node.children[i] = subtree_root_id;

      if (subtree_root_id >= npus) { // a non-leaf node
        node.subtree_size[i] = intra_tree[subtree_root_id - npus].total_size;
      }
      else { // a leaf node
        node.subtree_size[i] = 1; 
      }
    }
    node.total_size = std::accumulate(node.subtree_size.begin(), node.subtree_size.end(), 0);
    node.id = npus + intra_tree.size();
    intra_tree.push_back(node);
    root_id = node.id;
  }
  else if (arity == 1) { // just one child, do not add the tree node
    root_id = build_topology_tree(topology, obj->children[0], depth + 1, intra_tree, npus);
  }
  else { // leaf object, i.e., a processing element
    assert(arity == 0);
    root_id = obj->logical_index; // id of processing unit 
  }

  return root_id;
}

// get the intra-node topology by using the hwloc library
int TM_Gettopo_intra_node(TM_env *env)
// Note: currently, we build a intra-node topology tree by using hwloc,
// and then perform intra-node mapping by using the recursive tree mapping algorithm 
{
  int &npus = env->npus;
  tree &intra_tree = env->intra_tree;

  hwloc_topology_t topology;
  /* Allocate and initialize topology object. */
  hwloc_topology_init(&topology);
  /* Perform the topology detection. */
  hwloc_topology_load(topology);

  /* Optionally, get some additional topology information
  in case we need the topology depth later. */
  int topodepth;
  topodepth = hwloc_topology_get_depth(topology);

  // get the number of processing units
  // they are the leaves of the topology tree
  npus = hwloc_get_nbobjs_by_depth(topology, topodepth-1);

  int root = build_topology_tree(topology,
               hwloc_get_root_obj(topology), 0, intra_tree, npus);

#ifdef PRINT_INFO
  if (!env->myrank) {
    printf("get intra-node topology done!\n");
    printf("intra-node topology tree:\n");
    for (size_t i = 0; i < intra_tree.size(); ++i) {
      printf("node %d, total_size = %d\n", intra_tree[i].id, intra_tree[i].total_size);
      printf("children:");
      for (size_t j = 0; j < intra_tree[i].children.size(); ++j) {
        printf(" %d", intra_tree[i].children[j]);
      }
      printf("\nsubtree_size:");
      for (size_t j = 0; j < intra_tree[i].subtree_size.size(); ++j) {
        printf(" %d", intra_tree[i].subtree_size[j]);
      }
      printf("\n");
    }
  }
#endif  

  return 0;
}

#endif // INTRA_TREE_MAP
