#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <vector>
#include <algorithm>
#include <map>
#include <mpi.h>
#include <parmetis.h>
#include "hiertopomap.h"

bool smaller(std::pair<int,int> elem1, std::pair<int,int> elem2) {
     return elem1.first < elem2.first;
}

typedef std::pair<int,int> twoint;

void TM_Benchmark_graphtopo(MPI_Comm distgr, int newrank, int dsize, int niter, double *before, double *after);

int main(int argc, char** argv) {
  int m,n,nnz,start,end;
  int row, col;

  MPI_Init(&argc, &argv);

  int wr,ws;
  MPI_Comm_size(MPI_COMM_WORLD, &ws);
  MPI_Comm_rank(MPI_COMM_WORLD, &wr);

  if (argc < 4) {
//    fprintf(stderr, "%s <np (0 for all)> <matrix> <topomap file> [fake file]\n", argv[0]);
    if (wr == 0) {
      fprintf(stderr, "%s <datasize> <niter> <matrix>\n", argv[0]);
	  fprintf(stderr, "note: user can specify multiple matrices for test, e.g. %s <datasize> <niter> <matrix1> <matrix2> <matrix3> ...", argv[0]);
	}
    return -1;
  }
//  if (argc == 5) {
//    TPM_Fake_names_file = argv[4];
//    if(!wr) printf("using fake topology file %s\n", TPM_Fake_names_file);
//  }

  int border,color,key=0;
//  if(atoi(argv[1]) == 0) border=ws; else border = atoi(argv[1]);
  border=ws;
  if(wr < border) color = 0; else color = 1;
  MPI_Comm comm;
  MPI_Comm_split(MPI_COMM_WORLD, color, key, &comm);

  int p,r;
  MPI_Comm_size(comm, &p);
  MPI_Comm_rank(comm, &r);

  double t_total = 0;
  t_total = -MPI_Wtime();

  char *matrix_file;
  TM_env env;

  for (int testid = 3; testid < argc; ++testid) {
    matrix_file = argv[testid];

    if(!r) printf("starting with %i processes (built: %s %s)\n", p, __DATE__, __TIME__);

    std::vector<std::pair<int,int> > mat;
    { 
      FILE *fp = fopen(matrix_file, "r");
  
      const int LONGEST_LINE = 1024;
      char *buf = (char*)malloc(LONGEST_LINE+1);
      
      int firstline = 1;
      const int percinc=10;
      int lines = 0, perc=percinc;
      std::map<twoint,int,std::less<twoint> > edges;
      while(fgets(buf, LONGEST_LINE, fp) != NULL) {
        
        if(buf[0] == '%') continue; // comment
        if(firstline) { // the very first line has a special meaning
          sscanf(buf,"%d %d %d\n",&m,&n,&nnz);
          assert(m==n);
          start = r*(n/p);
          end = (r+1)*(n/p);
          if(r == p-1) end = n;
          firstline = 0;
          if(!r) printf("reading matrix \"%s\": %ix%i (nnz: %i)\n", matrix_file,m,n,nnz);
          continue;
        }
        sscanf(buf,"%d %d\n",&row,&col);
        // MM format starts with 1 instead of 0 -- correct!
        if(!(row>0 && row<=n)) printf("[%i] row: %i, n: %i\n", r, row, n);
        assert(row>0 && row<=n); assert(col>0 && col<=m);
        row--; col--;
        if(row != col) { // ParMeTiS doesn't like self-loops :-/
          if(row >= start && row < end) {
            // only insert if not already in graph
            std::pair<int,int> edge = std::make_pair(row,col);
            if(edges.find(edge) == edges.end()) {
              mat.push_back(std::make_pair(row, col));
              edges.insert(std::make_pair(edge,1));
            }
          }
          // read as symmetric graph!
          if(col >= start && col < end) {
            // only insert if not already in graph
            std::pair<int,int> edge = std::make_pair(col,row);
            if(edges.find(edge) == edges.end()) {
              mat.push_back(std::make_pair(col, row));
              edges.insert(std::make_pair(edge,1));
            }
          }
        }
        if(!r) if(++lines >= nnz*(double)perc/100) { printf("# read %i%% (%i) of lines\n", perc, lines); perc+=percinc; }
      }
      fclose(fp);
    }
  
    // matvec: z = v * A with z[i] = \sum_{j=0}^N (A[i,j] * v[j])
  
    //assert(mat.size() == nnz);
    int perproc = end-start;
    if(r<10) printf("[%i] finished reading matrix: %ix%i (nnz: %i), range: %i-%i (%i), elems: %i, \n", r,m,n,nnz,start,end,perproc,(int)mat.size());
  
    std::vector<idx_t>  vtxdist(p+1), // vertex distribution
                          xadj(perproc+1), // CSR index 
                          adjncy, // CSR list
                          part(perproc); // new index for each vertex
  
    // make sure that the initializer is bigger than all edge weights
    // (needed to guarantee that parmetis balances strictly!!!!
    idx_t initializer=1;
    std::vector<idx_t> vwgt(perproc,initializer); // vertex weights 
    std::vector<idx_t> adjwgt(mat.size(),initializer); // edge weights
  
    //for(int i=0; i<adjncy.size(); i++) printf("[%i] -> %i (%i)\n", r, adjncy[i], adjwgt[i]);
    int wgtflag=2; // 0 No weights, 1 Weights on the edges only, 2 Weights on the vertices only, 3 Weights on both the vertices and edges. 
    int numflag=0; // numbering scheme - 0 C-style numbering that starts from 0
    int ncon=1; // number of weights that each vertex has.
    int nparts = p; // number of partitions
    std::vector<float> tpwgts(ncon*nparts,1.0/nparts); // specify the fraction of vertex weight 
    std::vector<float> ubvec(ncon,1.05); // specify the imbalance tolerance for each vertex weight
    int options[3] = {1,0,0}; // use 0 as random seed, so the results of different runs would be consistent
    int edgecut;
    // fill vtxdist 
    for(int i=0; i<p; ++i) {
      vtxdist[i] = i*(n/p);
    }
    vtxdist[p] = n;
  
    // fill xadj
    std::sort(mat.begin(), mat.end(), smaller);
  
    int idx=0;
    int num=0;
    for(int i=start; i<end; ++i) {
      while(idx < mat.size() && i == mat[idx].first) {
        num++;
        adjncy.push_back(mat[idx].second);
        idx++;
      }
      xadj[i-start+1] = num;
    }
    //printf("[%i] %i == %i? (start: %i, end: %i)\n", r, adjncy.size(), mat.size(), start, end);
    assert(adjncy.size() == mat.size());
   
    const int printrank=-1;
    const int printsize=100;
    if(r==printrank) for(int i=0; i<vtxdist.size(); ++i) printf("vtxdist[%i] = %i\n", i, vtxdist[i]);
    if(r==printrank) for(int i=0; i<std::min((int)mat.size(),printsize); ++i) printf("mat[%i] = %i,%i\n", i, mat[i].first, mat[i].second);
    if(r==printrank) for(int i=0; i<std::min((int)xadj.size(),printsize); ++i) printf("xadj[%i] = %i\n", i, xadj[i]);
    if(r==printrank) for(int i=0; i<std::min((int)adjncy.size(),printsize); ++i) printf("adjncy[%i] = %i\n", i, adjncy[i]);
  
    MPI_Barrier(comm);
    if(!r) printf("calling ParMETIS\n");
    ParMETIS_V3_PartKway(&vtxdist[0], &xadj[0], &adjncy[0], &vwgt[0],  &adjwgt[0], &wgtflag, &numflag, &ncon, 
        &nparts, &tpwgts[0], &ubvec[0], &options[0], &edgecut, &part[0], &comm);
    if(!r) printf("ParMETIS done, edgecut: %i\n", edgecut);
  
    if(r==printrank) for(int i=0; i<std::min((int)part.size(),printsize); ++i) printf("part[%i] = %i\n", i, part[i]);
  
    // the vector part has now the new position for each row of the matrix
    // and element of the two vectors (it can be used to permute all rows)
  
    // we now collect the whole permutation to all processes (this is of
    // course not scalable)
    std::vector<int> perm(n);
    std::vector<int> recvcounts(p), displs(p);
    for(int i=0; i<p; ++i) {
      recvcounts[i] = n/p;
      displs[i] = i*(n/p);
    }
    recvcounts[p-1] = n-(p-1)*(n/p);
  
    MPI_Allgatherv(&part[0], perproc, MPI_INT, &perm[0], &recvcounts[0], &displs[0], MPI_INT, comm);
  
    // now we build a p*p matrix with the communication volume for each
    // element we have (after applying the permutation)
    // THIS IS OF COURSE TOTALLY NOT SCALABLE!
    std::vector<int> volumes(p*p,0), rvolumes(p*p,0);
    for(int i=0; i<mat.size(); ++i) {
      int src = perm[mat[i].first];
      int dst = perm[mat[i].second];
      volumes[src+dst*p]++;
    }
    // now allreduce it (I feel really bad)
    MPI_Allreduce(&volumes[0], &rvolumes[0], p*p, MPI_INT, MPI_SUM, comm);
  
    // build distributed graph communicator with the right weights!
    std::vector<int> sources(1,r),
                     degrees(1,0),
                     destinations,
                     weights;
  
    for(int i=0; i<p; ++i) {
      if(rvolumes[r+i*p] != 0) {
        if(r == 0) printf("[%i] sending %i doubles to %i\n", r, rvolumes[r+i*p], i);
        if(r == i) continue; // skip self-edge
        degrees[0]++;
        destinations.push_back(i);
        weights.push_back(rvolumes[r+i*p]);
      }
    }
  
//if(!r) for(int i=0; i<destinations.size(); ++i) printf("%i %i\n", destinations[i], weights[i]);
  
    MPI_Comm distgr;
    MPI_Dist_graph_create(comm, 1, &sources[0], &degrees[0], &destinations[0], &weights[0], MPI_INFO_NULL, 0, &distgr); // without reordering
    //TPM_Write_graph_comm(distgr, "./ltg.dot");
	
    int myrank;
    MPI_Comm_rank(distgr, &myrank);
	assert(myrank == r); // not reordered
  
	if (!env.topo_ready)
	  TM_Gettopo_env(&env, distgr); // get the topology information

    double before, after;
	int datasize = atoi(argv[1]);
	int niter = atoi(argv[2]);
	assert(niter > 0);

#ifdef TORUS_TOPOLOGY
	for (int strategy = 0; strategy < 2; ++strategy) {
	  env.strategy = strategy; // 0 - TM_RECURSIVE, 1 - TM_NJ_TREE
	  if (!r) printf("test strategy = %d ...\n", strategy);
#endif
    for(int i = 0; i < 3; ++i) {
      if(i==0) {
        //setenv("TM_STRATEGY", "internode", 1); // internode mapping only
		env.mapper = TM_MAPPER_INTER;
		if (!r) {
		  printf("**************************************************************\n");
		  printf("test inter-node mapping ...\n");
		}
      }
      else if (i==1) {
        //setenv("TM_STRATEGY", "hierarchical", 1);
        //setenv("TM_INTRANODE_OBJ", "edgecut", 1);
		env.mapper = TM_MAPPER_HIER;
		env.intra_obj = TM_OBJ_EDGECUT;
		if (!r) {
		  printf("**************************************************************\n");
		  printf("test hierarchical mapping (minimize edgecut for intra-node mapping) ...\n");
		}
      }
      else if (i==2) {
        //setenv("TM_STRATEGY", "hierarchical", 1);
        //setenv("TM_INTRANODE_OBJ", "mims", 1);
		env.mapper = TM_MAPPER_HIER;
		env.intra_obj = TM_OBJ_MIMS;
		if (!r) {
		  printf("**************************************************************\n");
		  printf("test hierarchical mapping (minimize MIMS for intra-node mapping) ...\n");
		}
      }

      int newrank;
	  //double t_map = 0;
      //MPI_Barrier(distgr);
	  //t_map = -MPI_Wtime();
      TM_Topomap_env(&env, distgr, &newrank); // call TM_Topmap
      //MPI_Barrier(distgr);
	  //t_map += MPI_Wtime();
      
      std::vector<int> rank2newrank(p);
      MPI_Allgather(&newrank, 1, MPI_INT, &rank2newrank[0], 1, MPI_INT, distgr);

      if (!r) {
        //printf("t_map = %f\n", t_map);
        printf("mapping solution:");
		// print up to 100 processes
        for (int j = 0; j < std::min(p, 100); ++j) printf(" %d", rank2newrank[j]);
        printf(" ...\n");
      }

      MPI_Barrier(distgr);

      if(!r) printf("start benchmark test: datasize = %d, niter = %d\n", datasize, niter);
      TM_Benchmark_graphtopo(distgr, newrank, datasize, niter, &before, &after);
      if(!r) printf("before: %f, after: %f\n", before, after);

	  TM_Metrics_env(&env, distgr);
    }
#ifdef TORUS_TOPOLOGY
	}
#endif

    if(!r) {
	  printf("**************************************************************\n");
	  printf("test MPI_Dist_graph_create() ...\n");
	}

    MPI_Comm reordered_distgr;

    MPI_Barrier(comm);
	double t_dist_graph = -MPI_Wtime();
    MPI_Dist_graph_create(comm, 1, &sources[0], &degrees[0], &destinations[0], &weights[0], MPI_INFO_NULL, 1, &reordered_distgr); // with reordering
	MPI_Barrier(comm);
    t_dist_graph += MPI_Wtime();

    if(!r) printf("MPI_Dist_graph_create() done! t_dist_graph = %f\n", t_dist_graph);

	int mynewrank;
    MPI_Comm_rank(reordered_distgr, &mynewrank);
	int reordered;
	if (mynewrank == r) reordered = 0;
	else reordered = 1;
	int all_reordered;
    MPI_Allreduce(&reordered, &all_reordered, 1, MPI_INT, MPI_MAX, comm);

	if (all_reordered == 1) {

      std::vector<int> rank2newrank(p);
      MPI_Allgather(&mynewrank, 1, MPI_INT, &rank2newrank[0], 1, MPI_INT, comm);

      if (!r) {
        printf("mapping solution:");
        for (int j = 0; j < std::min(p, 100); ++j) printf(" %d", rank2newrank[j]);
        printf(" ...\n");
      }

      MPI_Barrier(distgr);

	  if (!r) printf("start benchmark test: datasize = %d, niter = %d\n", datasize, niter);
      TM_Benchmark_graphtopo(distgr, mynewrank, datasize, niter, &before, &after);
      if(!r) printf("before: %f, after: %f\n", before, after);

	  if (!r) printf("cheat TM_env to print the statistics of metrics, note that the printed timing information is not valid!!!");
	  env.newrank = mynewrank;
	  TM_Metrics_env(&env, distgr);
	}
	else {
	  if (!r) printf("MPI_Dist_graph_create() did not reorder the ranks.\n");
	}
  }

  TM_Destroy_env(&env);

  t_total += MPI_Wtime();
  if (!r) printf("test done! t_total = %f\n", t_total);

  MPI_Finalize();

  return 0;
}

void TM_Benchmark_graphtopo(MPI_Comm distgr, int newrank, int dsize, int niter, double *before, double *after) {
  int r,p;
  MPI_Comm_size(distgr, &p);
  MPI_Comm_rank(distgr, &r);

  int indegree, outdegree, weighted;
  MPI_Dist_graph_neighbors_count(distgr, &indegree, &outdegree, &weighted);
  //assert(!weighted); // the code below works only for unweighted graphs (but accumulates multiple edges into weights)

  std::vector<int> in(indegree), out(outdegree), inw(indegree), outw(outdegree);
  MPI_Dist_graph_neighbors(distgr, indegree, &in[0], &inw[0], outdegree, &out[0], &outw[0]);

  //-- stolen from TPM_Topomap() !!!
  // we might get double edges here -- transform them into a weight map
  // (TODO: we loose the actual edge weights in this process but they
  // can easily be recovered if needed!)
  //std::vector<int> outw;
  if(!weighted) {
    if(outdegree > 0) {
      std::vector<int> tmp(out.size()); // temp vector

      std::sort(out.begin(), out.end());
      std::copy(out.begin(), out.end(), tmp.begin());
      out.erase(unique(out.begin(), out.end()), out.end());
      outdegree = out.size();
        
      // get weights by counting elements in tmp
      outw.resize(outdegree);

      int elem=tmp[0], cnt=0, pos=0;
      for(int i=0; i<tmp.size()+1; ++i) {
        if(tmp[i] == elem && i<tmp.size()) cnt++;
        else { 
          elem = tmp[i]; 
          assert(pos < out.size());
          //DBG2(printf("[%i] weight[%i]=%i\n", r, pos, cnt));
          outw[pos++] = cnt;
          cnt=1; 
  } } } } else {
    // weigthed graphs ignore double edges TODO: should be merged too at
    // some point ...
    assert(outw.size() == outdegree);
  }

  //std::vector<int> inw;
  if(!weighted) {
    if(indegree > 0) {
      std::vector<int> tmp(in.size()); // temp vector

      std::sort(in.begin(), in.end());
      std::copy(in.begin(), in.end(), tmp.begin());
      in.erase(unique(in.begin(), in.end()), in.end());
      indegree = in.size();
        
      // get weights by counting elements in tmp
      inw.resize(indegree);

      int elem=tmp[0], cnt=0, pos=0;
      for(int i=0; i<tmp.size()+1; ++i) {
        if(tmp[i] == elem && i<tmp.size()) cnt++;
        else { 
          elem = tmp[i]; 
          assert(pos < in.size());
          //DBG2(printf("[%i] weight[%i]=%i\n", r, pos, cnt));
          inw[pos++] = cnt;
          cnt=1; 
  } } } } else {
    // weigthed graphs ignore double edges TODO: should be merged too at
    // some point ...
    assert(inw.size() == indegree);
  }

  /* do benchmark - send along edges */

  const int mult=dsize;
  const int trials=niter+1;
  std::vector<std::vector<char> > sbufs(outdegree), rbufs(indegree);
  for(int i=0; i<outdegree; ++i) sbufs[i].resize(mult*outw[i]);
  for(int i=0; i<indegree; ++i) rbufs[i].resize(mult*inw[i]);
  std::vector<MPI_Request> sreqs(outdegree), rreqs(indegree);

  if(!r) printf("starting benchmark!\n");

  MPI_Barrier(distgr);

  //MPI_Aint w;
  double t[2];
  for(int i=0; i < trials; ++i) {
    if (i == 1) {
      t[0] = -MPI_Wtime();
    }
    for(int j=0; j<in.size(); ++j) {
      MPI_Irecv(&rbufs[j][0], inw[j]*mult, MPI_BYTE, in[j], 0, distgr, &rreqs[j]);
    }
    for(int j=0; j<out.size(); ++j) {
      MPI_Isend(&sbufs[j][0], outw[j]*mult, MPI_BYTE, out[j], 0, distgr, &sreqs[j]);
    }
    // silly AMPI doesn't support MPI_STATUSES_IGNORE
    std::vector<MPI_Status> rstats(rreqs.size());
    std::vector<MPI_Status> sstats(sreqs.size());
    MPI_Waitall(rreqs.size(), &rreqs[0], &rstats[0]);
    MPI_Waitall(sreqs.size(), &sreqs[0], &sstats[0]);
  }
  t[0] += MPI_Wtime();

  /* create reordered comm */
  MPI_Comm reorderedcomm;
  MPI_Comm_split(distgr, 0, newrank, &reorderedcomm);

  int newr;
  MPI_Comm_rank(reorderedcomm, &newr);
  assert(newr == newrank);

  if(!r) printf("finished stage one (%f s), rearranging edge connectivity!\n", t[0]);

  /* now we need to send our neighbor list to the host that has our rank
   * now -- first figure out the permutation in a non-scalable way :) */
  std::vector<int> permutation(p);
  MPI_Allgather(&newrank, 1, MPI_INT, &permutation[0], 1, MPI_INT, distgr);
  int rpeer=permutation[r]; // new rank r in reorderedcomm!
  int speer=0; while(permutation[speer++] != r); speer--;
  //printf("[%i] >%i <%i\n", r, speer, rpeer);

  MPI_Request reqs[4];
  MPI_Isend(&in[0], in.size(), MPI_INT, speer, 1, distgr, &reqs[0]);
  assert(in.size() == inw.size());
  MPI_Isend(&inw[0], in.size(), MPI_INT, speer, 1, distgr, &reqs[1]);
  //printf("%i sending in %i %i to %i\n", r, in[0], in[1], speer);
  MPI_Isend(&out[0], out.size(), MPI_INT, speer, 2, distgr, &reqs[2]);
  assert(out.size() == outw.size());
  MPI_Isend(&outw[0], out.size(), MPI_INT, speer, 2, distgr, &reqs[3]);
  //printf("%i sending out %i %i to %i\n", r, out[0], out[1], speer);

  MPI_Status stat;
  /* tag == 1 -> in edges */
  MPI_Probe(rpeer, 1, distgr, &stat);
  int count;
  MPI_Get_count(&stat, MPI_INT, &count);
  std::vector<int> rin(count), rinw(count);
  MPI_Recv(&rin[0], count, MPI_INT, rpeer, 1, distgr, MPI_STATUS_IGNORE);
  MPI_Recv(&rinw[0], count, MPI_INT, rpeer, 1, distgr, MPI_STATUS_IGNORE);
  //printf("%i recvd in %i %i from %i\n", r, rin[0], rin[1], rpeer);

  /* tag == 2 -> out edges */
  MPI_Probe(rpeer, 2, distgr, &stat);
  MPI_Get_count(&stat, MPI_INT, &count);
  std::vector<int> rout(count), routw(count);
  MPI_Recv(&rout[0], count, MPI_INT, rpeer, 2, distgr, MPI_STATUS_IGNORE);
  MPI_Recv(&routw[0], count, MPI_INT, rpeer, 2, distgr, MPI_STATUS_IGNORE);
  //printf("%i recvd out %i %i from %i\n", r, rout[0], rout[1], rpeer);
 
  // silly AMPI doesn't support MPI_STATUSES_IGNORE
  std::vector<MPI_Status> stats(4);
  MPI_Waitall(4, reqs, &stats[0]);

  MPI_Barrier(distgr); if(!r) printf("finished rearranging edge connectivity, starting phase two!\n");

  /* reset all data structures for new permutation */ 
  sreqs.resize(rout.size());
  rreqs.resize(rin.size());

  sbufs.resize(rout.size());
  for(int i=0; i<sbufs.size(); ++i) sbufs[i].resize(mult*routw[i]);
  rbufs.resize(rin.size());
  for(int i=0; i<rbufs.size(); ++i) rbufs[i].resize(mult*rinw[i]);

  MPI_Barrier(distgr);

  for(int i=0; i < trials; ++i) {
    if(i == 1) {
      t[1] = -MPI_Wtime();
    }
    for(int j=0; j<rin.size(); ++j) {
      MPI_Irecv(&rbufs[j][0], rinw[j]*mult, MPI_BYTE, rin[j], 0, reorderedcomm, &rreqs[j]);
    }
    for(int j=0; j<rout.size(); ++j) {
      MPI_Isend(&sbufs[j][0], routw[j]*mult, MPI_BYTE, rout[j], 0, reorderedcomm, &sreqs[j]);
    }
    // silly AMPI doesn't support MPI_STATUSES_IGNORE
    std::vector<MPI_Status> rstats(rreqs.size());
    std::vector<MPI_Status> sstats(sreqs.size());
    MPI_Waitall(rreqs.size(), &rreqs[0], &rstats[0]);
    MPI_Waitall(sreqs.size(), &sreqs[0], &sstats[0]);
  }
  t[1] += MPI_Wtime();

  double rt[2];
  MPI_Allreduce(t, rt, 2, MPI_DOUBLE, MPI_MAX, distgr);

  *before=rt[0];
  *after=rt[1];
}
