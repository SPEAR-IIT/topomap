#ifndef TOPO_H
#define TOPO_H

#define TORUS_TOPOLOGY // NICS Kraken
//#define FAT_TREE_TOPOLOGY //  TACC Stampede
//#define REGULAR_TORUS_TOPOLOGY // BG/P 

#define NAME_LENGTH 256
#define LINE_LENGTH 1024

// hardware process information
typedef struct HWPROC_INFO {
  char nodename[NAME_LENGTH]; // node name
  int nodeid; // node id [0, nnodes-1]
  int coreid; // core id [0, ncores-1]
#if defined(TORUS_TOPOLOGY) || defined(REGULAR_TORUS_TOPOLOGY)
  int x, y, z; // 3D mesh/torus coordinates
#endif
} hwproc_info;

typedef std::vector<hwproc_info> all_hwproc_info; // information of all the hardware processes
typedef std::vector<int> hop_distances; // the distance (in hops) between current process and other processes

typedef struct COORD {
  int x, y, z; // 3D mesh/torus coordinates
} coord;
typedef std::vector<coord> coords; // node coordinates 

typedef struct TREENODE {
  int id; // tree node id
  int total_size; // total size of the subtree rooted at this node (only count the number of leaf nodes)
  std::vector<int> children;
  std::vector<int> subtree_size;
} treenode;

typedef std::vector<treenode> tree;

struct TM_env;

#ifdef FAT_TREE_TOPOLOGY // supports TACC Stampede, non-contiguous allocation
int TM_Gettopo_fattree(TM_env *env, MPI_Comm distgr);
#else
#if defined(TORUS_TOPOLOGY) || defined(REGULAR_TORUS_TOPOLOGY)
// TORUS_TOPOLOGY supports NICS Kraken, non-contiguous allocation
// REGULAR_TORUS_TOPOLOGY supports IBM BG/P, contiguous allocation, degenerates to mesh if < 512 nodes
int estimate_hop_distance(const hwproc_info &n1, const hwproc_info &n2);
int TM_Gettopo_torus(TM_env *env, MPI_Comm distgr);
#else
  #error "Must define the topology: FAT_TREE_TOPOLOGY, TORUS_TOPOLOGY or REGULAR_TORUS_TOPOLOGY"
#endif // TORUS_TOPOLOGY || REGULAR_TORUS_TOPOLOGY
#endif // FAT_TREE_TOPOLOGY

int TM_Gettopo_intra_node(TM_env *env);

#endif // TOPO_H
