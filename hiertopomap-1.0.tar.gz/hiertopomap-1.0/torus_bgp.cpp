#include "hiertopomap.h"

// the fuctions in this file are used to support torus topology 
// (non-contiguous allocation), specifically - BG/P machines 
#ifdef REGULAR_TORUS_TOPOLOGY

extern "C" { // BG/P topology function headers
#include <spi/kernel_interface.h>
#include <common/bgp_personality.h>
#include <common/bgp_personality_inlines.h>
}

// physical dimensions 
static int xsize, ysize, zsize;
static bool is_torus;

// get hardware process information
static void get_hwproc_info(hwproc_info &info)
{
  gethostname(info.nodename, NAME_LENGTH); // node name

  _BGP_Personality_t personality;

  info.coreid = Kernel_PhysicalProcessorID();
  info.x = personality.Network_Config.Xcoord;
  info.y = personality.Network_Config.Ycoord;
  info.z = personality.Network_Config.Zcoord;

  xsize = personality.Network_Config.Xnodes;
  ysize = personality.Network_Config.Ynodes;
  zsize = personality.Network_Config.Znodes;

  is_torus = (xsize*ysize*zsize >= 512);
}

// compute the distance in one dimension
// here, we assume torus topology, since Kraken is connected by 3D torus network
static int estimate_coordinate_distance(const int &x1, const int &x2, const int &x_dimension)
{
  int d1 = abs(x1-x2); // the distance through the direct path

  if (!is_torus) return d1; // if mesh, return d1

  int d2; // the distance through the wrap-round path

  if (x1 < x2) d2 = abs(x1+x_dimension-x2);
  else d2 = abs(x2+x_dimension-x1);

  int d = (d1 < d2) ? d1 : d2;

  return d;
}

// compute the overall distance
int estimate_hop_distance(const hwproc_info &n1, const hwproc_info &n2)
{
  int dis = 0;
    
  dis += estimate_coordinate_distance(n1.x, n2.x, xsize); // X dimension
  dis += estimate_coordinate_distance(n1.y, n2.y, ysize); // Y dimension
  dis += estimate_coordinate_distance(n1.z, n2.z, zsize); // Z dimension

  return dis;
}

// This function uses the neighbor joining algorithm to derive the
// fat-tree topology according to the hopdis matrix. Details of the
// neighbor joining algorithm can be found in the following paper:
// Subramoni et al. "Design of a Scalable InfiniBand Topology Service to Enable
// Network-Topology-Aware Placement of Processes", in Proc. SC'12, Nov. 2012.
static void neighbor_joining(int nnodes, std::vector<int> &all_hopdis, // hopdis matrix
  tree &nj_tree, int myrank) // neigbor joined tree
{
  std::vector<std::vector<int> > d(nnodes); // distance matrix, d[i][j] - distance between node i and j
  for (int i = 0; i < nnodes; i++) { // fill the distance matrix
    d[i].resize(nnodes);
    std::vector<int>::iterator it = all_hopdis.begin()+i*nnodes;
    std::copy(it, it+nnodes, d[i].begin());
  }
// all_hopdis.clear(); // save memory

  typedef std::pair<int, int> node_pair;
  std::vector<std::list<node_pair> > rd; // rd(m) mapping from distance m to list of node pairs
  for (int i = 0; i < nnodes; i++) { // fill rd
    for (int j = i+1; j < nnodes; j++) { // only check the pairs (i, j), which satisfy i < j
      int dis = d[i][j]; // distance between node i and j
      if (rd.size() < (size_t)dis+1) { // make sure that rd[dis] is accessible
        rd.resize(dis+1);
      }
      rd[dis].push_back(std::make_pair(i, j));
    }
  }

  std::vector<bool> a(nnodes, true); // a(i) - node i is active or not

  nj_tree.clear();
  int iter = 1;
  while (1) {
    int i, j; // node id variables
    bool found = false; // an active pair is found or not
    for (size_t dis = 0; dis < rd.size(); ++dis) {
      for (std::list<node_pair>::iterator it = rd[dis].begin(); it != rd[dis].end(); ) {
        i = it->first;
        j = it->second;
        if (a[i] && a[j]) {
          found = true; // an active pair is found
#ifdef PRINT_DEBUG
		  if (!myrank) fprintf(stderr, "inter %d: find active edge (%d, %d)\n", iter, i, j);
#endif
          break;
        }
        else { // remove inactive pairs
          rd[dis].erase(it++);
#ifdef PRINT_DEBUG
		  if (!myrank) fprintf(stderr, "inter %d: delete inactive edge (%d, %d)\n", iter, i, j);
#endif
        }
      }
      
      if (found) break;
    }

    if (!found) break; // terminate if no active edges

    // an active edge is found, we need to add a joined tree node "n"
    treenode n;
    nj_tree.push_back(n);
    int new_node = nnodes + nj_tree.size() - 1; // the id of the new non-leaf node
    nj_tree.back().id = new_node;
    std::vector<int> &children = nj_tree.back().children;
    std::vector<int> &subtree_size = nj_tree.back().subtree_size;

    children.push_back(i);
    children.push_back(j);

    int dij = d[i][j];
    // find the nearest neighbors
    for (size_t k = 0; k < d[i].size(); ++k) {
      if ((a[k]) && (d[i][k] == dij)) {
        bool add_k = true;
        for (size_t index = 1; index < children.size(); ++index) { // the first one in L is i
          int id = children[index];
          if (d[k][id] != dij) { // in fact, dij is the minimum distance value of current active node pairs
            // so it must be ture that d[k][id] >= dij
            add_k = false;
            break;
          }
        }

        if (add_k) {
		  children.push_back(k);
#ifdef PRINT_DEBUG
		  if (!myrank) fprintf(stderr, "inter %d: add node %ld\n", iter, k);
#endif
		}
      }
    }

    // children are ready, fill subtree_size
    subtree_size.resize(children.size());
    for (size_t index = 0; index < subtree_size.size(); ++index) {
      int id = children[index];
      a[id] = false; // set the joined nodes to be invalid
      if (id < nnodes) subtree_size[index] = 1; // just a leaf node
      else subtree_size[index] = nj_tree[id-nnodes].total_size; // a non-leaf node
    }
    nj_tree.back().total_size = std::accumulate(subtree_size.begin(), subtree_size.end(), 0);
#ifdef PRINT_DEBUG
	if (!myrank) fprintf(stderr, "inter %d: compute subtree_size done!\n", iter);
#endif

    // now, the joined tree node is ready
    // we need to update the distance maps: d & rd
    	std::vector<int> d_new_node;
	d.push_back(d_new_node);
	d.back().assign(a.size()+1, 0);
    for (size_t id = 0; id < a.size(); ++id) {
      if (a[id]) {
        int dis = 0;
        for (size_t index = 0; index < children.size(); ++index) {
          int k = children[index];
          if (d[id][k] > dis) dis = d[id][k]; // take max distance
        }
        d[id].push_back(dis); // add the distance between id and new_node 
		d[new_node][id] = dis;
        rd[dis].push_back(std::make_pair(id, new_node));
      }
    }
    a.push_back(true); // the joined tree node is valid
#ifdef PRINT_DEBUG
	if (!myrank) fprintf(stderr, "inter %d: update d and rd done!\n", iter);
#endif
    iter++;
  }
}

// get the topology related information
int TM_Gettopo_torus(TM_env *env, MPI_Comm distgr)
// Note: currently, hopdis is computed per process, not per compute node.
// It is only used in TM_Topomap_torus() if OPT_MAP is defined.
// It may be further improved by computing hopdis per compute node.
{
  hwproc_info &myinfo = env->myinfo;
  all_hwproc_info &allinfo = env->allinfo;
#ifdef OPT_MAP
  hop_distances &hopdis = env->hopdis;
#endif
  int &nnodes = env->nnodes;
  coords &node_coords = env->node_coords;
  hop_distances &all_hopdis = env->all_hopdis;
  tree &nj_tree = env->nj_tree;
  double &t_nj = env->t_nj;

  // get the number of ranks and my rank
  int &nranks = env->nranks;
  int &myrank = env->myrank;

  MPI_Comm_size(distgr, &nranks);
  MPI_Comm_rank(distgr, &myrank); // myrank is not used in the current function

  get_hwproc_info(myinfo); // get myinfo

  allinfo.resize(nranks);
  MPI_Allgather(&myinfo, sizeof(hwproc_info), MPI_BYTE, &allinfo[0], sizeof(hwproc_info),
    MPI_BYTE, distgr); // gather allinfo

  // compute hop distances
#ifdef OPT_MAP
  hopdis.resize(nranks);
  for (int i = 0; i < nranks; i++) {
    hopdis[i] = estimate_hop_distance(myinfo, allinfo[i]);
  }
#endif

  std::map<std::string, int> nodeproc; // <node name, number of processes on it>
  for (int i = 0; i < nranks; i++) {
    std::string name = allinfo[i].nodename;
    std::map<std::string, int>::iterator it = nodeproc.find(name);
    if (it == nodeproc.end()) { // not found
      nodeproc[name] = 1; // add the node 
    }
    else { // found
      it->second++; // update the counter
    }
  }

  nnodes = nodeproc.size(); // number of compute nodes
  assert(nranks%nnodes == 0);
  int nprocs_per_node = nranks/nnodes;

#ifdef PRINT_INFO
  if (!myrank) printf("nranks = %d, nnodes = %d, nprocs_per_node = %d\n",
    nranks, nnodes, nprocs_per_node);
#endif

  for (std::map<std::string, int>::const_iterator it = nodeproc.begin();
    it != nodeproc.end(); it++) {
    assert(it->second == nprocs_per_node);
  }

  // fill nodeif, coreid and coords, make sure that each node is assigned contiguous processes 
  // This is the assumption of current implementation, we only support the default
  // consective mapping as the input. In order to support random input mappings,
  // we need to derive node id and core id explictly.
  node_coords.resize(nnodes);
  std::string current_nodename;
  for (int i = 0; i < nranks; i++) {
    int nodeid = i / nprocs_per_node;
    allinfo[i].nodeid = nodeid; // fill node id

    int coreid = i % nprocs_per_node;
    allinfo[i].coreid = coreid; // fill core id

    if (coreid == 0) {
	  node_coords[nodeid].x = allinfo[i].x; // fill coords
	  node_coords[nodeid].y = allinfo[i].y;
	  node_coords[nodeid].z = allinfo[i].z;
      current_nodename = allinfo[i].nodename;
    }
    else {
      std::string name = allinfo[i].nodename;
      assert(current_nodename == name); // check node name
	  assert(node_coords[nodeid].x == allinfo[i].x); // check coords
	  assert(node_coords[nodeid].y == allinfo[i].y);
	  assert(node_coords[nodeid].z == allinfo[i].z);
    }
  }

  myinfo = allinfo[myrank];
  // now, allinfo is ready at each process
  
  // create a new communicator, so that we can compute the node hop distances 
  // by using one process on each compute node
  int color;
  if (myinfo.coreid == 0) color = 0; 
  else color = MPI_UNDEFINED;
  int key = myinfo.nodeid;

  MPI_Comm node_comm;
  MPI_Comm_split(distgr, color, key, &node_comm);

  all_hopdis.resize(nnodes*nnodes); // hopdis matrix
  if (color == 0) {
	hop_distances myhopdis(nnodes);
	for (int i = 0; i < nnodes; ++i) {
      int dis = estimate_coordinate_distance(myinfo.x, node_coords[i].x, X_DIMENSION); // X dimension
      dis += estimate_coordinate_distance(myinfo.y, node_coords[i].y, Y_DIMENSION); // Y dimension
      dis += estimate_coordinate_distance(myinfo.z, node_coords[i].z, Z_DIMENSION); // Z dimension
	  myhopdis[i] = dis;
    }
    //MPI_Allgather(&myhopdis[0], nnodes, MPI_INT, &all_hopdis[0], nnodes, MPI_INT, node_comm);
    MPI_Gather(&myhopdis[0], nnodes, MPI_INT, &all_hopdis[0], nnodes, MPI_INT, 0, node_comm);
  }

  t_nj = 0;
  t_nj = -MPI_Wtime();
  //if (nnodes < nranks) // multiple processes per node
    MPI_Bcast(&all_hopdis[0], nnodes*nnodes, MPI_INT, 0, distgr); // broadcast all_hopdis to all ranks

  neighbor_joining(nnodes, all_hopdis, nj_tree, myrank);
  t_nj += MPI_Wtime();

#ifdef PRINT_INFO
  if (!myrank) {
    printf("neighbor joining done! t_nj = %f\n", t_nj);
    printf("The information of up to 32 nodes:\n");
    for (int i = 0; i < std::min(32, nnodes); ++i) {
      printf("node %d:\tname=%s;\tx=%d;\ty=%d;\tz=%d\n",
		i, allinfo[i*nprocs_per_node].nodename,
		node_coords[i].x, node_coords[i].y, node_coords[i].z);
    }
  }
#endif

  return TM_SUCCESS;
}

#endif // REGULAR_TORUS_TOPOLOGY
